import unittest
from types import SimpleNamespace
from unittest.mock import patch
from xml.etree.ElementTree import Element
from engine import FormAssistant
from ui_scan import BidirectionalScan

class SkipFieldTests(unittest.TestCase):
    def runner(self,text):
        r=object.__new__(FormAssistant);r.log=lambda s:None;r.check=lambda:None
        r.edit=Element('node',attrib={'class':'android.widget.EditText','text':text,'bounds':'[10,100][400,180]'})
        r.section=lambda *a:[r.edit];r.nodes=lambda:[];r.calls=[]
        def set_text(value):r.calls.append(value);r.edit.set('text',value)
        r.d=SimpleNamespace(window_size=lambda:(500,1000),xpath=lambda s:SimpleNamespace(set_text=set_text))
        return r
    def test_matching_fields_not_written(self):
        for value in ('0','Tốt','20','10',''):
            r=self.runner(value)
            self.assertFalse(r.field('Kiểm diện','Tiết theo PPCT',value))
            self.assertEqual(r.calls,[])
    def test_changed_field_written_once_and_verified(self):
        r=self.runner('Cũ')
        with patch('engine.time.sleep'):
            self.assertTrue(r.field('Nhận xét của giáo viên','Giáo viên xác nhận','Tốt'))
        self.assertEqual(r.calls,['Tốt'])
    def test_field_above_current_position_found(self):
        r=self.runner('20');r.visible=False;r.directions=[]
        r.section=lambda *a:[r.edit] if r.visible else []
        def scroll(forward=True):r.directions.append(forward);r.visible=True
        r.scroll=scroll
        self.assertFalse(r.field('Học tập','Kỷ luật','20'))
        self.assertEqual(r.directions,[False]);self.assertEqual(r.calls,[])
    def test_scan_top_then_bottom_and_stops(self):
        scan=BidirectionalScan();directions=[]
        for i in range(70):
            direction=scan.next_direction(('unchanged',))
            if direction is None:break
            directions.append(direction)
        self.assertIn(False,directions);self.assertIn(True,directions);self.assertLess(len(directions),10)

if __name__=='__main__':unittest.main()
