"""Read-only checks immediately before phone automation."""
from profiles import validate,key
from engine import label
from navigator import PACKAGE,Navigator,week_number

def data_checks(profile,tasks,ledger,only=False):
    errors=[];notes=[]
    try:validate(profile)
    except (ValueError,KeyError,TypeError) as e:errors.append('Hồ sơ: '+str(e))
    if not tasks:errors.append('Chưa chọn tiết cần thực hiện.')
    if len({key(t) for t in tasks})!=len(tasks):errors.append('Danh sách có tiết trùng nhau.')
    for t in tasks:
        desc=f"{t['classroom']} / PPCT {t['period']}"
        if not t.get('valid') or str(t['period']) not in profile.get('courses',{}).get(t['course'],{}).get('periods',{}):errors.append(desc+': thiếu PPCT.')
        if t['profile_id']!=profile['id']:errors.append(desc+': không thuộc hồ sơ đang chọn.')
        if any(ledger.state(t,m)=='saving' for m in ('write','complete')):errors.append(desc+': lần lưu trước chưa rõ kết quả, cần đối chiếu.')
    if len({t['week'] for t in tasks})>1:errors.append('Danh sách đang trộn nhiều tuần.')
    if not errors:notes.append(f'Hồ sơ, TKB, PPCT và tiến độ: hợp lệ ({len(tasks)} tiết).')
    if only:notes.append('Chỉ Hoàn thành: từng tiết sẽ được kiểm tra đã có sổ trên điện thoại trước khi thao tác.')
    notes.append('Cần giáo viên xác nhận đúng tài khoản/năm học; phần mềm chưa tự xác minh hai thông tin này.')
    return errors,notes

def device_checks(device,stop,log,tasks,manual=False):
    if device is None:raise RuntimeError('Chưa kết nối điện thoại. Bấm Kết nối USB trước.')
    nav=Navigator(device,stop,log)
    if device.app_current().get('package')!=PACKAGE:raise RuntimeError('Hãy mở eNetViet trên điện thoại.')
    nodes=nav.nodes()
    title='Ghi sổ đầu bài' if manual else 'Sổ đầu bài giáo viên'
    if not any(label(n)==title for n in nodes):raise RuntimeError('Hãy mở màn hình '+title+' trên điện thoại rồi thử lại.')
    notes=['Đã đọc được màn hình eNetViet qua USB.']
    if not manual and tasks:
        current=week_number(nodes)
        notes.append(f"Tuần cần làm: {tasks[0]['week']}; tuần trên điện thoại: {current if current else 'chưa đọc được'}. Sẽ tự chọn lại nếu cần.")
    return notes
