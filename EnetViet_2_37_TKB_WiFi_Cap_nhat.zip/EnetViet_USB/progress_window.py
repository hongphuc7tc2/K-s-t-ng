import tkinter as tk
from tkinter import ttk
from tkinter.scrolledtext import ScrolledText
from branding import credit
import time

class ProgressWindow(tk.Toplevel):
    def __init__(self,parent,stop):
        super().__init__(parent);self.title('Tiến trình thực hiện');self.geometry('780x460')
        self.running=True;self.stop_event=stop
        credit(self)
        self.status=tk.StringVar(value='Đang bắt đầu...')
        self.label=ttk.Label(self,textvariable=self.status,font=('Segoe UI',12,'bold'),wraplength=740)
        self.label.pack(fill='x',padx=12,pady=10)
        self.bar=ttk.Progressbar(self,mode='indeterminate');self.bar.pack(fill='x',padx=12);self.bar.start(15)
        footer=ttk.Frame(self,padding=8);footer.pack(side='bottom',fill='x')
        self.stop_button=ttk.Button(footer,text='DỪNG',command=self.request_stop);self.stop_button.pack(side='left')
        ttk.Button(footer,text='Ẩn cửa sổ',command=self.withdraw).pack(side='right')
        ttk.Label(footer,text='Có thể tiếp tục xem, lọc và chọn tiết ở cửa sổ chính.').pack(side='left',padx=10)
        self.text=ScrolledText(self,wrap='word',font=('Segoe UI',10),state='disabled');self.text.pack(fill='both',expand=True,padx=12,pady=8)
        self.protocol('WM_DELETE_WINDOW',self.withdraw)
    def request_stop(self):
        self.stop_event.set();self.status.set('Đang yêu cầu dừng; chờ thao tác hiện tại kết thúc...')
    def append(self,message):
        self.status.set(message)
        self.text.configure(state='normal');self.text.insert('end',time.strftime('%H:%M:%S')+'  '+message+'\n');self.text.see('end');self.text.configure(state='disabled')
    def finish(self,result):
        self.running=False;self.bar.stop();self.stop_button.configure(state='disabled')
        state=result.get('state','ok');detail=result.get('detail','')
        title={'ok':'HOÀN THÀNH','error':'THẤT BẠI','stopped':'ĐÃ DỪNG','warning':'HOÀN TẤT — CẦN KIỂM TRA'}.get(state,'CẦN KIỂM TRA')
        self.append(title+(' — '+detail if detail else ''))
        self.label.configure(foreground='#16803c' if state=='ok' else '#b42318')
        self.title(title);self.deiconify();self.lift()
        self.protocol('WM_DELETE_WINDOW',self.destroy)
