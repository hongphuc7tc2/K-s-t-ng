import tkinter as tk
from tkinter import ttk

HELP={
'Rà soát sổ đầu bài':'Chỉ đọc các tiết theo TKB toàn bộ hồ sơ trong tuần đang chọn, thứ Hai đến thứ Bảy; kiểm tra mục thiếu, số PPCT và Hoàn thành. Không lưu hay sửa trên điện thoại.',
'Rà soát phiếu mượn':'Chỉ đọc các ngày có phiếu trong tuần; kiểm tra có mượn ít nhất một ngày và các phiếu đã có số PPCT. Bỏ Chủ Nhật. Không sao chép hoặc lưu.',
'Mượn đồ dùng (MISA)':'Sao chép phiếu mượn từ tuần mẫu hoặc chỉ cập nhật PPCT của phiếu đã có trên MISA SISAP, theo TKB trong hồ sơ.',
'Sửa hồ sơ':'Sửa thông tin giáo viên, lớp dạy, TKB và PPCT của hồ sơ đang chọn.',
'Xóa hồ sơ':'Bỏ hồ sơ khỏi danh sách; giữ bản sao trong profiles/_da_xoa. Không xóa sổ trên eNetViet.',

'Chọn tất cả':'Chọn tất cả các dòng đang hiển thị theo tuần và lớp đã lọc.',
'Bỏ chọn tất cả':'Bỏ các dấu chọn. Không xóa lịch hay nội dung đã ghi.',
'Ghi sổ đầu bài':'Ghi các dòng đã đánh dấu và in đậm. Tiết đã ghi được bỏ qua; các tiết còn lại tiếp tục thực hiện.',
'Đã ghi sổ → Chỉ Hoàn thành':'Chỉ xác nhận Hoàn thành cho các tiết đã có sổ, không nhập lại PPCT, kiểm diện, nhận xét hay điểm.',
'Chụp màn hình báo lỗi':'Tạo ZIP chứa ảnh màn hình điện thoại và dữ liệu chẩn đoán. Xem trước rồi gửi tệp để hỗ trợ.',
'Thêm PPCT HĐTN':'Chọn phân phối chương trình HĐTN cho các lớp đã khai báo ở bước tạo profile.',

'Sửa khoảng tuần':'Chọn tuần bắt đầu và kết thúc, hoặc áp dụng từ tuần bắt đầu trở đi. Lịch mới thay lịch cũ từ tuần bắt đầu.',
'Xóa TKB đang chọn':'Xóa phiên bản TKB đang xem khỏi bản nháp, không xóa sổ đã ghi trên eNetViet. Bấm Lưu hồ sơ để lưu thay đổi.',
'Cài đặt AI':'Lưu hoặc đổi model và khóa API trên máy này. Khóa được bảo vệ bởi tài khoản Windows, không xuất kèm profile.',
'Thêm TKB':'Chọn thời khóa biểu của giáo viên bằng Excel, PDF, DOCX hoặc ảnh.',
'Thêm PPCT khối':'Chọn PPCT môn học của khối/lớp thường; ghi rõ khối nếu tên file chưa rõ.',
'Thêm PPCT tích hợp':'Chọn PPCT riêng của lớp tích hợp, khác với PPCT khối thông thường.',
'Thêm PPCT TT':'Chọn PPCT riêng dành cho tiết tăng tiết của lớp tích hợp.',
'Bỏ tệp chọn':'Bỏ tệp khỏi danh sách tài liệu gửi phân tích, không xóa tệp trên máy.',
'Chọn lớp và hai tiết HĐTN':'Chọn lớp và hai ô lịch thực tế; phần mềm xếp theo thứ, buổi và tiết để ghép PPCT.',
'Bỏ lớp được chọn':'Bỏ hai ô HĐTN của lớp đang chọn khỏi bản nháp.',
'Tải PPCT HĐTN':'Chọn file PPCT HĐTN đầy đủ; phần mềm dùng hai tiết sau của mỗi tuần.',
'Phân tích PPCT':'Đọc tài liệu HĐTN bằng model và API đã lưu. Kiểm tra kết quả trước khi lưu.',
'Xuất hồ sơ gửi ChatGPT':'Xuất lịch HĐTN đã chọn, tài liệu và lệnh phân tích để dùng với ChatGPT.',
'Nhập kết quả phân tích':'Nhập file JSON phân tích HĐTN rồi xem trước lịch và tên bài.',
'Lưu HĐTN vào hồ sơ':'Lưu môn HĐTN sau khi kiểm tra; giữ các môn khác trong hồ sơ.',

'Nội dung mặc định':'Sửa kiểm diện, nhận xét, điểm Học tập, Kỷ luật và Vệ sinh riêng cho giáo viên đang chọn. Đi kèm khi xuất profile; không sửa tiết đã ghi.',
'Thêm môn HĐTN':'Chọn lớp, hai ô trên TKB và tải PPCT HĐTN. Tự thiết lập lấy tiết PPCT 2–3 mỗi tuần; không cần nhập ghi chú cho AI.',
'Thêm bài':'Thêm số PPCT và tên bài mới vào danh mục đang chỉnh. Cần Áp dụng PPCT rồi Lưu hồ sơ.',
'Sửa bài':'Sửa tên bài của dòng PPCT được chọn. Muốn chọn bài cho một tiết dạy, dùng Sửa PPCT dòng chọn ở màn hình chính.',
'Xóa bài':'Bỏ bài khỏi danh mục đang chỉnh; không xóa bản ghi trên eNetViet.',
'Ghi danh sách / Tiếp tục':'Ghi tất cả các tiết đang hiển thị theo tuần/lớp đã lọc. Tự bỏ qua tiết đã ghi; tiếp tục các tiết còn lại sau khi dừng.',
'Ghi các tiết chọn':'Chỉ ghi những dòng được chọn trong bảng. Giữ Ctrl hoặc Shift để chọn nhiều tiết. Tự bỏ qua tiết đã ghi.',
'Hoàn thành các tiết chọn':'Mở các tiết đã có bài, chọn Giáo viên xác nhận → Hoàn thành rồi lưu. Không nhập lại bài dạy, kiểm diện, nhận xét hoặc điểm.',
'Điền phiếu đang mở':'Chọn đúng một dòng và tự mở đúng phiếu trên điện thoại. Phần mềm điền và lưu ngay trên phiếu đó; không tự chọn thứ/buổi/tiết.',
'Lấy dữ liệu màn hình':'Lưu ảnh, dữ liệu giao diện và thông tin ứng dụng vào ZIP trong thư mục chan_doan để gửi hỗ trợ. Không ghi sổ.',
'Đối chiếu / sửa trạng thái các dòng chọn':'Chỉ sửa tiến độ ghi nhớ trên máy tính sau khi đã kiểm tra kết quả trên điện thoại. Không sửa dữ liệu eNetViet.',
'Chọn Hoàn thành khi ghi sổ':'Bật: ghi sổ kèm xác nhận Hoàn thành. Tắt: giữ nguyên mục xác nhận. Với tiết đã ghi, dùng nút Hoàn thành các tiết chọn.',
'Tạo hồ sơ':'Tạo hồ sơ riêng cho giáo viên: môn, lớp, TKB, PPCT và các lớp tích hợp/TT.',
'Đổi TKB':'Thay lịch theo tuần áp dụng. Có thể chọn từng ô trong bảng để sửa hoặc thêm tài liệu để AI phân tích.',
'Đổi PPCT':'Cập nhật danh mục bài dạy của từng khối/lớp tích hợp/TT; không tự đổi số tiết trong TKB.',
'Xuất hồ sơ':'Xuất hồ sơ ra ZIP để chuyển máy. Có thể kèm tiến độ đã ghi và đã Hoàn thành.',
'Nhập hồ sơ':'Nhập hồ sơ JSON/ZIP đã phân tích, kiểm tra rồi lưu. Không cần phân tích lại tài liệu nguồn.',
'Kết nối USB':'Kết nối một điện thoại qua USB. Điện thoại cần bật Gỡ lỗi USB và cấp quyền cho máy tính.',
'DỪNG':'Yêu cầu dừng ở bước kế tiếp. Nếu đang lưu, kiểm tra kết quả trên điện thoại trước khi chạy lại.',
'Phân tích bằng API AI':'Gửi tài liệu đã chọn tới Gemini/OpenAI sau khi xác nhận. Kết quả cần được giáo viên kiểm tra trước khi lưu profile.',
'Xuất bộ hồ sơ gửi ChatGPT':'Gói TKB, PPCT và yêu cầu phân tích thành ZIP để gửi ChatGPT, không cần khóa API trong phần mềm.',
'Nhập kết quả phân tích':'Nhập kết quả phân tích từ ChatGPT vào bản nháp đang sửa. Kiểm tra TKB/PPCT trước khi lưu.',
'Áp dụng PPCT đang sửa':'Ghi bảng PPCT đang chỉnh vào bản nháp. Bấm trước khi chuyển danh mục, sau đó Lưu hồ sơ để lưu xuống máy.',
'Thêm danh mục PPCT':'Tạo một danh mục mới cho khối, lớp tích hợp hoặc TT. Mã danh mục được dùng khi chọn PPCT cho các dòng TKB.',
'Tạo TKB từ tuần mới':'Tạo phiên bản lịch áp dụng từ tuần chỉ định, giữ lịch trước đó. Nếu số tiết thay đổi, đặt lại tuần mốc và PPCT đầu.',
'Xem lịch tuần':'Xem kết quả ghép TKB và PPCT của một tuần để kiểm tra trước khi lưu.',
'Lưu hồ sơ':'Lưu hồ sơ đã kiểm tra. Các chỉnh sửa PPCT cần được Áp dụng trước.',
'Thêm tiết':'Thêm một dòng TKB, sau đó chọn thứ, buổi, tiết, lớp, danh mục và mốc PPCT.',
'Xóa tiết chọn':'Bỏ dòng TKB khỏi bản nháp. Không xóa sổ đã ghi trên eNetViet.',
'Sửa PPCT dòng chọn':'Mở danh sách số PPCT và tên bài để chọn. Thay đổi chỉ dùng cho lượt hiện tại, không sửa danh mục của hồ sơ.',
}

class Tooltip:
    def __init__(self,widget,text):
        self.widget=widget;self.text=text;self.timer=None;self.win=None
        for event,fn in [('<Enter>',self.schedule),('<Leave>',self.hide),('<ButtonPress>',self.hide),('<Destroy>',self.hide)]:widget.bind(event,fn,add='+')
    def schedule(self,event=None):
        self.hide();self.timer=self.widget.after(450,self.show)
    def show(self):
        self.timer=None
        try:
            x=self.widget.winfo_rootx()+12;y=self.widget.winfo_rooty()+self.widget.winfo_height()+5
            self.win=tk.Toplevel(self.widget);self.win.wm_overrideredirect(True)
            tk.Label(self.win,text=self.text,background='#fff9d7',foreground='#222222',relief='solid',borderwidth=1,wraplength=420,justify='left',padx=10,pady=8).pack()
            self.win.update_idletasks();x=max(0,min(x,self.win.winfo_screenwidth()-self.win.winfo_reqwidth()-8));y=max(0,min(y,self.win.winfo_screenheight()-self.win.winfo_reqheight()-8))
            self.win.geometry(f'+{x}+{y}')
        except tk.TclError:pass
    def hide(self,event=None):
        try:
            if self.timer:self.widget.after_cancel(self.timer)
            if self.win:self.win.destroy()
        except tk.TclError:pass
        self.timer=None;self.win=None

def add_tooltips(parent):
    from button_signs import decorate_buttons
    decorate_buttons(parent)
    for child in parent.winfo_children():
        if isinstance(child,(ttk.Button,ttk.Checkbutton)) and not hasattr(child,'_tooltip'):
            text=getattr(child,'_plain_button_text',str(child.cget('text')));hint=HELP.get(text)
            if hint:child._tooltip=Tooltip(child,hint)
        add_tooltips(child)

def choose(parent,title,prompt,choices,current=None,editable=False):
    """Modal searchable two-column list; values retain their original types."""
    win=tk.Toplevel(parent);win.title(title);win.transient(parent);win.geometry(f'{min(900,win.winfo_screenwidth()-60)}x{min(560,win.winfo_screenheight()-120)}');result=[]
    from branding import credit
    credit(win)
    ttk.Label(win,text=prompt,wraplength=740).pack(anchor='w',padx=12,pady=8)
    query=tk.StringVar();entry=ttk.Entry(win,textvariable=query);entry.pack(fill='x',padx=12);entry._tooltip=Tooltip(entry,'Nhập một phần số hoặc tên để lọc danh sách bên dưới. Chọn đúng dòng rồi bấm Chọn.')
    ttk.Label(win,text='Gõ để lọc danh sách. Chọn một dòng rồi bấm Chọn hoặc nhấp đúp.'+(' Có thể nhập giá trị mới vào ô tìm kiếm.' if editable else '')).pack(anchor='w',padx=12,pady=5)
    # Reserve footer before the expanding list, including on high-DPI displays.
    row=ttk.Frame(win);row.pack(side='bottom',fill='x',padx=12,pady=10)
    frame=ttk.Frame(win);frame.pack(fill='both',expand=True,padx=12)
    frame.rowconfigure(0,weight=1);frame.columnconfigure(0,weight=1)
    tree=ttk.Treeview(frame,columns=('value','label'),show='headings',selectmode='browse');tree.heading('value',text='Giá trị');tree.heading('label',text='Nội dung');tree.column('value',width=120,stretch=False);tree.column('label',width=600,minwidth=600);tree.grid(row=0,column=0,sticky='nsew')
    bar=ttk.Scrollbar(frame,orient='vertical',command=tree.yview);bar.grid(row=0,column=1,sticky='ns');tree.configure(yscrollcommand=bar.set)
    horizontal=ttk.Scrollbar(frame,orient='horizontal',command=tree.xview);horizontal.grid(row=1,column=0,sticky='ew');tree.configure(xscrollcommand=horizontal.set)
    choices=list(choices)
    from tkinter import font as tkfont
    font=tkfont.Font(family='Segoe UI',size=12,weight='bold')
    tree.column('label',width=max([600]+[font.measure(str(label).replace('\n',' / '))+32 for _,label in choices]),stretch=False)
    def refresh(*args):
        from engine import normalized
        text=normalized(query.get());tree.delete(*tree.get_children())
        for i,(v,label) in enumerate(choices):
            if text and text not in normalized(str(v)+' '+str(label)):continue
            tree.insert('','end',iid=str(i),values=(v,str(label).replace('\n',' / ')))
            if str(v)==str(current):tree.selection_set(str(i));tree.see(str(i))
    def finish(event=None):
        sel=tree.selection()
        if sel:result.append(choices[int(sel[0])][0]);win.destroy()
    ttk.Button(row,text='Chọn',command=finish).pack(side='right');ttk.Button(row,text='Hủy',command=win.destroy).pack(side='right',padx=8)
    if editable:
        def new_value():
            value=query.get().strip()
            if value:result.append(value);win.destroy()
        ttk.Button(row,text='Dùng giá trị mới vừa nhập',command=new_value).pack(side='left')
    query.trace_add('write',refresh);tree.bind('<Double-1>',finish);tree.bind('<Return>',finish);win.bind('<Escape>',lambda e:win.destroy())
    refresh();previous=parent.grab_current();win.grab_set();entry.focus_set();parent.wait_window(win)
    if previous:
        try:previous.grab_set()
        except tk.TclError:pass
    return result[0] if result else None
