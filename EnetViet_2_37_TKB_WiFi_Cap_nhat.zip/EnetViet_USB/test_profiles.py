import copy
import json
import tempfile
import unittest
import uuid
import zipfile
from pathlib import Path
from profiles import default_profile,validate,plan,key,Ledger,Store
from engine import FormAssistant
import xml.etree.ElementTree as E

class ProfileTests(unittest.TestCase):
    def test_defaults_and_integrated(self):
        p=default_profile();tasks=plan(p,7)
        self.assertEqual(len(tasks),15)
        self.assertEqual([(t['period'],t['course']) for t in tasks if t['classroom']=='6A11'],[(13,'6A11'),(7,'6A11_TT'),(14,'6A11')])
        self.assertEqual(tasks[1]['title'],'Lũy thừa với số mũ tự nhiên (t1)')
    def test_separate_profiles_years_and_states(self):
        p=default_profile();t=plan(p,7)[0];other=dict(t,profile_id=str(uuid.uuid4()))
        with tempfile.TemporaryDirectory() as d:
            l=Ledger(Path(d)/'progress.json');l.mark(t,'saved');l.mark(t,'saving','complete')
            reloaded=Ledger(l.path)
            self.assertEqual(reloaded.state(t),'saved');self.assertEqual(reloaded.state(t,'complete'),'saving')
            self.assertEqual(reloaded.state(other),'pending');self.assertEqual(reloaded.state(dict(t,school_year='2027-2028')),'pending')
    def test_revision_anchor(self):
        p=default_profile();new=copy.deepcopy(p['schedules'][0]);new['from_week']=8
        for r in new['rows']:
            if r['classroom']=='6A8':r['anchor_week']=8;r['start_period']=29
        p['schedules'].append(new)
        self.assertEqual([t['period'] for t in plan(p,7) if t['classroom']=='6A8'],[25,26,27,28])
        self.assertEqual([t['period'] for t in plan(p,8) if t['classroom']=='6A8'],[29,30,31,32])
        self.assertTrue(all(t['schedule_provisional'] for t in plan(p,6)))
    def test_missing_curriculum_is_blocked(self):
        p=default_profile();p['courses']['6']['periods'].pop('25')
        self.assertFalse(next(t for t in plan(p,7) if t['classroom']=='6A8')['valid'])
    def test_collision_and_integrated_requirements(self):
        p=default_profile();p['schedules'][0]['rows'].append(copy.deepcopy(p['schedules'][0]['rows'][0]))
        with self.assertRaises(ValueError):validate(p)
        p=default_profile();p['courses']['6A11_TT']['kind']='Thường'
        with self.assertRaises(ValueError):validate(p)
    def test_package_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            store=Store(Path(d)/'profiles');p=default_profile();t=plan(p,7)[0];target=Path(d)/'share.zip'
            store.save(p);store.export(p,target,{key(t):{'write':'saved','complete':'pending'}})
            q,progress=store.read_package(target)
            self.assertEqual(q,p);self.assertEqual(progress[key(t)]['write'],'saved')
            store.export(p,target);self.assertEqual(store.read_package(target)[1],{})
    def test_reject_foreign_progress(self):
        with tempfile.TemporaryDirectory() as d:
            target=Path(d)/'bad.zip'
            with zipfile.ZipFile(target,'w') as z:
                z.writestr('profile.json',json.dumps(default_profile()));z.writestr('progress.json',json.dumps({'other':{'write':'saved'}}))
            with self.assertRaises(ValueError):Store(d).read_package(target)

class CompletionTests(unittest.TestCase):
    def runner(self,period='25'):
        r=object.__new__(FormAssistant);r.d=type('Device',(),{'app_current':lambda s:{'package':'app'}})()
        r.exact=lambda *a:None
        r.section=lambda title,nxt:[E.Element('node',text={'Lớp':'6A8','Môn học':'Toán','Tiết theo PPCT':period}[title],attrib={'resource-id':'app:id/textViewValue'})]
        r.field=lambda *a:self.fail('Completion must not write any score/remark')
        r.log=lambda *a:None;r.on_saved=lambda:None
        return r
    def test_completion_only_no_field_writes(self):
        r=self.runner();events=[];r.select_completion=lambda:events.append('complete') or True;r.save_current=lambda:events.append('save')
        r.complete_only('6A8',25);self.assertEqual(events,['complete','save'])
    def test_blank_or_wrong_period_no_completion(self):
        for value in ('Chọn tiết PPCT...','26'):
            r=self.runner(value);r.select_completion=lambda:self.fail('Must not complete mismatched PPCT')
            with self.assertRaises(RuntimeError):r.complete_only('6A8',25)
    def test_already_completed_does_not_save_again(self):
        r=self.runner();r.select_completion=lambda:False;r.save_current=lambda:self.fail('Must not save again');done=[];r.on_saved=lambda:done.append(True)
        r.complete_only('6A8',25);self.assertEqual(done,[True])
    def test_write_complete_selection_precedes_scores(self):
        r=self.runner();r.complete_after=True;events=[];r.select_completion=lambda:events.append('complete');r.field=lambda *a:events.append(a[0]);r.save_current=lambda:events.append('save')
        r.score_and_save();self.assertEqual(events,['complete','Học tập','Kỷ luật','Vệ sinh','save'])

if __name__=='__main__':unittest.main()

class EarlierWeeksTests(unittest.TestCase):
    def test_weeks_one_to_six_visible_with_provisional_schedule(self):
        p=default_profile()
        for week in range(1,7):
            tasks=plan(p,week)
            self.assertEqual(len(tasks),15)
            self.assertTrue(all(t['schedule_provisional'] for t in tasks))
            self.assertEqual([t['period'] for t in tasks if t['classroom']=='6A8'],list(range(4*week-3,4*week+1)))
            self.assertEqual([t['period'] for t in tasks if t['classroom']=='6A11'],[2*week-1,week,2*week])
        self.assertFalse(any(t['schedule_provisional'] for t in plan(p,7)))
    def test_explicit_older_schedule_takes_precedence(self):
        p=default_profile();old=copy.deepcopy(p['schedules'][0]);old['from_week']=1
        old['rows'][0]['day']=3;p['schedules'].append(old)
        tasks=plan(p,1)
        self.assertFalse(any(t['schedule_provisional'] for t in tasks))
        self.assertTrue(any(t['day']==3 and t['classroom']=='6A8' for t in tasks))
