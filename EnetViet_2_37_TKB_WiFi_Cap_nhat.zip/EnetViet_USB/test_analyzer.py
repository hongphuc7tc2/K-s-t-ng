import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from analyzer import analyze,export_request,content_for
from profiles import default_profile
import zipfile

class AnalyzerTests(unittest.TestCase):
    def test_api_response_is_draft_and_secrets_not_persisted(self):
        p=default_profile();out=dict(p,id='wrong',reviewed=True)
        class Response:
            def __enter__(self):return self
            def __exit__(self,*a):pass
            def read(self):return json.dumps({'status':'completed','output':[{'type':'message','content':[{'type':'output_text','text':json.dumps(out)}]}]}).encode()
        with patch('urllib.request.urlopen',return_value=Response()) as call:
            result=analyze(p,'TKB mới',[],'TEST-KEY','gpt-4.1')
        self.assertEqual(result['id'],p['id']);self.assertFalse(result['reviewed']);self.assertNotIn('TEST-KEY',json.dumps(result))
        payload=json.loads(call.call_args.args[0].data)
        self.assertFalse(payload['store'])
    def test_export_request_contains_sources_and_prompt(self):
        with tempfile.TemporaryDirectory() as d:
            source=Path(d)/'tkb.txt';source.write_text('Thứ 2',encoding='utf-8');target=Path(d)/'request.zip'
            export_request(default_profile(),'đổi TKB',[source],target)
            with zipfile.ZipFile(target) as z:
                self.assertIn('YEU_CAU_PHAN_TICH.txt',z.namelist());self.assertEqual(z.read('tai_lieu/1_tkb.txt').decode(),'Thứ 2')
            self.assertIn('Thứ 2',content_for(source)['text'])
