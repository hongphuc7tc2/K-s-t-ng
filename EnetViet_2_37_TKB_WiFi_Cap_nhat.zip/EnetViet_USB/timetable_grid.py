import tkinter as tk
from tkinter import ttk

def set_slot(rows,day,session,slot,selection,from_week,courses):
    matches=[r for r in rows if (r['day'],r['session'],r['slot'])==(day,session,slot)]
    if len(matches)>1:raise ValueError('Có nhiều tiết trùng giờ; sửa ở bảng chi tiết trước.')
    old=matches[0] if matches else None
    if not selection:
        if old:rows.remove(old)
        return
    room,code=selection
    group=next((r for r in rows if r['classroom']==room and r['course']==code),None)
    if old and old['classroom']==room and old['course']==code:return
    course=courses[code]
    anchor=group['anchor_week'] if group else from_week
    first=group['start_period'] if group else (course.get('taught_offsets') or [min(map(int,course.get('periods') or {'1':''}))])[0]
    new=dict(day=day,session=session,slot=slot,classroom=room,course=code,anchor_week=anchor,start_period=first)
    if old:old.update(new)
    else:rows.append(new)

class TimetableGrid(ttk.Frame):
    def __init__(self,parent,editor):
        super().__init__(parent);self.editor=editor;self.active=None
        bar=ttk.Frame(self);bar.pack(fill='x')
        ttk.Label(bar,text='Chọn lớp / loại tiết tại ô. Delete/Backspace để xóa. Nhóm mới: kiểm tra mốc PPCT ở Chi tiết.').pack(side='left')
        ttk.Button(bar,text='Xóa ô chọn',command=self.delete).pack(side='right')
        self.canvas=tk.Canvas(self,highlightthickness=0);self.canvas.pack(side='left',fill='both',expand=True)
        scroll=ttk.Scrollbar(self,orient='vertical',command=self.canvas.yview);scroll.pack(side='right',fill='y');self.canvas.configure(yscrollcommand=scroll.set)
        self.body=ttk.Frame(self.canvas);self.window=self.canvas.create_window(0,0,window=self.body,anchor='nw')
        self.body.bind('<Configure>',lambda e:self.canvas.configure(scrollregion=self.canvas.bbox('all')))
        self.canvas.bind('<Configure>',lambda e:self.canvas.itemconfigure(self.window,width=e.width))
        from mousewheel import bind_form_wheel
        self.refresh_wheel=bind_form_wheel(self.canvas,self.body)
    def delete(self,event=None):
        if self.active:self.apply(*self.active,None)
        return 'break'
    def apply(self,day,session,slot,selection):
        rev=self.editor.revision()
        if not rev:return
        try:set_slot(rev['rows'],day,session,slot,selection,rev['from_week'],self.editor.p['courses'])
        except ValueError as exc:
            from tkinter import messagebox
            messagebox.showerror('TKB',str(exc),parent=self);return
        self.editor.reviewed.set(False);self.editor.show_rows()
    def render(self):
        for w in self.body.winfo_children():w.destroy()
        rev=self.editor.revision();p=self.editor.p
        rooms=sorted(set(p.get('declared_classes',[]))|{r['classroom'] for v in p.get('schedules',[]) for r in v['rows']})
        choices={'— Trống —':None}
        for room in rooms:
            for code,c in p.get('courses',{}).items():choices[f"{room} · {c.get('name',code)} [{code}]"]=(room,code)
        ttk.Label(self.body,text='Buổi / tiết',anchor='center').grid(row=0,column=0,sticky='nsew',padx=2,pady=4)
        for d in range(2,8):
            self.body.columnconfigure(d-1,weight=1,uniform='days')
            ttk.Label(self.body,text={2:'Thứ Hai',3:'Thứ Ba',4:'Thứ Tư',5:'Thứ Năm',6:'Thứ Sáu',7:'Thứ Bảy'}[d],anchor='center',font=('Segoe UI',11,'bold')).grid(row=0,column=d-1,sticky='nsew',padx=2,pady=4)
        for i,(session,slot) in enumerate((s,k) for s in ('Sáng','Chiều') for k in range(1,6)):
            row=i+1;color='#edf6ff' if session=='Sáng' else '#fff7e9'
            tk.Label(self.body,text=f'{session}\nTiết {slot}',bg=color).grid(row=row,column=0,sticky='nsew',padx=1,pady=1)
            for d in range(2,8):
                frame=tk.Frame(self.body,bg=color,bd=1,relief='solid');frame.grid(row=row,column=d-1,sticky='nsew',padx=1,pady=1)
                box=ttk.Combobox(frame,values=list(choices),state='readonly',width=13,height=15);box.pack(fill='both',expand=True,padx=3,pady=10)
                found=[r for r in (rev['rows'] if rev else []) if (r['day'],r['session'],r['slot'])==(d,session,slot)]
                pair=(found[0]['classroom'],found[0]['course']) if len(found)==1 else None
                box.set(next((k for k,v in choices.items() if v==pair),'— Trống —') if len(found)<2 else 'Trùng giờ!')
                key=(d,session,slot)
                box.bind('<FocusIn>',lambda e,k=key:setattr(self,'active',k))
                box.bind('<<ComboboxSelected>>',lambda e,k=key,b=box:self.apply(*k,choices[b.get()]))
                box.bind('<Delete>',lambda e,k=key:self.clear_key(k));box.bind('<BackSpace>',lambda e,k=key:self.clear_key(k))
        self.refresh_wheel()
    def clear_key(self,key):
        self.active=key;return self.delete()
