from branding import credit
from onboarding import ProfileWizard, select_teacher, profile_names
from table_sort import TimetableSort
from timetable import DAYS, SESSIONS
import copy
import json
import queue
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
from legacy_app import App as BaseApp, ROOT
from engine import FormAssistant
from defaults import edit_defaults, describe_defaults
from navigator import Navigator
from profiles import Store, Ledger, default_profile, plan, key, atomic_json
from profile_ui import ProfileEditor, empty_profile
from widgets import choose, add_tooltips

STATES={'pending':'Chưa xong','working':'Đang làm','saving':'Cần kiểm tra','saved':'Đã xong','skipped':'Đã làm thủ công'}

class App(BaseApp):
    def __init__(self,root):
        self.root=root;self.d=None;self.busy=False;self.tasks=[]
        self.stop=threading.Event();self.events=queue.Queue()
        self.store=Store(ROOT/'profiles');self.ledger=Ledger(ROOT/'tien_do_profiles.json')
        import tkinter.font as tkfont
        tkfont.nametofont('TkDefaultFont').configure(family='Segoe UI',size=11)
        tkfont.nametofont('TkTextFont').configure(family='Segoe UI',size=11)
        style=ttk.Style(root)
        style.configure('Treeview',font=('Segoe UI',11),rowheight=32)
        style.map('Treeview',background=[('selected','#b6d6fa')],foreground=[('selected','#172b3a')])
        style.configure('Treeview.Heading',font=('Segoe UI',11,'bold'))
        style.configure('TButton',font=('Segoe UI',11),padding=(8,6))
        style.configure('Primary.TButton',font=('Segoe UI',12,'bold'),padding=(14,10))
        root.option_add('*TCombobox*Listbox.font',('Segoe UI',12))
        root.withdraw()
        selected=select_teacher(root,self.store)
        if selected is None:root.destroy();return
        self.profiles=self.store.list();self.profile=next(p for p in self.profiles if p['id']==selected)
        root.deiconify()
        self.migrate_old()
        self.week=tk.StringVar(value='7');self.classroom=tk.StringVar(value='Tất cả');self.profile_name=tk.StringVar()
        self.status=tk.StringVar(value='Chưa kết nối USB');self.complete_after=tk.BooleanVar(value=False)
        self.tt_type=tk.StringVar()
        root.title('eNetViet USB 2.37 — Hồ sơ giáo viên');root.geometry(f"{min(1360,root.winfo_screenwidth()-40)}x{min(900,root.winfo_screenheight()-80)}")
        credit(root)
        wrap=ttk.Frame(root,padding=10);wrap.pack(fill='both',expand=True)
        row=ttk.Frame(wrap);row.pack(fill='x',pady=5)
        ttk.Label(row,text='Giáo viên').pack(side='left')
        self.profilebox=ttk.Combobox(row,textvariable=self.profile_name,state='readonly',width=24);self.profilebox.pack(side='left',padx=6);self.profilebox.bind('<<ComboboxSelected>>',self.switch_profile)
        for title,fn in [('Tạo hồ sơ',lambda:self.edit_profile('Tạo hồ sơ',True)),('Đổi PPCT',lambda:self.edit_profile('Đổi PPCT')),('Xuất hồ sơ',self.export_profile),('Nhập hồ sơ',self.import_profile)]:ttk.Button(row,text=title,command=fn).pack(side='left',padx=2)
        tk.Button(row,text='SỬA TKB',command=lambda:self.edit_profile('Đổi TKB'),bg='#1565c0',fg='white',font=('Segoe UI',12,'bold'),padx=14,pady=5).pack(side='left',padx=6)
        manage=ttk.Frame(wrap);manage.pack(fill='x')
        ttk.Button(manage,text='Sửa hồ sơ',command=lambda:self.edit_profile('Sửa hồ sơ')).pack(side='left',padx=3)
        ttk.Button(manage,text='Xóa hồ sơ',command=self.delete_profile).pack(side='left',padx=3)
        ttk.Button(manage,text='Tiếp tục bản nháp',command=self.resume_work).pack(side='left',padx=3)
        ttk.Button(manage,text='Sao lưu hồ sơ',command=self.backup_profile).pack(side='left',padx=3)
        from updates import configure as configure_updates
        ttk.Button(manage,text='Cài đặt cập nhật',command=lambda:configure_updates(self)).pack(side='left',padx=3)
        ttk.Button(manage,text='Khôi phục sao lưu',command=self.restore_backup).pack(side='left',padx=3)
        ttk.Label(wrap,text='Mở đúng tài khoản eNetViet và màn hình Sổ đầu bài giáo viên. Phần mềm tự chọn tuần khi chạy theo TKB. Chọn hồ sơ không tự đổi tài khoản.').pack(anchor='w',pady=5)
        row=ttk.Frame(wrap);row.pack(fill='x')
        ttk.Label(row,text='Tuần').pack(side='left');box=ttk.Combobox(row,textvariable=self.week,values=list(range(1,54)),width=5,state='readonly');box.pack(side='left',padx=5);box.bind('<<ComboboxSelected>>',self.refresh)
        ttk.Label(row,text='Lớp').pack(side='left');self.classbox=ttk.Combobox(row,textvariable=self.classroom,width=12,state='readonly');self.classbox.pack(side='left',padx=5);self.classbox.bind('<<ComboboxSelected>>',self.refresh)
        row=ttk.Frame(wrap);row.pack(fill='x',pady=3)
        ttk.Button(row,text='Kết nối USB',command=lambda:self.run(self.connect)).pack(side='left',padx=5)
        from wifi_connection import open_wifi
        ttk.Button(row,text='Kết nối Wi-Fi',command=lambda:open_wifi(self)).pack(side='left',padx=4)
        ttk.Button(row,text='Thêm môn HĐTN',command=self.add_hdtn).pack(side='left',padx=10)
        ttk.Button(row,text='Nội dung mặc định',command=self.edit_write_defaults).pack(side='left',padx=5)
        ttk.Button(row,text='Cài đặt AI',command=self.ai_settings).pack(side='left',padx=5)
        ttk.Button(row,text='Xem tiến trình',command=self.show_progress).pack(side='right',padx=4)
        ttk.Button(row,text='DỪNG',command=self.stop.set).pack(side='right')
        row=ttk.Frame(wrap);row.pack(fill='x',pady=6)
        self.completion_box=tk.Frame(row,bg='#fff1c2',bd=2,relief='groove');self.completion_box.pack(side='left',padx=4,pady=4)
        self.completion_check=tk.Checkbutton(self.completion_box,text='Tự động bấm Hoàn thành khi ghi sổ',variable=self.complete_after,font=('Segoe UI',12,'bold'),bg='#fff1c2',activebackground='#fff1c2',selectcolor='white',padx=10,pady=8)
        self.completion_check.pack()
        self.completion_label=tk.Label(self.completion_box,text='',font=('Segoe UI',10),bg='#fff1c2');self.completion_label.pack(pady=(0,5))
        def completion_status(*args):
            on=self.complete_after.get();color='#d5f2dc' if on else '#fff1c2'
            self.completion_box.configure(bg=color);self.completion_check.configure(bg=color,activebackground=color)
            self.completion_label.configure(bg=color,text='ĐANG BẬT — Ghi sổ và chọn Hoàn thành' if on else 'ĐANG TẮT — Giữ nguyên mục xác nhận')
        self.complete_after.trace_add('write',completion_status);completion_status()
        from widgets import Tooltip, HELP
        self.completion_check._tooltip=Tooltip(self.completion_check,HELP['Chọn Hoàn thành khi ghi sổ'])
        ttk.Label(row,text='Kiểu giảng dạy TT (nếu cần thay):').pack(side='left',padx=12);ttk.Entry(row,textvariable=self.tt_type,width=22).pack(side='left')
        columns=['pick','write','complete','day','session','slot','classroom','kind','period','title']
        self.table_frame=ttk.Frame(wrap)
        self.table=ttk.Treeview(self.table_frame,columns=columns,show='headings',height=8,selectmode='extended')
        for col,title,width in zip(columns,['Chọn','Ghi sổ','Hoàn thành','Thứ','Buổi','Tiết','Lớp','Môn/TT','PPCT','Bài dạy'],[55,110,110,90,95,40,75,85,60,380]):self.table.heading(col,text=title);self.table.column(col,width=width,stretch=col=='title')
        self.sorter=TimetableSort(self.table,lambda:{key(t):t for t in self.tasks},subject_column='kind')
        self.table_frame.rowconfigure(0,weight=1);self.table_frame.columnconfigure(0,weight=1)
        self.table.grid(row=0,column=0,sticky='nsew');self.table.bind('<Button-1>',self.toggle_row)
        self.table.bind('<space>',self.toggle_focused)
        self.table.bind('<<TreeviewSelect>>',lambda e:self.paint_selection())
        self.table.tag_configure('chosen',font=('Segoe UI',12,'bold'),foreground='#0b2545')
        bar=ttk.Scrollbar(self.table_frame,orient='horizontal',command=self.table.xview);self.hscroll=bar;self.table.configure(xscrollcommand=bar.set)
        vertical=ttk.Scrollbar(self.table_frame,orient='vertical',command=self.table.yview);vertical.grid(row=0,column=1,sticky='ns');self.table.configure(yscrollcommand=vertical.set);self.vscroll=vertical
        row=ttk.Frame(wrap);row.pack(fill='x',pady=7)
        ttk.Button(row,text='Chọn tất cả',command=lambda:self.select_rows(True)).pack(side='left',padx=3)
        ttk.Button(row,text='Bỏ chọn tất cả',command=lambda:self.select_rows(False)).pack(side='left',padx=3)
        self.selection_count=tk.StringVar(value='Đã chọn 0 tiết')
        ttk.Label(row,textvariable=self.selection_count,font=('Segoe UI',12,'bold')).pack(side='left',padx=12)
        ttk.Button(row,text='Kiểm tra trước khi chạy',command=self.preflight).pack(side='left',padx=3)
        ttk.Button(row,text='Ghi sổ đầu bài',command=lambda:self.start_batch(True),style='Primary.TButton').pack(side='left',padx=10)
        ttk.Button(row,text='Đã ghi sổ → Chỉ Hoàn thành',command=lambda:self.start_batch(True,True)).pack(side='left',padx=3)
        row=ttk.Frame(wrap);row.pack(fill='x',pady=4)
        ttk.Button(row,text='Điền phiếu đang mở',command=self.fill).pack(side='left',padx=3)
        ttk.Button(row,text='Chụp màn hình báo lỗi',command=lambda:self.run(self.capture)).pack(side='left',padx=3)
        from borrow_ui import open_borrow
        ttk.Button(row,text='Mượn đồ dùng (MISA)',command=lambda:open_borrow(self)).pack(side='left',padx=8)
        row=ttk.Frame(wrap);row.pack(fill='x')
        from audit_ui import start_audit
        ttk.Button(row,text='Rà soát sổ đầu bài',command=lambda:start_audit(self,'notebook')).pack(side='left',padx=4)
        ttk.Button(row,text='Rà soát phiếu mượn',command=lambda:start_audit(self,'borrow')).pack(side='left',padx=4)
        row=ttk.Frame(wrap);row.pack(fill='x')
        ttk.Button(row,text='Đối chiếu / sửa trạng thái các dòng chọn',command=self.resolve).pack(side='left')
        ttk.Button(row,text='Sửa PPCT dòng chọn',command=self.edit_period).pack(side='left',padx=6)
        row=ttk.Frame(wrap);row.pack(fill='x')
        ttk.Label(row,text='Thứ ⇅: xếp theo thời gian • Lớp ⇅: theo lớp • Môn ⇅: theo môn • ▲: đang chọn. Bấm để chọn/bỏ chọn; Shift + bấm để chọn một dải.').pack(side='left',padx=6)
        self.table_frame.pack(fill='both',expand=True,pady=5);self.hscroll.grid(row=1,column=0,sticky='ew')
        self.table.bind('<Configure>',self.fit_lesson_titles,add='+')
        ttk.Label(wrap,textvariable=self.status,wraplength=1230).pack(anchor='w',pady=5)
        self.logbox=tk.Text(wrap,height=4,wrap='word',state='disabled');self.logbox.pack(fill='both',expand=True)
        add_tooltips(wrap)
        self.reload_profiles(self.profile['id']);root.after(100,self.poll)
        from updates import start_check
        root.after(1500,lambda:start_check(self))
        from status_cells import StatusCells
        self.status_cells=StatusCells(self)
        root.protocol('WM_DELETE_WINDOW',self.close)
    def fit_lesson_titles(self,event=None):
        # Keep long lesson names reachable using the horizontal scrollbar.
        from tkinter import font as tkfont
        font=tkfont.Font(family='Segoe UI',size=12,weight='bold')
        width=max([380]+[font.measure(str(self.table.set(i,'title')))+32 for i in self.table.get_children()])
        self.table.column('title',width=width,minwidth=width,stretch=False)
    def close(self):
        if self.busy:
            self.stop.set();messagebox.showinfo('Đang dừng','Chờ nhật ký báo dừng rồi đóng cửa sổ.');return
        self.root.destroy()
    def migrate_old(self):
        marker=ROOT/'da_chuyen_tien_do_2_0.txt';old=ROOT/'tien_do_tuan.json'
        if marker.exists() or not old.exists():return
        p=default_profile()
        for k,v in json.loads(old.read_text(encoding='utf-8')).items():
            parts=k.split('|')
            if len(parts)==7:
                year,w,day,session,slot,cls,kind=parts
                newkey='|'.join([p['id'],year,w,day,session,slot,cls,p['subject']])
                self.ledger.data.setdefault(newkey,{'write':v.get('state','pending'),'complete':'pending','period':v.get('period')})
        atomic_json(self.ledger.path,self.ledger.data);marker.write_text('done',encoding='utf-8')
    def reload_profiles(self,selected_id):
        self.profiles=self.store.list();self.profilebox['values']=profile_names(self.profiles)
        i=next((i for i,p in enumerate(self.profiles) if p['id']==selected_id),0);self.profilebox.current(i);self.profile=self.profiles[i]
        self.classbox['values']=['Tất cả']+sorted({r['classroom'] for s in self.profile['schedules'] for r in s['rows']});self.classroom.set('Tất cả');self.refresh()
    def switch_profile(self,event=None):
        if self.busy:
            self.profilebox.current(next(i for i,p in enumerate(self.profiles) if p['id']==self.profile['id']));return
        self.reload_profiles(self.profiles[self.profilebox.current()]['id']);self.complete_after.set(False);self.tt_type.set('')
    def edit_profile(self,mode,new=False):
        if self.busy and new:return
        def saved(p):self.store.save(p);self.reload_profiles(p['id'])
        def ready(p):
            editor=ProfileEditor(self.root,p,saved,'Tải TKB và PPCT' if new else mode)
            if mode=='Đổi TKB':editor.book.select(1)
        if new:ProfileWizard(self.root,ready)
        else:ready(self.profile)
    def resume_work(self):
        if self.busy:return
        from drafts import resume_draft
        def saved(p):self.store.save(p);self.reload_profiles(p['id'])
        resume_draft(self.root,saved)
    def backup_profile(self):
        if self.busy:return
        try:
            path=self.store.backup(self.profile)
            messagebox.showinfo('Đã sao lưu','Đã sao lưu hồ sơ và tiến độ:\n'+str(path))
        except Exception as e:messagebox.showerror('Sao lưu',str(e))
    def restore_backup(self):
        self.import_profile(backup=True)
    def delete_profile(self):
        if self.busy:return
        if not messagebox.askyesno('Xóa hồ sơ giáo viên','Xóa hồ sơ '+self.profile['name']+' khỏi danh sách?\nBản sao được giữ trong thư mục profiles/_da_xoa. Không xóa sổ trên eNetViet hoặc tiến độ đã lưu.'):return
        try:self.store.delete(self.profile['id'])
        except Exception as e:messagebox.showerror('Không xóa được',str(e));return
        remaining=self.store.list()
        if remaining:self.reload_profiles(remaining[0]['id'])
        else:
            selected=select_teacher(self.root,self.store)
            if selected is None:self.root.destroy();return
            self.reload_profiles(selected)
        self.complete_after.set(False)
    def add_hdtn(self):
        if self.busy:return
        from hdtn import HdtnWizard
        def saved(p):self.store.save(p);self.reload_profiles(p['id'])
        HdtnWizard(self.root,self.profile,saved)
    def ai_settings(self):
        if self.busy:return
        from ai_settings import configure
        configure(self.root,'Gemini')
    def edit_write_defaults(self):
        if self.busy:return
        def saved(p):
            self.store.save(p);self.reload_profiles(p['id'])
            self.log('Đã lưu nội dung ghi sổ mặc định cho '+p['name'])
        edit_defaults(self.root,self.profile,saved)
    def export_profile(self):
        if self.busy:return
        target=filedialog.asksaveasfilename(defaultextension='.zip',initialfile='Profile_giao_vien.zip')
        if not target:return
        include=messagebox.askyesno('Kèm tiến độ','Kèm tiến độ đã ghi/hoàn thành để chuyển sang máy khác và tiếp tục?')
        self.store.export(self.profile,target,self.ledger.data if include else None);self.log('Đã xuất hồ sơ: '+target)
    def import_profile(self,backup=False):
        if self.busy:return
        path=filedialog.askopenfilename(initialdir=str(ROOT/'sao_luu') if backup else None,filetypes=[('Hồ sơ','*.zip *.json')])
        if not path:return
        try:
            p,progress=self.store.read_package(path)
            if any(x['id']==p['id'] for x in self.profiles) and not messagebox.askokcancel('Cập nhật hồ sơ','Hồ sơ này đã có. Thay TKB/PPCT bằng bản vừa nhập?'):return
            def saved(reviewed):
                existing=next((p for p in self.store.list() if p['id']==reviewed['id']),None)
                if existing:self.store.backup(existing)
                self.store.save(reviewed)
                if progress and messagebox.askyesno('Nhập tiến độ','Nhập tiến độ đi kèm? Các mục trùng sẽ dùng trạng thái từ gói nhập; hãy chọn bản mới nhất.'):
                    self.ledger.data.update(progress);atomic_json(self.ledger.path,self.ledger.data)
                self.reload_profiles(reviewed['id'])
            editor=ProfileEditor(self.root,p,saved,'Kiểm tra hồ sơ nhập');editor.grab_set()
        except Exception as e:messagebox.showerror('Hồ sơ',str(e))
    def refresh(self,event=None):
        try:self.tasks=[t for t in plan(self.profile,int(self.week.get())) if self.classroom.get() in ('Tất cả',t['classroom'])]
        except Exception as e:self.tasks=[];self.status.set(str(e))
        if self.tasks:
            if self.tasks[0].get('schedule_provisional'):
                self.status.set(f"Tuần {self.week.get()}: tạm hiển thị theo TKB từ tuần {self.tasks[0]['schedule_from_week']}. Kiểm tra lịch cũ trước khi chạy; nếu khác, bấm Đổi TKB.")
            else: self.status.set(f"Đang hiển thị tuần {self.week.get()} theo TKB tuần {self.tasks[0]['schedule_from_week']}–{self.tasks[0]['schedule_to_week']}.")
        self.redraw()
    def redraw(self):
        selected=self.table.selection();self.table.delete(*self.table.get_children())
        for t in self.tasks:
            values=['☐']+[STATES[self.ledger.state(t,m)] for m in ('write','complete')]+[DAYS[t['day']],SESSIONS[t['session']],t['slot'],t['classroom'],t['kind'],t['period']]+[t['title'].replace('\n',' / ')]
            self.table.insert('','end',iid=key(t),values=values)
        self.sorter.apply()
        self.table.selection_set([k for k in selected if self.table.exists(k)])
        self.paint_selection()
        self.fit_lesson_titles()
    def paint_selection(self):
        selected=set(self.table.selection())
        for iid in self.table.get_children():
            self.table.set(iid,'pick','▶ ☑' if iid in selected else '☐')
            if hasattr(self.table,'tag_configure'):
                shades=tuple(t for t in self.table.item(iid,'tags') if t.startswith('shade_'))
            else:shades=()
            self.table.item(iid,tags=(('chosen',) if iid in selected else ())+shades)
        if hasattr(self,'status_cells'):self.status_cells.invalidate()
        if hasattr(self,'selection_count'):self.selection_count.set(f'Đã chọn {len(selected)} / {len(self.tasks)} tiết')
    def select_rows(self,all_rows):
        self.selection_anchor=None
        self.table.selection_set(self.table.get_children() if all_rows else ())
        self.paint_selection()
    def toggle_row(self,event):
        if self.table.identify_region(event.x,event.y)!='cell':return
        iid=self.table.identify_row(event.y)
        if iid:
            state=getattr(event,'state',0)
            rows=list(self.table.get_children())
            anchor=getattr(self,'selection_anchor',None)
            if state & 0x0001 and anchor in rows:
                start,end=sorted((rows.index(anchor),rows.index(iid)))
                chosen=rows[start:end+1]
                if state & 0x0004:chosen=list(set(self.table.selection()).union(chosen))
                self.table.selection_set(chosen)
            else:
                if iid in self.table.selection():self.table.selection_remove(iid)
                else:self.table.selection_add(iid)
                self.selection_anchor=iid
            self.table.focus(iid);self.table.focus_set();self.paint_selection()
        return 'break'
    def toggle_focused(self,event):
        iid=self.table.focus()
        if iid:
            if iid in self.table.selection():self.table.selection_remove(iid)
            else:self.table.selection_add(iid)
            self.paint_selection()
        return 'break'
    def show_progress(self):
        win=getattr(self,'progress_window',None)
        if win and win.winfo_exists():win.deiconify();win.lift()
    def run(self,fn):
        if self.busy:
            self.show_progress();return
        from progress_window import ProgressWindow
        self.busy=True;self.stop.clear()
        self._run_defaults=copy.deepcopy(self.profile.get('write_defaults'))
        self.progress_window=ProgressWindow(self.root,self.stop)
        def worker():
            result={'state':'ok','detail':'Đã thực hiện xong.'}
            try:
                value=fn()
                if isinstance(value,dict) and 'state' in value:result=value
                if self.stop.is_set():result={'state':'stopped','detail':'Đã dừng theo yêu cầu.'}
            except Exception as exc:
                result={'state':'stopped' if self.stop.is_set() else 'error','detail':str(exc)}
                self.log('DỪNG: '+str(exc))
            finally:self.events.put(('done',result))
        threading.Thread(target=worker,daemon=True).start()
    def poll(self):
        try:
            while True:
                kind,value=self.events.get_nowait()
                if kind=='done':
                    self.busy=False;self.redraw()
                    if getattr(self,'progress_window',None):self.progress_window.finish(value or {'state':'ok'})
                    if getattr(self,'_pending_update',None):
                        from updates import launch_install
                        try:launch_install(self,self._pending_update);return
                        except Exception as exc:
                            self._pending_update=None;messagebox.showerror('Cập nhật',str(exc))
                elif kind=='update_staged':
                    self._pending_update=value
                elif kind=='update_result':
                    from updates import offer_update
                    offer_update(self,value)
                elif kind=='audit_result':
                    from audit_ui import show_audit
                    show_audit(self.root,*value)
                elif kind=='preflight_ok':messagebox.showinfo('Kết quả kiểm tra',value)
                elif kind=='preflight_error':messagebox.showwarning('Chưa thể chạy',value)
                else:
                    if getattr(self,'progress_window',None) and self.progress_window.winfo_exists() and self.progress_window.running:self.progress_window.append(value)
                    self.status.set(value);self.logbox.configure(state='normal');self.logbox.insert('end',time.strftime('%H:%M:%S')+'  '+value+'\n');self.logbox.see('end');self.logbox.configure(state='disabled')
        except queue.Empty:pass
        self.root.after(100,self.poll)
    def chosen(self):return [t for t in self.tasks if key(t) in self.table.selection()]
    def edit_period(self,event=None):
        if event is not None and self.table.identify_region(event.x,event.y)!='cell':return
        if self.busy or len(self.chosen())!=1:return
        t=self.chosen()[0];course=self.profile['courses'][t['course']]
        n=choose(self.root,'Chọn PPCT',f"{t['classroom']} • {course['name']} — chọn số và tên bài:",[(int(n),title) for n,title in sorted(course['periods'].items(),key=lambda x:int(x[0]))],t['period'])
        if n is None:return
        if str(n) not in course['periods']:messagebox.showerror('PPCT','Số này không có trong danh mục.');return
        t.update(period=n,title=course['periods'][str(n)],valid=True,expected_title=course['periods'][str(n)] if course.get('exact_title',True) else None);self.redraw()
    def resolve(self):
        if self.busy or not self.chosen():return
        win=tk.Toplevel(self.root);win.title('Đối chiếu kết quả trên điện thoại');win.grab_set()
        mode=tk.StringVar(value='write');state=tk.StringVar(value='saved')
        ttk.Label(win,text='Chỉ thay trạng thái sau khi đã kiểm tra trên eNetViet.').pack(padx=20,pady=10)
        for text,value in [('Ghi sổ','write'),('Hoàn thành','complete')]:ttk.Radiobutton(win,text=text,variable=mode,value=value).pack(anchor='w',padx=20)
        for text,value in [('Đã làm thành công','saved'),('Chưa làm / cho phép chạy lại','pending')]:ttk.Radiobutton(win,text=text,variable=state,value=value).pack(anchor='w',padx=20)
        def save():
            for t in self.chosen():self.ledger.mark(t,state.get(),mode.get())
            win.destroy();self.redraw()
        ttk.Button(win,text='Cập nhật trạng thái',command=save).pack(pady=10)
    def execute(self,t,subjects,complete=False,only=False):
        modes=['complete'] if only else ['write']+(['complete'] if complete else [])
        def mark(state):
            for mode in modes:self.ledger.mark(t,state,mode)
        mark('working')
        runner=FormAssistant(self.d,self.stop,self.log,before_save=lambda:mark('saving'),on_saved=lambda:mark('saved'),complete_after=complete,write_defaults=getattr(self,'_run_defaults',self.profile.get('write_defaults')))
        if only:runner.complete_only(t['classroom'],t['period'],subjects)
        else:runner.fill(t['classroom'],t['period'],expected_title=t['expected_title'],subjects=subjects)
    def preflight(self):
        if self.busy:return
        from preflight import data_checks,device_checks
        tasks=[dict(t) for t in self.chosen()];errors,notes=data_checks(self.profile,tasks,self.ledger)
        if errors:messagebox.showwarning('Cần sửa trước khi chạy','\n'.join(errors));return
        def check():
            try:result=notes+device_checks(self.d,self.stop,self.log,tasks)
            except Exception as e:self.events.put(('preflight_error',str(e)));raise
            self.events.put(('preflight_ok','\n'.join(result)))
        self.run(check)
    def start_batch(self,selected_only,only=False):
        if self.busy:return
        if selected_only and not self.chosen():
            messagebox.showinfo('Chưa chọn tiết','Bấm vào các dòng cần làm hoặc bấm Chọn tất cả, rồi bấm nút thực hiện.');return
        mode='complete' if only else 'write';complete=self.complete_after.get() and not only
        tasks=[dict(t) for t in (self.chosen() if selected_only else self.tasks)]
        if any(self.ledger.state(t,m)=='saving' for t in tasks for m in ('write','complete')):
            messagebox.showwarning('Cần kiểm tra','Có tiết chưa rõ kết quả lưu. Đối chiếu trên điện thoại và sửa trạng thái trước khi chạy.');return
        tasks=[t for t in tasks if self.ledger.state(t,mode) not in ('saved','skipped')]
        if not tasks:messagebox.showinfo('Danh sách','Không có tiết cần chạy. Các tiết đã ghi muốn Hoàn thành thêm: dùng nút Đã ghi sổ → Chỉ Hoàn thành.');return
        if any(not t['valid'] for t in tasks):messagebox.showerror('Thiếu PPCT','Cập nhật PPCT hoặc sửa số tiết trước khi chạy.');return
        if any(t.get('schedule_provisional') for t in tasks):
            if not messagebox.askokcancel('Xác nhận TKB tuần cũ',f"Tuần {tasks[0]['week']} chưa có TKB riêng. Bảng đang dùng tạm TKB từ tuần {tasks[0]['schedule_from_week']}.\nThầy xác nhận các thứ/buổi/tiết và lớp được chọn cũng đúng với tuần cũ này?\nNếu khác, bấm Hủy rồi Đổi TKB để thêm lịch tuần cũ."):return
        action_text='Chỉ xác nhận Hoàn thành; giữ nguyên nội dung đã ghi.' if only else describe_defaults(self.profile.get('write_defaults'))+'\n'+('chọn Hoàn thành.' if complete else 'giữ nguyên mục xác nhận.')
        if not messagebox.askokcancel('Chạy các tiết',f"GV: {self.profile['name']} • {len(tasks)} tiết\n{action_text}\nĐã mở đúng tài khoản và kiểm tra lịch/PPCT? Phần mềm sẽ tự chọn tuần trên điện thoại. Sẽ lưu thay đổi."):return
        from preflight import data_checks,device_checks
        errors,notes=data_checks(self.profile,tasks,self.ledger,only)
        if errors:messagebox.showwarning('Cần sửa trước khi chạy','\n'.join(errors));return
        tt=self.tt_type.get()
        def action():
            self.require_device();nav=Navigator(self.d,self.stop,self.log)
            nav.ensure_main()
            device_checks(self.d,self.stop,self.log,tasks)
            self.log('Kiểm tra trước khi chạy: đạt. Bắt đầu các tiết đã chọn.')
            self.require_device();nav=Navigator(self.d,self.stop,self.log)
            for t in tasks:
                nav.check();self.log(f"{DAYS[t['day']]} {SESSIONS[t['session']]} tiết {t['slot']} • {t['classroom']} • PPCT {t['period']}")
                nav.open_task(t,existing_only=only)
                subjects=nav.subjects(t) if only else nav.prepare_form(t,tt)
                self.execute(t,subjects,complete,only);nav.return_after_saved()
            self.log('Đã xong danh sách.')
        self.run(action)
    def fill(self):
        if self.busy or len(self.chosen())!=1:return
        t=dict(self.chosen()[0]);complete=self.complete_after.get();tt=self.tt_type.get()
        if not t['valid'] or self.ledger.state(t,'write') in ('saving','saved','skipped') or self.ledger.state(t,'complete')=='saving':messagebox.showinfo('Kiểm tra','Kiểm tra PPCT và trạng thái trước khi điền lại.');return
        if not messagebox.askokcancel('Phiếu đang mở',f"Đã mở đúng tuần {t['week']}, {DAYS[t['day']]} {SESSIONS[t['session']]} tiết {t['slot']}, lớp {t['classroom']}?\n{describe_defaults(self.profile.get('write_defaults'))}\nChế độ này không kiểm tra ngày/buổi. Sẽ lưu"+(' và chọn Hoàn thành.' if complete else '.')):return
        from preflight import data_checks,device_checks
        errors,_=data_checks(self.profile,[t],self.ledger)
        if errors:messagebox.showwarning('Cần kiểm tra','\n'.join(errors));return
        def action():
            device_checks(self.d,self.stop,self.log,[t],manual=True)
            self.require_device();nav=Navigator(self.d,self.stop,self.log);self.execute(t,nav.prepare_form(t,tt),complete)
        self.run(action)

if __name__=='__main__':
    root=tk.Tk();App(root);root.mainloop()
