import json
import os
import queue
import threading
import time
import zipfile
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox
from engine import FormAssistant

ROOT = Path(__file__).resolve().parent
if (ROOT / 'platform-tools' / 'adb.exe').exists():
    os.environ['ADBUTILS_ADB_PATH'] = str(ROOT / 'platform-tools' / 'adb.exe')
DATA = json.loads((ROOT / 'ppct.json').read_text(encoding='utf-8'))


class App:
    def __init__(self, root):
        self.root = root
        self.d = None
        self.busy = False
        self.stop = threading.Event()
        self.events = queue.Queue()
        self.week = tk.StringVar(value='6')
        self.classroom = tk.StringVar(value='6A8')
        self.status = tk.StringVar(value='Chưa kết nối điện thoại')
        root.title('eNetViet USB — Điền và lưu từng tiết 0.7')
        root.geometry('920x650')
        wrap = ttk.Frame(root, padding=16)
        wrap.pack(fill='both', expand=True)
        ttk.Label(wrap, text='TRỢ LÝ PPCT • TOÁN 6 & 7', font=('Segoe UI', 18, 'bold')).pack(anchor='w')
        ttk.Label(wrap, text='Mở đúng phiếu: tự chọn PPCT, nhập 0 / Tốt, điểm 20 / 10 / 10 và lưu. Hoàn thành do thầy chọn.', wraplength=870).pack(anchor='w', pady=8)
        controls = ttk.Frame(wrap)
        controls.pack(fill='x', pady=8)
        ttk.Label(controls, text='Tuần').pack(side='left')
        week = ttk.Combobox(controls, textvariable=self.week, values=list(range(1,36)), width=5, state='readonly')
        week.pack(side='left', padx=8)
        ttk.Label(controls, text='Lớp').pack(side='left')
        classroom = ttk.Combobox(controls, textvariable=self.classroom, values=['6A8','6A1','7A2'], width=8, state='readonly')
        classroom.pack(side='left', padx=8)
        week.bind('<<ComboboxSelected>>', self.refresh)
        classroom.bind('<<ComboboxSelected>>', self.refresh)
        ttk.Button(controls, text='Kết nối USB', command=lambda:self.run(self.connect)).pack(side='left', padx=8)
        ttk.Button(controls, text='Dừng', command=self.stop.set).pack(side='right')
        self.table = ttk.Treeview(wrap, columns=('period','title'), show='headings', height=6, selectmode='browse')
        self.table.heading('period', text='Tiết PPCT')
        self.table.heading('title', text='Nội dung nhóm tiết nguyên văn trong file (không tự tách tên bài)')
        self.table.column('period', width=80, stretch=False)
        self.table.column('title', width=740)
        self.table.pack(fill='x')
        scroll = ttk.Scrollbar(wrap, orient='horizontal', command=self.table.xview)
        scroll.pack(fill='x')
        self.table.configure(xscrollcommand=scroll.set)
        actions = ttk.Frame(wrap)
        actions.pack(fill='x', pady=12)
        ttk.Button(actions, text='Điền tiết đã chọn vào phiếu đang mở', command=self.fill).pack(side='left')
        ttk.Button(actions, text='Lấy dữ liệu màn hình để hiệu chỉnh', command=lambda:self.run(self.capture)).pack(side='left', padx=8)
        ttk.Label(wrap, textvariable=self.status, wraplength=860).pack(anchor='w', pady=8)
        self.logbox = tk.Text(wrap, height=15, wrap='word', state='disabled', font=('Segoe UI',10))
        self.logbox.pack(fill='both', expand=True)
        self.refresh()
        root.after(100, self.poll)

    def refresh(self, event=None):
        self.table.delete(*self.table.get_children())
        grade = self.classroom.get()[0]
        for rec in DATA[grade]['weeks'][self.week.get()]:
            self.table.insert('', 'end', iid=str(rec['period']), values=(rec['period'], rec['source_text'].replace('\n',' / ')))
        first = self.table.get_children()[0]
        self.table.selection_set(first)

    def log(self, message):
        self.events.put(('log', message))

    def poll(self):
        try:
            while True:
                kind, value = self.events.get_nowait()
                if kind == 'done':
                    self.busy = False
                else:
                    self.status.set(value)
                    self.logbox.configure(state='normal')
                    self.logbox.insert('end', time.strftime('%H:%M:%S') + '  ' + value + '\n')
                    self.logbox.see('end')
                    self.logbox.configure(state='disabled')
        except queue.Empty:
            pass
        self.root.after(100, self.poll)

    def run(self, fn):
        if self.busy:
            messagebox.showinfo('Đang chạy', 'Hãy chờ thao tác hiện tại hoặc bấm Dừng.')
            return
        self.busy = True
        self.stop.clear()
        def worker():
            try:
                fn()
            except Exception as exc:
                self.log('DỪNG: ' + str(exc))
            finally:
                self.events.put(('done', None))
        threading.Thread(target=worker, daemon=True).start()

    def connect(self):
        import adbutils
        import uiautomator2 as u2
        devices = adbutils.adb.device_list()
        devices = [d for d in devices if ':' not in d.serial and not d.serial.startswith(('emulator-', 'adb-'))]
        if len(devices) != 1:
            raise RuntimeError('Cần đúng một điện thoại USB được cấp quyền. Mở khóa máy, bật Gỡ lỗi USB và chấp nhận hộp thoại trên điện thoại.')
        self.log('Đang kết nối; lần đầu có thể cần tải thành phần điều khiển...')
        self.d = u2.connect_usb(devices[0].serial)
        self.d.window_size()
        self.log('Đã kết nối USB. Mở eNetViet → Sổ đầu bài giáo viên → chọn đúng tuần, rồi chạy danh sách.')

    def require_device(self):
        if self.d is None:
            raise RuntimeError('Bấm Kết nối USB hoặc Kết nối Wi-Fi trước.')

    def fill(self):
        selected = self.table.selection()
        if not selected:
            return
        classroom, week, period = self.classroom.get(), self.week.get(), int(selected[0])
        if not messagebox.askokcancel('Kiểm tra phiếu đang mở', f'Tuần {week} • {classroom} • Toán • PPCT {period}\n\nThầy đã mở đúng ngày/buổi/tiết cần nhập trên điện thoại chưa?\nPhần mềm chưa tự đối chiếu ngày và thời khóa biểu.\nSẽ nhập 0, Tốt, điểm 20 / 10 / 10 và BẤM LƯU.\nMục Hoàn thành giữ nguyên lựa chọn của thầy.'):
            return
        def action():
            self.require_device()
            self.log(f'Bắt đầu: tuần {week}, {classroom}, PPCT {period}.')
            FormAssistant(self.d, self.stop, self.log).fill(classroom, period)
        self.run(action)

    def capture(self):
        self.require_device()
        folder = ROOT / 'chan_doan' / time.strftime('%Y%m%d_%H%M%S')
        folder.mkdir(parents=True, exist_ok=True)
        (folder/'man_hinh.xml').write_text(self.d.dump_hierarchy(), encoding='utf-8')
        self.d.screenshot(str(folder/'man_hinh.png'))
        (folder/'ung_dung.json').write_text(json.dumps(self.d.app_current(), ensure_ascii=False), encoding='utf-8')
        archive = folder.with_suffix('.zip')
        with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
            for path in folder.iterdir():
                z.write(path,path.name)
        self.log(f'Đã tạo {archive}. Tệp chứa màn hình hiện tại; xem trước khi gửi để hiệu chỉnh.')


if __name__ == '__main__':
    window = tk.Tk()
    App(window)
    window.mainloop()
