import tempfile
import unittest
import zipfile
from pathlib import Path
from analyzer import content_for

class PpctLinesTests(unittest.TestCase):
    def test_word_cell_preserves_paragraphs_and_breaks(self):
        xml='''<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:tbl><w:tr><w:tc><w:p><w:r><w:t>23;24</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>KTTX</w:t><w:br/><w:t>CHƯƠNG 4</w:t></w:r></w:p><w:p><w:r><w:t>Bài 12</w:t></w:r></w:p><w:p><w:r><w:t>Bài 13</w:t></w:r></w:p></w:tc></w:tr></w:tbl></w:body></w:document>'''
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'ppct.docx'
            with zipfile.ZipFile(p,'w') as z:z.writestr('word/document.xml',xml)
            self.assertIn('23;24 | KTTX\nCHƯƠNG 4\nBài 12\nBài 13',content_for(p)['text'])
