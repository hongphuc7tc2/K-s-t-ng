import unittest
from types import SimpleNamespace as NS
from xml.etree.ElementTree import Element
from navigator import Navigator,PACKAGE
from borrow import BorrowAssistant,PACKAGE as MISA
from test_week_picker import main
from test_borrow import fixture
from datetime import date

def node(package,id,text):return Element('node',{'resource-id':package+':id/'+id,'text':text})

class EntryTests(unittest.TestCase):
    def test_sisap_waits_for_complete_calendar_without_swiping(self):
        nav=BorrowAssistant.__new__(BorrowAssistant);actions=[]
        nav.nodes=lambda:[node(MISA,'tvContent','Thiết bị')]
        nav.click=lambda n:actions.append('open')
        nav.require_main=lambda:actions.append('ready')
        def wait(pred,msg,timeout=20):
            self.assertEqual(actions,['open'])
            self.assertFalse(pred([]))
            self.assertFalse(pred([node(MISA,'tvTitle','Thiết bị'),node(MISA,'tvTitleWeek','')]))
            partial=fixture('main')
            for n in partial:
                if n.get('class')=='android.widget.CheckedTextView':n.set('visible-to-user','false')
            self.assertFalse(pred(partial))
            busy=fixture('main')+[Element('node',{'class':'android.widget.ProgressBar','visible-to-user':'true'})]
            self.assertFalse(pred(busy))
            self.assertTrue(pred(fixture('main')))
            return fixture('main')
        nav.wait_nodes=wait;nav.ensure_entry()
        self.assertEqual(actions,['open','ready'])
    def test_sisap_already_loading_does_not_tap_again(self):
        nav=BorrowAssistant.__new__(BorrowAssistant);nav.nodes=lambda:[]
        nav.click=lambda n:self.fail('must not tap while loading')
        nav.require_main=lambda:None
        def wait(pred,msg,timeout=20):
            self.assertFalse(pred([]));self.assertTrue(pred(fixture('main')))
            return fixture('main')
        nav.wait_nodes=wait;nav.ensure_entry()
    def test_enet_home_menu_then_wait_calendar(self):
        nav=Navigator.__new__(Navigator);actions=[];state=[0]
        pages=[[node(PACKAGE,'tv_title','Sổ đầu bài')],[node(PACKAGE,'tv_title','Sổ đầu bài giáo viên')],main(7)]
        nav.nodes=lambda:pages[state[0]]
        def click(n):actions.append(n.get('text'));state[0]+=1
        def wait(pred,msg,timeout=20):
            self.assertTrue(pred(nav.nodes()));return nav.nodes()
        nav.click=click;nav.wait_nodes=wait
        nav.ensure_main();nav.ensure_main()
        self.assertEqual(actions,['Sổ đầu bài','Sổ đầu bài giáo viên'])
    def test_sisap_opens_and_dismisses_known_overlay_once(self):
        nav=BorrowAssistant.__new__(BorrowAssistant);state=[0];actions=[]
        pages=[[node(MISA,'tvContent','Thiết bị')],[node(MISA,'tvName','Nhấn vào đây để xem hướng dẫn sử dụng')],fixture('main')]
        nav.nodes=lambda:pages[state[0]];nav.check=lambda:None;nav.log=lambda s:None
        def click(n):actions.append(n.get('text'));state[0]=1
        def center(x,y):actions.append((x,y));state[0]=2
        def wait(pred,msg,timeout=20):
            self.assertTrue(pred(nav.nodes()));return nav.nodes()
        nav.click=click;nav.d=NS(window_size=lambda:(1260,2800),click=center);nav.wait_nodes=wait
        nav.ensure_entry();nav.ensure_entry()
        self.assertEqual(actions,['Thiết bị',(630,1400)])
    def test_borrow_week_never_visits_sunday(self):
        nav=BorrowAssistant.__new__(BorrowAssistant);days=[];opened=[]
        nav.ensure_entry=lambda:None;nav.go_week=lambda week:date(2026,10,19)
        nav.day=lambda day,start:days.append(day) or start
        nav.scan_cards=lambda:['Tiết 4 Sáng'];nav.open_card=lambda n:opened.append(n)
        nav.process_card=lambda *a:True;nav.log=lambda s:None
        nav.run_week(5,7,[],False)
        self.assertEqual(days,[2,3,4,5,6,7]);self.assertEqual(len(opened),6)
