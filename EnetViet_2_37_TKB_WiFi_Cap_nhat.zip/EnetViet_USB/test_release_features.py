import unittest,io,zipfile,tempfile,json,queue,threading
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
from timetable_grid import set_slot
from updates import version_tuple,safe_members,check_feed,stage_release
from wifi_connection import endpoint
from install_update import install

class NewFeaturesTests(unittest.TestCase):
    def test_grid_keeps_anchor_for_same_group(self):
        rows=[dict(day=2,session='Sáng',slot=1,classroom='6A1',course='c',anchor_week=6,start_period=21)]
        set_slot(rows,3,'Chiều',2,('6A1','c'),7,{'c':{'periods':{'1':'Bài'}}})
        self.assertEqual((rows[1]['anchor_week'],rows[1]['start_period']),(6,21))
        set_slot(rows,2,'Sáng',1,None,7,{})
        self.assertEqual(len(rows),1)
    def test_grid_hdtn_starts_at_second_period(self):
        rows=[];set_slot(rows,2,'Sáng',1,('6A1','h'),1,{'h':{'periods':{'1':'A','2':'B'},'taught_offsets':[2,3]}})
        self.assertEqual(rows[0]['start_period'],2)
    def test_wifi_addresses_validated(self):
        self.assertEqual(endpoint('192.168.1.3:43210'),'192.168.1.3:43210')
        for value in ['localhost:5555','1.2.3.4:0','1.2.3.4:99999','1.2.3.4;echo secret:55']:
            with self.assertRaises(ValueError):endpoint(value)
    def zip_data(self,extra=None):
        bio=io.BytesIO()
        with zipfile.ZipFile(bio,'w') as z:
            for name in ['app.py','borrow.py','LICH_SU_PHIEN_BAN.txt']:z.writestr('EnetViet_USB/'+name,'test')
            if extra:z.writestr(extra,'x')
        return bio.getvalue()
    def test_zip_rejects_runtime_data_and_traversal(self):
        for name in ['EnetViet_USB/../bad.py','EnetViet_USB/profiles/a.json','EnetViet_USB/cap_nhat_settings.json']:
            with zipfile.ZipFile(io.BytesIO(self.zip_data(name))) as z:
                with self.assertRaises(ValueError):safe_members(z)
        with zipfile.ZipFile(io.BytesIO(self.zip_data())) as z:self.assertEqual(len(safe_members(z)),3)
    def test_update_version_numeric_and_up_to_date_silent(self):
        self.assertGreater(version_tuple('2.100'),version_tuple('2.37'))
        with patch('updates.fetch',return_value=b'{"version":"2.37"}'):
            self.assertIsNone(check_feed('https://example.org/version.json'))
    def test_update_hash_mismatch_does_not_stage(self):
        with patch('updates.fetch',return_value=self.zip_data()):
            with self.assertRaisesRegex(ValueError,'không khớp'):
                stage_release({'download_url':'https://example.org/x.zip','sha256':'0'*64})
    def test_install_preserves_profiles_and_backs_up(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/'app';root.mkdir();stage=Path(tmp)/'stage';(stage/'files').mkdir(parents=True)
            (root/'app.py').write_text('old');(root/'profiles').mkdir();(root/'profiles'/'mine.json').write_text('private')
            (stage/'files'/'app.py').write_text('new');install(root,stage)
            self.assertEqual((root/'app.py').read_text(),'new');self.assertEqual((root/'profiles'/'mine.json').read_text(),'private')
            self.assertEqual(next((root/'sao_luu_phien_ban').rglob('app.py')).read_text(),'old')
    def test_progress_worker_reports_failure(self):
        from app import App
        app=App.__new__(App);app.root=None;app.busy=False;app.stop=threading.Event();app.events=queue.Queue();app.profile={}
        app.log=lambda msg:None
        def fail():raise RuntimeError('Mất kết nối')
        with patch('progress_window.ProgressWindow'):
            app.run(fail)
            kind,result=app.events.get(timeout=3)
        self.assertEqual(kind,'done');self.assertEqual(result,{'state':'error','detail':'Mất kết nối'})

if __name__=='__main__':unittest.main()
