class BidirectionalScan:
    """Bounded scan from current position to top, then bottom."""
    def __init__(self,limit=30):
        self.limit=limit;self.forward=False;self.previous=None;self.stalled=0;self.steps=0
    def next_direction(self,signature):
        self.stalled=self.stalled+1 if signature==self.previous else 0
        self.previous=signature;self.steps+=1
        if not self.forward and (self.stalled>=2 or self.steps>=self.limit):
            self.forward=True;self.previous=None;self.stalled=0;self.steps=0
        elif self.forward and (self.stalled>=3 or self.steps>=self.limit):return None
        return self.forward
