"""MISA SISAP equipment loans, driven by observed accessibility identifiers."""
import re
import json
from datetime import datetime,timedelta
from engine import FormAssistant,label,bounds,normalized,same_class
from profiles import atomic_json
from ui_scan import BidirectionalScan
from xml.etree.ElementTree import Element

PACKAGE='vn.com.misa.sisapteacher'
def ids(ns,name):return [n for n in ns if n.get('resource-id')==PACKAGE+':id/'+name]
def one(ns,name):
    found=ids(ns,name)
    if len(found)!=1:raise RuntimeError('Không nhận diện duy nhất mục mượn đồ dùng: '+name)
    return found[0]
def value(ns,title):
    found=[n for n in ids(ns,'tvCategoryName') if label(n)==title]
    if len(found)!=1:raise RuntimeError('Chưa đọc rõ mục '+title)
    parents=[n for n in ns if found[0] in list(n)]
    if len(parents)!=1:raise RuntimeError('Bố cục mục '+title+' chưa rõ.')
    return label(one(list(parents[0].iter('node')),'tvHint'))
def week_info(ns):
    text=label(one(ns,'tvTitleWeek'))
    m=re.fullmatch(r'Tuần\s+(\d+):\s*(\d{2}/\d{2}/\d{4})\s*-\s*(\d{2}/\d{2}/\d{4})',text)
    if not m:raise RuntimeError('Chưa đọc rõ tuần/ngày trong app Thiết bị.')
    start=datetime.strptime(m[2],'%d/%m/%Y').date()
    if start.weekday()!=0:raise RuntimeError('Ngày đầu tuần không phải thứ Hai.')
    return int(m[1]),start

def calendar_cells(ns):
    """Resolve the visible seven-day row, even without the pager identifier."""
    _,start=week_info(ns)
    expected=[str((start+timedelta(days=i)).day) for i in range(7)]
    header=bounds(one(ns,'tvTitleWeek'))
    candidates=[]
    for n in ns:
        if n.get('class')!='android.widget.CheckedTextView' or n.get('visible-to-user')=='false':continue
        x,y,xx,yy=bounds(n)
        if xx>x and yy>y and y>=header[3] and label(n) in expected:candidates.append(n)
    groups={}
    for n in candidates:groups.setdefault(bounds(n)[1],[]).append(n)
    rows=[]
    for group in groups.values():
        row=sorted(group,key=lambda n:bounds(n)[0])
        if len(row)==7 and [label(n) for n in row]==expected and all(bounds(a)[2]<=bounds(b)[0] for a,b in zip(row,row[1:])):rows.append(row)
    if len(rows)!=1:raise RuntimeError('Chưa thấy rõ đủ bảy ngày của tuần trên lịch Thiết bị.')
    return rows[0]

def calendar_region(ns):
    cells=calendar_cells(ns)
    pagers=[n for n in ids(ns,'mcv_pager') if all(c in list(n.iter('node')) for c in cells)]
    if len(pagers)==1:return pagers[0]
    boxes=[bounds(n) for n in cells]
    return Element('node',{'bounds':f'[{min(b[0] for b in boxes)},{min(b[1] for b in boxes)}][{max(b[2] for b in boxes)},{max(b[3] for b in boxes)}]'})

def match_task(ns,tasks,day,expected_date):
    if label(one(ns,'tvSubTitle'))!='Ngày '+expected_date.strftime('%d/%m/%Y'):
        raise RuntimeError('Ngày trên phiếu mượn khác ngày cần xử lý.')
    slot=value(ns,'Tiết học');room=value(ns,'Lớp');subject=value(ns,'Môn học')
    matches=[t for t in tasks if t['day']==day and slot==f"{t['slot']} {t['session']}"
             and same_class(room,t['classroom']) and normalized(subject)==normalized(t.get('subject','Toán'))]
    if len(matches)!=1:raise RuntimeError(f'Phiếu {room} • {subject} • {slot} không khớp duy nhất TKB tuần đích. Kiểm tra TKB trước khi chạy.')
    if not matches[0].get('valid') or int(matches[0]['period'])<1:raise RuntimeError('Thiếu PPCT hợp lệ cho phiếu mượn.')
    return matches[0]

class BorrowAssistant(FormAssistant):
    def __init__(self,device,stop,log,journal_path,profile_id,school_year):
        super().__init__(device,stop,log);self.package=PACKAGE
        self.path=journal_path;self.identity=profile_id+'|'+school_year
        self.journal=json.loads(self.path.read_text(encoding='utf-8')) if self.path.exists() else {}
    def mark(self,k,state):self.journal[k]=state;atomic_json(self.path,self.journal)
    def main(self,ns=None):
        ns=self.nodes() if ns is None else ns
        return any(label(n)=='Thiết bị' for n in ids(ns,'tvTitle')) and len(ids(ns,'tvTitleWeek'))==1
    def ensure_entry(self):
        ns=self.nodes()
        def overlay(nodes):
            return any(label(n)=='Nhấn vào đây để xem hướng dẫn sử dụng' for n in ids(nodes,'tvName'))
        def loaded(nodes):
            try:
                return (self.main(nodes) and bool(calendar_cells(nodes))
                        and any(label(n)=='Kế hoạch mượn' and n.get('selected')=='true' for n in nodes)
                        and not any(n.get('class')=='android.widget.ProgressBar' and n.get('visible-to-user')!='false' for n in nodes))
            except RuntimeError:return False
        if not self.main(ns) and not overlay(ns):
            buttons=[n for n in ids(ns,'tvContent') if label(n)=='Thiết bị']
            if len(buttons)>1:raise RuntimeError('Có nhiều nút Thiết bị; chưa xác định được nút cần mở.')
            if buttons:self.click(buttons[0])
        # Header may appear before the calendar and loan tab finish loading.
        ns=self.wait_nodes(lambda nodes:loaded(nodes) or overlay(nodes),
                           'Đợi Thiết bị tải xong tuần, bảy ô ngày và Kế hoạch mượn...',timeout=40)
        if overlay(ns):
            self.check();w,h=self.d.window_size()
            self.log('Đóng lớp hướng dẫn Thiết bị bằng cách chạm giữa màn hình.')
            self.d.click(w//2,h//2)
            self.wait_nodes(lambda nodes:loaded(nodes) and not overlay(nodes),'Đang chờ lịch Thiết bị tải đầy đủ...',timeout=40)
        self.require_main()

    def require_main(self):
        if not self.main():raise RuntimeError('Mở app MISA SISAP → Thiết bị → Kế hoạch mượn trước khi chạy.')
        ns=self.nodes()
        if not any(label(n)=='Kế hoạch mượn' and n.get('selected')=='true' for n in ns):
            raise RuntimeError('Chọn tab Kế hoạch mượn trước khi chạy.')
    def swipe_region(self,node,forward=True,horizontal=False):
        x1,y1,x2,y2=bounds(node)
        if x2-x1<40 or y2-y1<60:raise RuntimeError('Vùng cuộn quá nhỏ.')
        self.check()
        if horizontal:
            # Keep both endpoints inside the calendar, away from Vivo side panels.
            y=(y1+y2)/2;a=x1+(x2-x1)*.12;b=x1+(x2-x1)*.88
            self.d.swipe(b if forward else a,y,a if forward else b,y,.55)
        else:
            x=(x1+x2)/2;a=y1+(y2-y1)*.2;b=y1+(y2-y1)*.8
            self.d.swipe(x,b if forward else a,x,a if forward else b,.35)
        if self.stop.wait(.5):self.check()
    def go_week(self,wanted):
        self.require_main()
        for _ in range(55):
            ns=self.nodes();current,start=week_info(ns)
            if current==wanted:
                self.log(f'Đã đúng tuần {wanted}; không vuốt thêm.')
                return start
            self.log(f'Đang ở tuần {current}, cần tuần {wanted}.')
            for attempt in range(3):
                # Earlier week: finger left-to-right. Later week: right-to-left.
                ns=self.calendar_ready()
                if week_info(ns)[0]!=current:break
                self.swipe_region(calendar_region(ns),wanted>current,True)
                changed=False
                for _ in range(12):
                    self.check();ns=self.nodes()
                    if self.main(ns):
                        actual,_=week_info(ns)
                        if actual!=current:
                            changed=True;break
                    if self.stop.wait(.25):self.check()
                if changed:
                    if (actual-current)*(wanted-current)<=0:
                        raise RuntimeError(f'Vuốt từ tuần {current} nhưng app chuyển sang tuần {actual}, ngược hướng tuần {wanted}. Đã dừng để kiểm tra.')
                    self.log(f'Đã chuyển sang tuần {actual}.')
                    break
                if attempt<2:self.log(f'Vẫn ở tuần {current}; vuốt dài lại ({attempt+2}/3).')
            else:
                raise RuntimeError(f'Đã vuốt 3 lần nhưng chưa chuyển khỏi tuần {current}. Kiểm tra lịch trên điện thoại.')
        raise RuntimeError('Không chuyển được tới tuần yêu cầu.')
    def calendar_ready(self):
        def ready(ns):
            try:return self.main(ns) and bool(calendar_cells(ns))
            except RuntimeError:return False
        ns=self.nodes()
        if ready(ns):return ns
        self.log('Chờ lịch ngày tải/hiện lại...')
        for _ in range(6):
            if self.stop.wait(.5):self.check()
            ns=self.nodes()
            if ready(ns):return ns
        # Scrolling loan cards can collapse the calendar. Reveal it only when absent.
        for _ in range(4):
            if not self.main(ns):break
            regions=ids(ns,'rvData')
            if len(regions)!=1:break
            self.log('Đưa danh sách về phía trên để hiện lịch ngày...')
            self.swipe_region(regions[0],False)
            ns=self.nodes()
            if ready(ns):return ns
        return self.wait_nodes(ready,'Chưa thấy lịch ngày. Chờ lịch Thiết bị hiện đủ bảy ngày...',timeout=10)

    def day(self,day,start):
        ns=self.calendar_ready();date=start+timedelta(days=day-2)
        if week_info(ns)[1]!=start:raise RuntimeError('Tuần trên điện thoại đã thay đổi; dừng để tránh chọn nhầm ngày.')
        options=[n for n in calendar_cells(ns) if label(n)==str(date.day)]
        if len(options)!=1:raise RuntimeError('Không nhận diện được ngày trên lịch mượn.')
        if options[0].get('checked')!='true':self.click(options[0])
        def selected(ns):
            try:return week_info(ns)[1]==start and any(n.get('checked')=='true' and label(n)==str(date.day) for n in calendar_cells(ns))
            except RuntimeError:return False
        self.wait_nodes(selected,'Đang chọn ngày '+date.strftime('%d/%m/%Y')+'...')
        if self.stop.wait(.7):self.check()
        return date
    def titles(self,ns):
        result=[]
        for row in ids(ns,'lnTitleSession'):
            sub=list(row.iter('node'));sessions=ids(sub,'tvSession');edits=ids(sub,'tvEditBorrowed')
            if len(sessions)==len(edits)==1:result.append((label(sessions[0]),edits[0]))
        return result
    def scan_cards(self):
        self.require_main()
        names=[name for name,_ in self.titles(self.nodes())]
        if len(names)!=len(set(names)):
            raise RuntimeError('Có nhiều phiếu cùng tiết/buổi trong một ngày; cần kiểm tra thủ công.')
        return names
    def open_card(self,name):
        ns=self.nodes();items=self.titles(ns);region=one(ns,'rvData');rb=bounds(region)
        matches=[n for title,n in items if title==name]
        if len(matches)!=1:raise RuntimeError('Chưa thấy duy nhất nút Chỉnh sửa của '+name+'. Không tự cuộn danh sách ngày.')
        b=bounds(matches[0])
        if b[3]-b[1]<=30 or b[1]<rb[1] or b[3]>rb[3]:
            raise RuntimeError('Nút Chỉnh sửa đang khuất. Đưa phiếu vào màn hình rồi chạy lại.')
        self.click(matches[0])
        return self.wait_nodes(lambda ns:bool(ids(ns,'tvCategoryName')),'Đang mở phiếu mượn...')
    def back(self):
        self.click(one(self.nodes(),'ivBack'))
        self.wait_nodes(self.main,'Đang trở về danh sách mượn...')
    def inventory(self,week,tasks=None):
        start=self.go_week(week);records=[]
        for day in range(2,8):
            date=self.day(day,start)
            names=self.scan_cards()
            for name in names:
                if tasks is None:records.append((day,name,None));continue
                ns=self.open_card(name);task=match_task(ns,tasks,day,date)
                records.append((day,name,dict(task)));self.back()
        return start,records
    def copy_week(self,source,target,tasks):
        token=f'{self.identity}|copy|{source}|{target}'
        if self.journal.get(token):raise RuntimeError('Lần sao chép này đã chạy hoặc chưa rõ kết quả. Chọn Chỉ cập nhật phiếu đã có để tránh sao chép trùng.')
        if source==target:raise RuntimeError('Tuần mẫu và tuần đích phải khác nhau.')
        self.log(f'Đi thẳng đến tuần mẫu {source} để sao chép sang tuần {target}.')
        self.go_week(source)
        self.click(one(self.nodes(),'tvCloneBill'))
        ns=self.wait_nodes(lambda ns:len(ids(ns,'tvWeek'))==1,'Đang mở Sao chép phiếu mượn...')
        if not re.match(r'^Tuần\s+'+str(source)+r':',label(one(ns,'tvWeek'))):
            raise RuntimeError('Tuần nguồn trên bảng sao chép khác tuần mẫu. Chưa sao chép.')
        self.click(one(ns,'tvWeek'))
        self.wait_nodes(lambda ns:any(label(n)=='Chọn tuần' for n in ns),'Đang mở bảng chọn tuần đích...')
        scan=BidirectionalScan(limit=30)
        for _ in range(64):
            ns=self.nodes();region=one(ns,'rvDataMorning');rows=ids(list(region.iter('node')),'tvName')
            matches=[n for n in rows if re.match(r'^Tuần\s+'+str(target)+r':',label(n))]
            if len(matches)==1:
                self.click(matches[0]);break
            if len(matches)>1:raise RuntimeError('Tuần đích bị trùng trong bảng chọn.')
            direction=scan.next_direction(tuple(label(n) for n in rows))
            if direction is None:raise RuntimeError('Không tìm được tuần đích.')
            self.swipe_region(region,direction)
        else:raise RuntimeError('Không tìm được tuần đích.')
        def selected(ns):
            parents=[n for n in ns if any(re.match(r'^Tuần\s+'+str(target)+r':',label(c)) for c in list(n))]
            marked=[n for n in ns if ids(list(n),'animatedcheckbox') and ids(list(n),'tvName')]
            return len(marked)==1 and marked[0] in parents
        ns=self.wait_nodes(selected,'Đang xác minh tuần đích đã chọn...')
        self.mark(token,'saving')
        self.click(one(ns,'tvDone'))  # Never retry: this commits the copy.
        self.wait_nodes(lambda ns:any(label(n)=='Sao chép thành công' for n in ns),'Đang chờ sao chép thành công...',timeout=30)
        self.mark(token,'copied');self.click(self.exact('Đóng'))
        self.wait_nodes(self.main,'Đang trở về tuần đã sao chép...')
        self.log(f'Đã sao chép tuần {source} sang tuần {target}.')
        return None
    def skip_filled_ppct(self,ns):
        current=value(ns,'Tiết PPCT').strip()
        if re.fullmatch(r'\d+(?:\s*[,;]\s*\d+)*',current):
            self.log(f'Phiếu đã có PPCT {current}; giữ nguyên, bỏ qua.')
            self.back();return True
        if current and not normalized(current).startswith('chọn'):
            raise RuntimeError('Ô PPCT có nội dung chưa nhận diện: '+current+'. Không ghi đè.')
        return False
    def process_card(self,tasks,day,date):
        ns=self.nodes()
        if label(one(ns,'tvSubTitle'))!='Ngày '+date.strftime('%d/%m/%Y'):
            raise RuntimeError('Ngày phiếu khác ngày vừa chọn; đã dừng.')
        if self.skip_filled_ppct(ns):return False
        task=match_task(ns,tasks,day,date)
        self.update_form(task,date)
        return True
    def update_form(self,task,date):
        ns=self.nodes()
        if self.skip_filled_ppct(ns):return
        match_task(ns,[task],task['day'],date)
        period=str(task['period'])
        token=f"{self.identity}|save|{date}|{task['slot']}|{task['session']}|{task['classroom']}|{task.get('subject')}"
        def equipment(ns):
            return tuple((n.get('resource-id'),label(n)) for n in ns if n in ids(ns,'tvNameDevice')+ids(ns,'tvSpeciesDevice')+ids(ns,'edtNumber'))
        original_equipment=equipment(ns)
        if self.journal.get(token)=='saving':
            raise RuntimeError('Phiếu này có lần lưu chưa xác nhận; kiểm tra trên điện thoại trước khi chạy lại. Không tự lưu thêm.')
        self.click(self.exact('Tiết PPCT',ns))
        ns=self.wait_nodes(lambda ns:len(ids(ns,'etSearchLesson'))==1,'Đang mở tìm kiếm PPCT mượn đồ dùng...')
        self.check();self.d(resourceId=PACKAGE+':id/etSearchLesson').set_text(period)
        try:keyboard=self.d.shell('dumpsys input_method').output
        except Exception:keyboard=''
        if re.search(r'(?:mInputShown|isInputViewShown)\s*[=:]\s*true',keyboard):self.check();self.d.press('back')
        ns=self.wait_nodes(lambda ns:len([n for n in ids(ns,'tvSearchLesson') if label(n)==period])==1,'Đang tìm đúng PPCT '+period+'...')
        self.click([n for n in ids(ns,'tvSearchLesson') if label(n)==period][0])
        def prompt(ns):return any('thay đổi lại danh sách thiết bị' in label(n) and 'Tiết PPCT' in label(n) for n in ns)
        ns=self.wait_nodes(lambda ns:prompt(ns) or (bool(ids(ns,'tvCategoryName')) and value(ns,'Tiết PPCT')==period),'Đang cập nhật PPCT trên phiếu...')
        if prompt(ns):
            buttons=[n for n in ns if normalized(label(n))=='không']
            if len(buttons)!=1:raise RuntimeError('Không nhận diện nút Không để giữ thiết bị mẫu.')
            self.click(buttons[0])
        ns=self.wait_nodes(lambda ns:not prompt(ns) and bool(ids(ns,'tvCategoryName')) and value(ns,'Tiết PPCT')==period,'Đang xác minh PPCT trước khi lưu...')
        match_task(ns,[task],task['day'],date)
        token=f"{self.identity}|save|{date}|{task['slot']}|{task['session']}|{task['classroom']}|{task.get('subject')}"
        if equipment(ns)!=original_equipment:raise RuntimeError('Danh sách thiết bị/số lượng đã thay đổi; chưa lưu, cần kiểm tra thủ công.')
        self.mark(token,'saving');self.click(one(ns,'tvSave'))
        self.wait_nodes(self.main,'Đang chờ lưu phiếu mượn...',timeout=30)
        self.mark(token,'saved')
        self.log(f"Đã lưu phiếu {date} • {task['classroom']} • PPCT {period}; chuyển phiếu tiếp theo, không mở lại.")
    def run_week(self,source,target,tasks,copy_first):
        self.ensure_entry()
        expected=self.copy_week(source,target,tasks) if copy_first else None
        start=self.go_week(target)
        visited=set();filled=0;skipped=0
        for day in range(2,8):
            date=self.day(day,start)
            names=self.scan_cards()
            if not names:self.log('Ngày '+date.strftime('%d/%m/%Y')+': không thấy phiếu mượn, bỏ qua.')
            for name in names:
                self.open_card(name)
                if self.process_card(tasks,day,date):filled+=1
                else:skipped+=1
                visited.add((day,name))
        if expected is not None and {(d,n) for d,n,_ in expected}!=visited:
            raise RuntimeError('Danh sách phiếu hiển thị sau sao chép khác tuần mẫu. Kiểm tra thêm trên điện thoại; các phiếu đã xử lý được ghi trong nhật ký.')
        if not visited:raise RuntimeError('Không thấy phiếu mượn trong tuần đích.')
        self.log('Bỏ qua Chủ Nhật theo thiết lập mượn đồ dùng.')
        self.log(f'ĐÃ XONG: điền {filled} phiếu trống PPCT; giữ nguyên {skipped} phiếu đã có PPCT, trong {len(set(d for d,_ in visited))} ngày của tuần {target}.')
