"""PNG button icons, independent of font glyph rendering."""
from pathlib import Path
import tkinter as tk
from tkinter import ttk

RULES=[
 (('Dừng','Ngắt'),'stop'),(('Xóa','Bỏ tệp','Bỏ lớp','Bỏ chọn'),'delete'),
 (('Khôi phục','Tiếp tục'),'restore'),(('Sao chép','Copy'),'copy'),
 (('Sao lưu',),'backup'),(('Lưu',),'save'),(('Xuất',),'export'),(('Nhập',),'import'),
 (('Thêm','Tạo'),'add'),(('Sửa','Đổi','Nội dung mặc định'),'edit'),
 (('Đồng ý','Áp dụng','Chọn tất cả','Đã ghi sổ','Hoàn thành'),'check'),
 (('Ghi sổ','Ghi phiếu'),'edit'),(('Phân tích','Cài đặt AI'),'ai'),
 (('Chụp',),'camera'),(('Kết nối','Quét'),'connect'),
 (('Bắt đầu','Mở','Mượn'),'play'),(('Xem','Kiểm tra','Rà soát'),'inspect'),
 (('Đóng','Hủy','Quay lại'),'back'),(('Chọn',),'check')]

def icon_name(text):
    return next((name for prefixes,name in RULES if text.startswith(prefixes)),None)

def button_label(text):return text

def decorate_buttons(parent):
    for child in parent.winfo_children():
        if isinstance(child,ttk.Button) and not hasattr(child,'_button_icon_ready'):
            text=getattr(child,'_plain_button_text',str(child.cget('text')))
            child._plain_button_text=text;name=icon_name(text)
            if name:
                size=min((20,24,32,40,48),key=lambda n:abs(n-20*float(child.tk.call('tk','scaling'))/(96/72)))
                path=Path(__file__).parent/'icons'/f'{name}_{size}.png'
                try:
                    child._button_icon=tk.PhotoImage(master=child,file=str(path))
                    child.configure(text=text,image=child._button_icon,compound='left')
                except (tk.TclError,OSError):child.configure(text=text)
            child._button_icon_ready=True
        decorate_buttons(child)
