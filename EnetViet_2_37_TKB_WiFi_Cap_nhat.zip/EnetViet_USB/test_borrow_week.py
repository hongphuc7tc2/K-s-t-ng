import unittest
from types import SimpleNamespace
from datetime import date,timedelta
from test_borrow import fixture
from borrow import BorrowAssistant,one
from borrow_ui import title_dimensions

class WeekTests(unittest.TestCase):
    def nav(self,week,changes):
        nav=BorrowAssistant.__new__(BorrowAssistant);state=[week];swipes=[]
        nav.require_main=lambda:None;nav.check=lambda:None;nav.log=lambda s:None
        nav.stop=SimpleNamespace(wait=lambda seconds:False)
        def nodes():
            ns=fixture('main');start=date(2026,10,12)+timedelta(weeks=state[0]-6)
            cells=[n for n in one(ns,'mcv_pager').iter('node') if n.get('class')=='android.widget.CheckedTextView']
            for i,n in enumerate(cells):n.set('text',str((start+timedelta(days=i)).day))
            one(ns,'tvTitleWeek').set('text',f'Tuần {state[0]}: {start:%d/%m/%Y} - {start+timedelta(days=6):%d/%m/%Y}')
            return ns
        nav.nodes=nodes
        def swipe(node,forward,horizontal):
            swipes.append((forward,horizontal))
            if changes:state[0]=changes.pop(0)
        nav.swipe_region=swipe
        return nav,swipes
    def test_correct_week_no_swipe(self):
        nav,swipes=self.nav(6,[])
        self.assertEqual(nav.go_week(6),date(2026,10,12));self.assertEqual(swipes,[])
    def test_earlier_week_right_retry_unchanged(self):
        nav,swipes=self.nav(7,[7,6]);nav.go_week(6)
        self.assertEqual(swipes,[(False,True),(False,True)])
    def test_later_week_left(self):
        nav,swipes=self.nav(5,[6]);nav.go_week(6)
        self.assertEqual(swipes,[(True,True)])
    def test_no_change_bounded(self):
        nav,swipes=self.nav(7,[])
        with self.assertRaisesRegex(RuntimeError,'3 lần'):nav.go_week(6)
        self.assertEqual(len(swipes),3)
    def test_wrong_direction_stops(self):
        nav,swipes=self.nav(7,[8])
        with self.assertRaisesRegex(RuntimeError,'ngược hướng'):nav.go_week(6)
        self.assertEqual(len(swipes),1)
    def test_swipe_long_but_away_from_edges(self):
        nav,swipes=self.nav(7,[]);calls=[]
        nav.d=SimpleNamespace(swipe=lambda *args:calls.append(args))
        BorrowAssistant.swipe_region(nav,one(nav.nodes(),'mcv_pager'),True,True)
        x1,y1,x2,y2,duration=calls[0]
        self.assertGreater(x1-x2,1260*.75);self.assertEqual(y1,y2)
        self.assertGreaterEqual(x2,1260*.11);self.assertLessEqual(x1,1260*.89)
        self.assertGreaterEqual(duration,.5)
    def test_multiline_title_layout(self):
        font=SimpleNamespace(metrics=lambda key:20,measure=lambda s:len(s)*10)
        self.assertEqual(title_dimensions(['a\nb\nc','x'*60],font),(74,632))
        self.assertEqual(title_dimensions([],font),(34,460))
