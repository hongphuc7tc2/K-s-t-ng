import copy
import tempfile
import unittest
import zipfile
from pathlib import Path
from profiles import default_profile,validate,plan
from navigator import TimetableSweep
from analyzer import contents_for

class HDTNTests(unittest.TestCase):
    def profile(self):
        p=default_profile()
        p['courses']['hdtn6']={'name':'HĐTN 6','subject':'HĐTN','kind':'Thường','weekly_stride':3,'taught_offsets':[2,3],'periods':{str(n):'Bài '+str(n) for n in range(1,106)}}
        p['schedules'][0]['rows'] += [dict(day=2,session=s,slot=n,classroom='6A1',course='hdtn6',anchor_week=1,start_period=2) for s,n in [('Sáng',2),('Chiều',3)]]
        return p
    def test_all_weeks_hdtn_independent_of_math(self):
        p=self.profile()
        for w in range(1,36):
            tasks=plan(p,w);h=[t for t in tasks if t['subject']=='HĐTN']
            self.assertEqual([t['period'] for t in h],[3*w-1,3*w])
            self.assertEqual([t['period'] for t in tasks if t['classroom']=='6A1' and t['subject']=='Toán'],list(range(4*w-3,4*w+1)))
    def test_requires_two_taught_slots(self):
        p=self.profile();p['schedules'][0]['rows'].pop()
        with self.assertRaises(ValueError):validate(p)
    def test_separate_class_counter(self):
        p=self.profile()
        for r in copy.deepcopy(p['schedules'][0]['rows'][-2:]):r['classroom']='6A2';r['day']=3;p['schedules'][0]['rows'].append(r)
        h=[t for t in plan(p,2) if t['subject']=='HĐTN'];self.assertEqual([t['period'] for t in h],[5,6,5,6])
    def test_scroll_reverses_at_top_and_stops(self):
        s=TimetableSweep();directions=[]
        for _ in range(26):
            d=s.next_direction(('same viewport',));directions.append(d)
            if d is None:break
        self.assertIn(False,directions);self.assertIn(True,directions);self.assertIsNone(directions[-1])
    def test_scroll_bounded_even_when_viewport_changes(self):
        s=TimetableSweep();ds=[s.next_direction((n,)) for n in range(25)]
        self.assertIn(True,ds);self.assertIsNone(ds[-1])
    def test_word_tables_and_embedded_image(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'tkb.docx'
            with zipfile.ZipFile(p,'w') as z:
                z.writestr('word/document.xml','<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>TKB</w:t></w:r></w:p><w:tbl><w:tr><w:tc><w:p><w:r><w:t>Thứ 2</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>HĐTN</w:t></w:r></w:p></w:tc></w:tr></w:tbl></w:body></w:document>')
                z.writestr('word/media/image1.png',b'fixture')
            items=contents_for(p);self.assertIn('Thứ 2 | HĐTN',items[0]['text']);self.assertEqual(items[-1]['type'],'input_image')
