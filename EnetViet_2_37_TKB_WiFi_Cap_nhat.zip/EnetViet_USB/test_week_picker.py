import unittest
from types import SimpleNamespace
from xml.etree.ElementTree import Element,SubElement
from navigator import Navigator,week_number
from week_picker import picker_list,visible_options
from table_sort import sort_key

def main(week):
    root=Element('node');SubElement(root,'node',text='Sổ đầu bài giáo viên')
    SubElement(root,'node',attrib={'resource-id':'app:id/rvNotebook'})
    group=SubElement(root,'node')
    SubElement(group,'node',text='Chọn tuần',attrib={'resource-id':'app:id/textViewLabel'})
    SubElement(group,'node',text=f'Tuần {week} (ngày tháng)',attrib={'resource-id':'app:id/textViewValue'})
    return list(root.iter('node'))

def page(week):
    root=Element('node',attrib={'class':'android.widget.ListView','scrollable':'true','bounds':'[0,100][500,800]'})
    SubElement(root,'node',text=f'Tuần {week} (ngày tháng)',bounds='[10,200][490,260]')
    return list(root.iter('node'))

class Harness(Navigator):
    def __init__(self,start_page=2,current=9):
        self.current=current;self.page=start_page;self.open=False;self.actions=[]
        self.stop=SimpleNamespace(wait=lambda t:False)
        self.d=SimpleNamespace(window_size=lambda:(500,900),swipe=self.swipe)
        self.log=lambda s:None
    def check(self):pass
    def nodes(self):return page(self.page+1) if self.open else main(self.current)
    def click(self,node):
        text=node.get('text');self.actions.append(text)
        if text=='Chọn tuần':self.open=True
        else:self.current=self.page+1;self.open=False
    def swipe(self,x,a,x2,b,duration):
        self.actions.append('down' if a>b else 'up')
        self.page=max(0,min(3,self.page+(1 if a>b else -1)))
    def wait_nodes(self,predicate,message,timeout=20):
        nodes=self.nodes()
        if not predicate(nodes):raise RuntimeError('Không xác nhận được tuần')
        return nodes

class WeekPickerTests(unittest.TestCase):
    def test_current_week_does_nothing(self):
        nav=Harness(current=6);nav.select_week(6);self.assertEqual(nav.actions,[])
    def test_find_above(self):
        nav=Harness();nav.select_week(1)
        self.assertEqual(week_number(nav.nodes()),1);self.assertIn('up',nav.actions)
    def test_find_below_after_top_scan(self):
        nav=Harness();nav.select_week(4)
        self.assertEqual(week_number(nav.nodes()),4);self.assertIn('up',nav.actions);self.assertIn('down',nav.actions)
    def test_missing_week_stops(self):
        nav=Harness()
        with self.assertRaisesRegex(RuntimeError,'Không tìm thấy'):nav.select_week(8)
        self.assertTrue(nav.open);self.assertFalse(any(x.startswith('Tuần') for x in nav.actions))
    def test_main_value_not_an_option(self):
        self.assertIsNone(picker_list(main(6)))
    def test_clipped_option_not_clickable(self):
        nodes=page(6);nodes[1].set('bounds','[10,60][490,120]')
        self.assertEqual(visible_options(nodes[0]),[])
    def test_duplicate_options_stop(self):
        nav=Harness(start_page=0);original=nav.nodes
        def nodes():
            ns=original()
            if nav.open:
                SubElement(ns[0],'node',text='Tuần 1',bounds='[10,300][490,360]')
                return list(ns[0].iter('node'))
            return ns
        nav.nodes=nodes
        with self.assertRaisesRegex(RuntimeError,'nhiều mục'):nav.select_week(1)
    def test_subject_sort_uses_time_inside_subject(self):
        rows=[dict(subject='Toán',day=2,session='Sáng',slot=1,classroom='6A1'),dict(subject='HĐTN',day=4,session='Sáng',slot=1,classroom='6A1'),dict(subject='HĐTN',day=2,session='Chiều',slot=2,classroom='6A1')]
        self.assertEqual(sorted(range(3),key=lambda i:sort_key(rows[i],'subject')),[2,1,0])

if __name__=='__main__':unittest.main()
