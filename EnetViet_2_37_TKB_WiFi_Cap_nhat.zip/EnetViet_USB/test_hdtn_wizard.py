import copy
import unittest
from hdtn import hdtn_draft,merge_hdtn
from profiles import default_profile,plan

class WizardTests(unittest.TestCase):
    def setup_data(self):
        base=default_profile()
        rows=[dict(classroom='6A1',day=2,session=s,slot=n) for s,n in [('Sáng',2),('Chiều',3)]]
        draft=hdtn_draft(base,rows,7,1,2)
        result=copy.deepcopy(draft);result['courses']['hdtn']['periods']={str(n):'Bài HĐTN '+str(n) for n in range(1,106)}
        return base,draft,result
    def test_add_preserves_math(self):
        base,draft,result=self.setup_data();original=copy.deepcopy(base)
        merged=merge_hdtn(base,draft,result)
        self.assertEqual(base,original)
        for code,course in base['courses'].items():self.assertEqual(merged['courses'][code],course)
        self.assertEqual([t['period'] for t in plan(merged,7) if t['subject']=='HĐTN'],[20,21])
        self.assertEqual([r for r in merged['schedules'][0]['rows'] if r['course'] in base['courses']],base['schedules'][0]['rows'])
    def test_ai_cannot_change_selected_schedule(self):
        base,draft,result=self.setup_data()
        for r in result['schedules'][0]['rows']:r['day']=3;r['start_period']=99
        merged=merge_hdtn(base,draft,result)
        h=[t for t in plan(merged,7) if t['subject']=='HĐTN']
        self.assertEqual([t['day'] for t in h],[2,2]);self.assertEqual([t['period'] for t in h],[20,21])
    def test_collision_keeps_original(self):
        base,draft,result=self.setup_data();draft['schedules'][0]['rows'][0]['slot']=4
        with self.assertRaises(ValueError):merge_hdtn(base,draft,result)
        self.assertEqual(base,default_profile())
    def test_missing_curriculum_does_not_save(self):
        base,draft,result=self.setup_data();result['courses']['hdtn']['periods']={'1':'Chỉ có bài 1'}
        with self.assertRaisesRegex(ValueError,'chưa có đủ'):merge_hdtn(base,draft,result)
    def test_add_new_version_preserves_old(self):
        base,draft,result=self.setup_data();draft['schedules'][0]['from_week']=8
        merged=merge_hdtn(base,draft,result)
        self.assertEqual(merged['schedules'][0]['rows'],base['schedules'][0]['rows']);self.assertEqual(merged['schedules'][0]['to_week'],7);self.assertEqual(len(plan(merged,7)),15);self.assertEqual(len(plan(merged,8)),17)
