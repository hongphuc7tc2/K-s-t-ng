import copy
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from profiles import Store,default_profile
from profile_ui import ProfileEditor
from row_colors import group_colors

class ReviewTests(unittest.TestCase):
    @patch('profile_ui.messagebox.showinfo')
    def test_result_not_applied_until_approved(self,_showinfo):
        p=default_profile();result=copy.deepcopy(p);result['courses']['6']['name']='Đã sửa'
        callbacks=[];values=[]
        parent=SimpleNamespace(p=copy.deepcopy(p),vars={},integrated=SimpleNamespace(set=lambda v:None),has_integrated=SimpleNamespace(set=lambda v:None),reviewed=SimpleNamespace(set=lambda v:None),msg=SimpleNamespace(set=lambda v:values.append(v)),book=SimpleNamespace(select=lambda n:None),show_teaching_summary=lambda:None,reload=lambda:None,wait_window=lambda e:None,winfo_exists=lambda:False)
        def dialog(parent,candidate,callback,*a,**kw):
            callbacks.append((candidate,callback));return SimpleNamespace(grab_set=lambda:None)
        with patch('profile_ui.ProfileEditor',side_effect=dialog):
            ProfileEditor.accept_result(parent,result)
        self.assertEqual(parent.p,p)
        callbacks[0][0]['courses']['6']['name']='Sửa trong bảng'
        self.assertEqual(parent.p,p)
        callbacks[0][1](callbacks[0][0])
        self.assertEqual(parent.p['courses']['6']['name'],'Sửa trong bảng')
        self.assertEqual(result['courses']['6']['name'],'Đã sửa')
    def test_locked_note_not_sent(self):
        p=default_profile()
        parent=SimpleNamespace(ai_mode=SimpleNamespace(get=lambda:'Phân tích toàn bộ'),metadata=lambda:copy.deepcopy(p),files=[],has_note=SimpleNamespace(get=lambda:False),note=SimpleNamespace(get=lambda *a:'KHONG_GUI_GHI_CHU'))
        self.assertNotIn('KHONG_GUI_GHI_CHU',ProfileEditor.request_data(parent)[1])
        parent.has_note.get=lambda:True
        self.assertIn('KHONG_GUI_GHI_CHU',ProfileEditor.request_data(parent)[1])
    def test_delete_keeps_restorable_copy(self):
        with tempfile.TemporaryDirectory() as d:
            store=Store(d);p=default_profile();store.save(p)
            backup=store.delete(p['id']);self.assertEqual(store.list(),[]);self.assertTrue(backup.exists())
            restored,_=store.read_package(backup);store.save(restored);self.assertEqual(store.list()[0]['id'],p['id'])

class ColorTests(unittest.TestCase):
    def test_grouping_and_pale_colors(self):
        rows={'a':dict(session='Sáng',classroom='6A1',subject='Toán'),'b':dict(session='Chiều',classroom='6A1',subject='HĐTN'),'c':dict(session='Sáng',classroom='7A2',subject='Toán')}
        c=group_colors(rows,'day');self.assertEqual(c['a'],c['c']);self.assertNotEqual(c['a'],c['b'])
        c=group_colors(rows,'subject');self.assertEqual(c['a'],c['c']);self.assertNotEqual(c['a'],c['b'])
        c=group_colors(rows,'classroom');self.assertEqual(c['a'],c['b']);self.assertNotEqual(c['a'],c['c'])
        for color in c.values():self.assertTrue(all(int(color[i:i+2],16)>225 for i in (1,3,5)))

if __name__=='__main__':unittest.main()
