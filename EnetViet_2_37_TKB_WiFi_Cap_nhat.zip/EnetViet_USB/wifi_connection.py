"""ADB transport UI; no root, pairing code never persisted."""
import ipaddress,json,re,shutil,subprocess
from pathlib import Path
import tkinter as tk
from tkinter import ttk,messagebox
from legacy_app import ROOT
from profiles import atomic_json

def endpoint(text):
    host,sep,port=text.strip().rpartition(':')
    if not sep or not port.isdigit() or not 1<=int(port)<=65535:raise ValueError('Nhập địa chỉ dạng 192.168.1.10:37123 (IP:cổng).')
    ipaddress.IPv4Address(host)
    return host+':'+str(int(port))

def adb_command(args,input_text=None):
    exe=shutil.which('adb')
    if not exe:
        try:
            from adbutils import adb_path
            exe=adb_path()
        except Exception:raise RuntimeError('Không tìm thấy ADB. Chạy CAI_DAT.bat hoặc cài Android Platform Tools.')
    result=subprocess.run([str(exe)]+args,input=input_text,capture_output=True,text=True,timeout=30,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    output=(result.stdout+'\n'+result.stderr).strip()
    if result.returncode or re.search(r'failed|unable|cannot|error:',output,re.I):raise RuntimeError(output or 'ADB không thực hiện được lệnh.')
    return output

def attach(app,address):
    import uiautomator2 as u2
    app.log('Đang kết nối Wi-Fi tới '+address+'...')
    adb_command(['connect',address]);device=u2.connect(address);device.info
    app.d=device;atomic_json(ROOT/'ket_noi_wifi.json',{'address':address})
    app.log('Đã kết nối điện thoại qua Wi-Fi: '+address)

def open_wifi(app):
    if app.busy:app.show_progress();return
    win=tk.Toplevel(app.root);win.title('Kết nối điện thoại qua Wi-Fi');win.geometry('700x420')
    from branding import credit
    credit(win)
    saved={}
    try:saved=json.loads((ROOT/'ket_noi_wifi.json').read_text(encoding='utf-8'))
    except (OSError,ValueError):pass
    ttk.Label(win,text='Máy tính và điện thoại cùng mạng Wi-Fi.\nĐiện thoại: Tùy chọn nhà phát triển → Gỡ lỗi không dây.\nLần đầu: chọn Ghép đôi bằng mã, nhập địa chỉ ghép đôi và mã bên dưới.\nSau đó dùng IP:cổng ở trang Gỡ lỗi không dây để kết nối (hai cổng có thể khác nhau).',wraplength=650).pack(fill='x',padx=12,pady=12)
    pairing=tk.StringVar();code=tk.StringVar();address=tk.StringVar(value=saved.get('address',''))
    for title,var,secret in [('Địa chỉ ghép đôi (IP:cổng)',pairing,False),('Mã ghép đôi 6 số',code,True),('Địa chỉ kết nối (IP:cổng)',address,False)]:
        row=ttk.Frame(win);row.pack(fill='x',padx=12,pady=5)
        ttk.Label(row,text=title,width=30).pack(side='left');ttk.Entry(row,textvariable=var,show='*' if secret else '',width=30).pack(side='left')
    def pair():
        try:
            ep=endpoint(pairing.get());secret=code.get().strip()
            if not re.fullmatch(r'\d{6}',secret):raise ValueError('Mã ghép đôi phải có 6 chữ số.')
            code.set('')
            def work():
                adb_command(['pair',ep],secret+'\n');app.log('Đã ghép đôi. Nhập địa chỉ kết nối rồi bấm Kết nối Wi-Fi.')
            app.run(work)
        except Exception as exc:messagebox.showerror('Wi-Fi',str(exc),parent=win)
    def connect():
        try:ep=endpoint(address.get());app.run(lambda:attach(app,ep))
        except Exception as exc:messagebox.showerror('Wi-Fi',str(exc),parent=win)
    def via_usb():
        def work():
            import adbutils
            devices=[d for d in adbutils.adb.device_list() if ':' not in d.serial and not d.serial.startswith('adb-')]
            if len(devices)!=1:raise RuntimeError('Cắm và cho phép gỡ lỗi đúng một điện thoại USB trước.')
            serial=devices[0].serial
            info=adb_command(['-s',serial,'shell','ip','-4','addr','show','wlan0'])
            match=re.search(r'inet\s+(\d+\.\d+\.\d+\.\d+)/',info)
            if not match:raise RuntimeError('Chưa đọc được IP Wi-Fi của điện thoại.')
            ep=endpoint(match[1]+':5555');adb_command(['-s',serial,'tcpip','5555'])
            if app.stop.wait(2):raise RuntimeError('Đã dừng.')
            attach(app,ep);app.log('Đã kết nối Wi-Fi. Có thể rút cáp USB; khởi động lại điện thoại có thể cần làm lại.')
        app.run(work)
    row=ttk.Frame(win);row.pack(fill='x',padx=12,pady=12)
    ttk.Button(row,text='Ghép đôi',command=pair).pack(side='left',padx=4)
    ttk.Button(row,text='Kết nối Wi-Fi',command=connect).pack(side='left',padx=4)
    ttk.Button(row,text='Chuyển USB sang Wi-Fi',command=via_usb).pack(side='left',padx=4)
    ttk.Label(win,text='Lưu địa chỉ kết nối trên máy này; không lưu mã ghép đôi.\nCổng Wi-Fi có thể đổi khi tắt/bật gỡ lỗi không dây. Chế độ USB → Wi-Fi dùng mạng tin cậy.',wraplength=650).pack(fill='x',padx=12)
