from tkinter import ttk
CREDIT='Tác giả phần mềm: Thầy Nguyễn Hồng Phúc - GV Toán trường THCS Huỳnh Tấn Phát'
def credit(parent):
    label=ttk.Label(parent,text=CREDIT,font=('Segoe UI',9),foreground='#52606d',wraplength=850,anchor='center',justify='center')
    label.pack(side='bottom',fill='x',padx=8,pady=5)
    from button_signs import decorate_buttons
    parent.after_idle(lambda:decorate_buttons(parent) if parent.winfo_exists() else None)
    return label
