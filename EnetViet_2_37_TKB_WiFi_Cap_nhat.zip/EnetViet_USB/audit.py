"""Read-only weekly audits. No field entry, save, copy or completion actions."""
import re
from datetime import timedelta
from engine import label,bounds
from navigator import Navigator,PACKAGE,week_number
from borrow import BorrowAssistant,one,ids,value,week_info,calendar_cells
from timetable import DAYS

FIELDS=('Kiểm diện','Tiết theo PPCT','Nhận xét của giáo viên','Giáo viên xác nhận','Học tập','Kỷ luật','Vệ sinh')

def read_fields(nodes):
    result={}
    for title in FIELDS:
        labels=[n for n in nodes if label(n)==title and n.get('resource-id','').endswith('/textViewLabel')]
        if len(labels)!=1:continue
        parents=[n for n in nodes if labels[0] in list(n)]
        if len(parents)!=1:continue
        vals=[n for n in parents[0].iter('node') if n.get('class')=='android.widget.EditText' or n.get('resource-id','').endswith('/textViewValue')]
        if len(vals)==1:
            n=vals[0];text=n.get('text','').strip()
            if text==n.get('hint') or text.startswith('Chọn'):text=''
            result[title]=text
    return result

def lesson_issues(values,period):
    errors=[]
    for name in FIELDS:
        if name not in values:errors.append('Chưa đọc được '+name);continue
        text=values[name]
        if name=='Giáo viên xác nhận':
            if text!='Hoàn thành':errors.append('Chưa Hoàn thành'+(' ('+text+')' if text else ''))
        elif not text:errors.append('Thiếu '+name)
        elif name=='Tiết theo PPCT' and text!=str(period):errors.append(f'PPCT đang là {text}, đúng phải là {period}')
    return errors

class NotebookAudit(Navigator):
    def leave_form(self):
        ns=self.nodes()
        if week_number(ns) is not None:return
        backs=[n for n in ns if n.get('resource-id')==PACKAGE+':id/img_action_left']
        if len(backs)!=1:raise RuntimeError('Không đọc được nút quay lại phiếu; dừng rà soát, không bấm Lưu.')
        self.click(backs[0])
        self.wait_nodes(lambda ns:week_number(ns) is not None,'Trở về danh sách sau khi rà soát...',timeout=20)
    def audit_form(self,task):
        found={};previous=None;stalls=0
        # Start at top. Then gather independent fields over all form viewports.
        for _ in range(6):
            ns=self.nodes()
            if any(label(n)=='Lớp' for n in ns):break
            self.scroll(False)
        for _ in range(16):
            ns=self.nodes();found.update(read_fields(ns))
            if all(k in found for k in FIELDS):break
            signature=tuple((label(n),n.get('bounds')) for n in ns if label(n))
            stalls=stalls+1 if signature==previous else 0;previous=signature
            if stalls>=2:break
            self.scroll(True)
        return lesson_issues(found,task['period'])
    def audit_week(self,tasks):
        self.ensure_main();rows=[]
        for task in sorted((t for t in tasks if 2<=t['day']<=7),key=lambda t:(t['day'],t['session']=='Chiều',t['slot'])):
            self.check()
            title=f"{DAYS[task['day']]} • {task['session']} • Tiết {task['slot']} • {task['classroom']} • {task.get('subject','')}"
            self.log('Rà soát: '+title)
            if not task.get('valid'):
                rows.append((title,['Thiếu PPCT chuẩn trong hồ sơ để đối chiếu']));continue
            try:
                self.open_task(task,existing_only=True)
                errors=self.audit_form(task)
                self.leave_form()
                rows.append((title,errors))
            except RuntimeError as exc:
                self.check()  # Do not swallow Stop or a changed foreground app.
                rows.append((title,[str(exc)]))
                if week_number(self.nodes()) is None:
                    try:self.leave_form()
                    except RuntimeError as back_error:
                        rows.append(('Chưa rà soát hết tuần',[str(back_error)]));break
        if not rows:rows.append(('Tuần được chọn',['Không có tiết trong TKB từ thứ Hai đến thứ Bảy']))
        return rows

def green_dot_days(nodes,screenshot,window_size):
    """Read green indicators within observed calendar day cells, not system UI."""
    cells=calendar_cells(nodes)
    if len(cells)!=7:raise RuntimeError('Không đọc đủ 7 ô ngày để nhận diện chấm xanh.')
    cells=sorted(cells,key=lambda n:bounds(n)[0]);im=screenshot.convert('RGB');w,h=window_size
    result=[]
    for day,n in enumerate(cells,2):
        x1,y1,x2,y2=bounds(n);sx=im.width/w;sy=im.height/h
        crop=im.crop((int(x1*sx),int(y1*sy),int(x2*sx),int(y2*sy)))
        count=sum(1 for r,g,b in crop.getdata() if g>110 and g-r>35 and g-b>15)
        if count>=max(3,int(crop.width*crop.height*.0006)):result.append(day)
    return result

class BorrowAudit(BorrowAssistant):
    def all_cards(self):
        ns=self.nodes();region=one(ns,'rvData');cards=self.titles(ns)
        current=[name for name,_ in cards]
        if len(current)!=len(set(current)):raise RuntimeError('Có phiếu trùng tiết/buổi; chưa phân biệt được từng phiếu.')
        # Yield visible cards first: edit/read/back before any discovery scrolling.
        for name in current:yield name
        # A non-scrollable list is already complete. Do not probe both directions.
        if region.get('scrollable')=='false':return
        # Audit needs all cards, including those below the viewport.
        names=list(current)
        for forward in (False,True):
            previous=None;stalls=0
            for _ in range(18):
                ns=self.nodes();cards=self.titles(ns)
                current=[name for name,_ in cards]
                if len(current)!=len(set(current)):raise RuntimeError('Có phiếu trùng tiết/buổi; chưa phân biệt được từng phiếu.')
                for name in current:
                    if name not in names:
                        names.append(name)
                        yield name
                signature=tuple((name,n.get('bounds')) for name,n in cards)
                stalls=stalls+1 if signature==previous else 0;previous=signature
                if stalls>=2:break
                self.swipe_region(one(ns,'rvData'),forward)
            else:raise RuntimeError('Danh sách phiếu quá dài; chưa rà soát hết.')
    def safe_cards(self,day,rows):
        try:yield from self.all_cards()
        except RuntimeError as exc:
            self.check();rows.append((DAYS[day],['Chưa rà soát hết phiếu trong ngày: '+str(exc)]))
    def open_audit_card(self,name):
        for forward in (False,True):
            previous=None;stalls=0
            for _ in range(18):
                ns=self.nodes();cards=self.titles(ns);region=one(ns,'rvData');rb=bounds(region)
                matches=[n for title,n in cards if title==name]
                if len(matches)>1:raise RuntimeError('Trùng phiếu '+name)
                if matches:
                    b=bounds(matches[0])
                    if b[1]>=rb[1] and b[3]<=rb[3] and b[3]-b[1]>30:return self.open_card(name)
                sig=tuple((t,n.get('bounds')) for t,n in cards)
                stalls=stalls+1 if sig==previous else 0;previous=sig
                if stalls>=2:break
                self.swipe_region(region,forward)
        raise RuntimeError('Chưa mở được phiếu '+name)
    def audit_week(self,week):
        self.ensure_entry();start=self.go_week(week);rows=[];count=0
        self.wait_nodes(lambda ns:week_info(ns)[0]==week,'Chờ lịch tuần để rà soát...')
        if self.stop.wait(1):self.check()
        ns=self.calendar_ready();self.check()
        try:
            days=[d for d in green_dot_days(ns,self.d.screenshot(),self.d.window_size()) if d<=7]
            self.log('Ngày có chấm xanh: '+(', '.join(DAYS[d] for d in days) or 'chưa nhận thấy'))
        except Exception as exc:
            self.check();days=[];self.log('Chưa nhận diện chấm xanh: '+str(exc))
        # No dots is not proof of no loans (theme/colour/loading can differ).
        marked_days=set(days)
        if not days:
            days=list(range(2,8));self.log('Đối chiếu danh sách từng ngày để xác nhận tuần có phiếu hay chưa.')
        for day in days:
            try:date=self.day(day,start)
            except RuntimeError as exc:
                self.check();rows.append((DAYS[day],['Chưa rà soát được ngày này: '+str(exc)]))
                rows.append(('Chưa rà soát hết tuần',['Lịch ngày chưa sẵn sàng. Mở lịch Thiết bị rồi chạy rà soát lại.']))
                break
            seen_card=False
            for name in self.safe_cards(day,rows):
                seen_card=True
                title=f'{DAYS[day]} ({date:%d/%m/%Y}) • {name}'
                try:
                    ns=self.open_audit_card(name);count+=1
                    room=value(ns,'Lớp');ppct=value(ns,'Tiết PPCT').strip()
                    errors=[]
                    if label(one(ns,'tvSubTitle'))!='Ngày '+date.strftime('%d/%m/%Y'):errors.append('Ngày trên phiếu không khớp ngày đang rà soát')
                    if not re.fullmatch(r'\d+(?:\s*[,;]\s*\d+)*',ppct):errors.append('Chưa có số tiết PPCT' if not ppct or ppct.startswith('Chọn') else 'PPCT chưa đọc rõ: '+ppct)
                    rows.append((title+' • '+room,errors));self.back()
                except RuntimeError as exc:
                    self.check();rows.append((title,[str(exc)]))
                    if not self.main():
                        try:self.back()
                        except RuntimeError:
                            rows.append(('Chưa rà soát hết tuần',['Không trở về được danh sách phiếu']));return rows
            if not seen_card and day in marked_days:
                rows.append((DAYS[day],['Có chấm xanh nhưng chưa đọc được phiếu mượn; cần kiểm tra lại']))
        rows.insert(0,('Tình hình mượn trong tuần',[] if count else ['Chưa xác nhận được phiếu mượn nào từ thứ Hai đến thứ Bảy']))
        return rows
