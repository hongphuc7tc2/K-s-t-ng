from teacher_setup import preserve_setup
"""Optional explicit AI analysis; credentials are managed separately by ai_settings."""
import base64
import json
import mimetypes
import urllib.request
import urllib.error
import zipfile
from pathlib import Path

INSTRUCTIONS=(Path(__file__).parent/'LENH_PHAN_TICH_AI.txt').read_text(encoding='utf-8')

def prompt(profile,note):
    return INSTRUCTIONS+'\nYêu cầu của GV: '+note+'\nProfile hiện tại/mẫu cần hoàn thiện:\n'+json.dumps(profile,ensure_ascii=False)


def content_for(path):
    p=Path(path); ext=p.suffix.lower()
    if p.stat().st_size>18_000_000: raise ValueError('Tệp quá 18 MB: '+p.name)
    if ext in ('.png','.jpg','.jpeg','.webp'):
        mime=mimetypes.guess_type(p.name)[0] or 'image/png'
        return {'type':'input_image','image_url':'data:'+mime+';base64,'+base64.b64encode(p.read_bytes()).decode()}
    if ext=='.pdf': return {'type':'input_file','filename':p.name,'file_data':'data:application/pdf;base64,'+base64.b64encode(p.read_bytes()).decode()}
    if ext=='.docx':
        import xml.etree.ElementTree as ET
        with zipfile.ZipFile(p) as z:
            if sum(i.file_size for i in z.infolist())>80_000_000: raise ValueError('File Word giải nén quá lớn.')
            ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
            body=ET.fromstring(z.read('word/document.xml')).find('w:body',ns)
            lines=[]
            for element in body:
                if element.tag.endswith('}tbl'):
                    for row in element.findall('w:tr',ns):
                        lines.append(' | '.join('\n'.join(''.join(('\n' if t.tag in ("{"+ns['w']+"}br","{"+ns['w']+"}cr") else t.text or '') for t in para.iter() if t.tag in ("{"+ns['w']+"}t","{"+ns['w']+"}br","{"+ns['w']+"}cr")) for para in cell.findall('.//w:p',ns)) for cell in row.findall('w:tc',ns)))
                else:
                    text=' '.join(t.text or '' for t in element.findall('.//w:t',ns))
                    if text:lines.append(text)
            text='\n'.join(lines)
    elif ext=='.xls':
        import xlrd
        book=xlrd.open_workbook(p)
        text='\n'.join('SHEET '+sheet.name+'\n'+'\n'.join(' | '.join(str(x) for x in sheet.row_values(r)) for r in range(sheet.nrows)) for sheet in book.sheets())
    elif ext=='.xlsx':
        import openpyxl
        w=openpyxl.load_workbook(p,read_only=True,data_only=True)
        lines=[]
        for sheet in w:
            lines.append('SHEET '+sheet.title)
            for row in sheet.iter_rows():
                vals=[f'{cell.column_letter}:{cell.value}' for cell in row if cell.value is not None]
                if vals: lines.append(' | '.join(vals))
        w.close(); text='\n'.join(lines)
    elif ext in ('.txt','.csv','.json'): text=p.read_text(encoding='utf-8-sig')
    else: raise ValueError('Dùng ảnh/PDF/Excel XLSX hoặc XLS/Word DOCX/CSV/TXT/JSON. Word DOC cũ cần lưu thành DOCX hoặc PDF.')
    if len(text)>350000: raise ValueError('Bảng dữ liệu quá dài; tách file nhỏ hơn.')
    return {'type':'input_text','text':'FILE '+p.name+'\n'+text}


def analyze(profile,note,files,api_key,model,provider="OpenAI",progress=None):
    progress=progress or (lambda message:None)
    progress("Đang đọc và chuẩn bị tài liệu…")
    if provider=="Gemini": return analyze_gemini(profile,note,files,api_key,model,progress)
    if provider!="OpenAI": raise ValueError("Nhà cung cấp AI không hợp lệ.")
    if sum(Path(f).stat().st_size for f in files)>30_000_000: raise ValueError('Tổng tệp phân tích tối đa 30 MB.')
    content=[{'type':'input_text','text':prompt(profile,note)}]
    for f in files: content += [{'type':'input_text','text':'Nguồn: '+Path(f).name}]+contents_for(f)
    body={'model':model,'store':False,'input':[{'role':'user','content':content}], 'max_output_tokens':24000}
    req=urllib.request.Request('https://api.openai.com/v1/responses',data=json.dumps(body).encode(),headers={'Authorization':'Bearer '+api_key,'Content-Type':'application/json'})
    progress("Đang gửi yêu cầu / chờ AI trả kết quả (không có % tiến độ từ API)…")
    try:
        with urllib.request.urlopen(req,timeout=240) as r: result=json.load(r)
    except urllib.error.HTTPError as e:
        raise RuntimeError(f'API trả lỗi HTTP {e.code}. Kiểm tra khóa, model và hạn mức; khóa không được ghi vào nhật ký.') from None
    progress('Đã nhận phản hồi; đang kiểm tra dữ liệu…')
    if result.get('status')!='completed': raise RuntimeError('Kết quả AI chưa đầy đủ; không dùng dữ liệu bị cắt.')
    text=''.join(c.get('text','') for o in result.get('output',[]) if o.get('type')=='message' for c in o.get('content',[]) if c.get('type')=='output_text').strip()
    if text.startswith('```'): text=text.split('\n',1)[1].rsplit('```',1)[0].strip()
    parsed=json.loads(text); parsed['id']=profile['id']; parsed['reviewed']=False
    return check_analysis(preserve_setup(profile,parsed))


def chatgpt_request(note):
    return ("Tôi đính kèm bộ hồ sơ ZIP xuất từ phần mềm eNetViet USB. "
            "Hãy mở ZIP, đọc YEU_CAU_PHAN_TICH.txt, profile_mau.json và các tài liệu trong tai_lieu/. "
            "Thực hiện đúng quy tắc trong YEU_CAU_PHAN_TICH.txt.\n\n"
            "Yêu cầu cho lần này:\n"+note+"\n\n"
            "Giữ nguyên id hồ sơ và các dữ liệu ngoài phạm vi cập nhật. "
            "Đọc ô PPCT gộp theo thứ tự bài: với hai tiết và hai bài, bài cuối thuộc tiết sau, "
            "toàn bộ phần phía trên thuộc tiết đầu; không chép nguyên ô cho cả hai tiết. "
            "Không tự đoán khi thiếu dữ liệu; hãy hỏi tôi chỗ cần làm rõ.\n"
            "Khi đủ dữ liệu, tạo tệp profile.json hoàn chỉnh, UTF-8, schema 2, reviewed=false "
            "để tôi tải xuống và nhập lại phần mềm. Không chỉ trả đoạn JSON thay đổi. "
            "Kèm tóm tắt những gì đã cập nhật để tôi kiểm tra. "
            "Nếu không đọc được ZIP, hãy báo để tôi giải nén và gửi các tệp bên trong.")


def export_request(profile,note,files,target):
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('YEU_CAU_PHAN_TICH.txt',prompt(profile,note)+'\nHãy tạo profile.json hoàn chỉnh để nhập vào phần mềm.')
        z.writestr('LENH_GUI_CHATGPT.txt',chatgpt_request(note))
        z.writestr('profile_mau.json',json.dumps(profile,ensure_ascii=False,indent=2))
        for i,f in enumerate(files): z.write(f,'tai_lieu/'+str(i+1)+'_'+Path(f).name)


def check_analysis(parsed):
    if not isinstance(parsed,dict): raise ValueError('AI chưa trả một hồ sơ JSON hợp lệ.')
    questions=parsed.get('unresolved_questions',[])
    if questions:
        raise ValueError('Cần bổ sung vào Ghi chú rồi phân tích lại:\n'+'\n'.join(str(q) for q in questions))
    from profiles import validate
    from ppct_cleanup import repair_merged_lessons
    parsed=repair_merged_lessons(parsed)
    validate(parsed)
    for rev in parsed['schedules']:
        rev['rows'].sort(key=lambda r:(r['day'],r['session']=='Chiều',r['slot']))
    return parsed


def analyze_gemini(profile,note,files,api_key,model,progress=None):
    progress=progress or (lambda message:None)
    import re
    model=model.removeprefix('models/').strip()
    if not re.fullmatch(r'[a-zA-Z0-9_.-]+',model): raise ValueError('Tên model Gemini không hợp lệ.')
    parts=[{'text':prompt(profile,note)}]
    for f in files:
        parts.append({'text':'Nguồn: '+Path(f).name})
        for content in contents_for(f):
            if content['type']=='input_text': parts.append({'text':content['text']})
            else:
                uri=content['image_url'] if content['type']=='input_image' else content['file_data']
                header,data=uri.split(',',1)
                parts.append({'inlineData':{'mimeType':header[5:].split(';')[0],'data':data}})
    body={'contents':[{'role':'user','parts':parts}], 'generationConfig':{'responseMimeType':'application/json'}}
    payload=json.dumps(body).encode()
    if len(payload)>19_000_000: raise ValueError('Yêu cầu Gemini quá lớn sau mã hóa (tối đa 19 MB). Chia nhỏ tệp hoặc nén PDF/ảnh rồi thử lại.')
    req=urllib.request.Request('https://generativelanguage.googleapis.com/v1beta/models/'+model+':generateContent',data=payload,headers={'x-goog-api-key':api_key.strip(),'Content-Type':'application/json'})
    progress("Đang gửi yêu cầu / chờ AI trả kết quả (không có % tiến độ từ API)…")
    try:
        with urllib.request.urlopen(req,timeout=240) as r: result=json.load(r)
    except urllib.error.HTTPError as e:
        hints={400:'Kiểm tra định dạng khóa, model và tài liệu.',401:'Khóa không hợp lệ.',403:'Khóa chưa có quyền Gemini API hoặc bị giới hạn.',404:'Model không tồn tại hoặc tài khoản chưa có quyền dùng.',429:'Hết hạn mức hoặc gửi quá nhanh.'}
        raise RuntimeError('Gemini HTTP '+str(e.code)+': '+hints.get(e.code,'Dịch vụ chưa xử lý được; thử lại sau.')) from None
    progress('Đã nhận phản hồi; đang kiểm tra dữ liệu…')
    candidates=result.get('candidates',[])
    if len(candidates)!=1 or candidates[0].get('finishReason')!='STOP':
        raise RuntimeError('Gemini chưa trả kết quả đầy đủ hoặc đã chặn yêu cầu. Không nhập bản bị cắt; giảm số tệp hoặc đổi model.')
    text=''.join(p.get('text','') for p in candidates[0].get('content',{}).get('parts',[]) if not p.get('thought')).strip()
    parsed=json.loads(text)
    if not isinstance(parsed,dict):raise ValueError('Gemini chưa trả hồ sơ hợp lệ.')
    parsed['id']=profile['id'];parsed['reviewed']=False
    return check_analysis(preserve_setup(profile,parsed))


def contents_for(path):
    p=Path(path);items=[content_for(p)]
    if p.suffix.lower()=='.docx':
        with zipfile.ZipFile(p) as z:
            for info in z.infolist():
                if info.filename.startswith('word/media/'):
                    ext=Path(info.filename).suffix.lower()
                    if ext not in ('.png','.jpg','.jpeg','.webp'):
                        raise ValueError('Word có ảnh không hỗ trợ ('+ext+'). Xuất Word sang PDF để phân tích đủ nội dung.')
                    mime=mimetypes.guess_type(info.filename)[0] or 'image/png'
                    items.append({'type':'input_text','text':'Ảnh nhúng trong Word: '+Path(info.filename).name})
                    items.append({'type':'input_image','image_url':'data:'+mime+';base64,'+base64.b64encode(z.read(info)).decode()})
    return items
