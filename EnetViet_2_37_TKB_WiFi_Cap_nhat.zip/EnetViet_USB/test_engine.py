import json
import threading
import unittest
from pathlib import Path
from engine import FormAssistant, period_number


class FakeDevice:
    def __init__(self, classroom='6A8', subject='Toán', existing=False):
        self.actions = []
        labels = ['Ghi sổ đầu bài','Lớp',classroom,'Môn học',subject,'Kiểu giảng dạy','Lên lớp','Kiểm diện','Tiết theo PPCT', '21' if existing else 'Chọn tiết PPCT...', 'Bài dạy']
        self.xml = '<hierarchy>' + ''.join(f'<node text="{t}" bounds="[0,{i*30}][300,{i*30+20}]"/>' for i,t in enumerate(labels)) + '</hierarchy>'

    def app_current(self):
        return {'package':'sample.enetviet'}

    def dump_hierarchy(self):
        return self.xml

    def click(self, *args):
        self.actions.append(args)


class Tests(unittest.TestCase):
    def test_exact_number(self):
        self.assertEqual(period_number('Tiết PPCT: 21'),21)
        self.assertEqual(period_number('Tiết PPCT: 121'),121)
        self.assertIsNone(period_number('Bài 21: Nội dung'))
        self.assertIsNone(period_number('Tiết PPCT: 21;22'))

    def test_wrong_class_never_clicks(self):
        d = FakeDevice(classroom='6A1')
        with self.assertRaises(RuntimeError):
            FormAssistant(d,threading.Event(),print).fill('6A8',21)
        self.assertFalse(d.actions)

    def test_wrong_subject_never_clicks(self):
        d = FakeDevice(subject='HĐTN')
        with self.assertRaises(RuntimeError):
            FormAssistant(d,threading.Event(),print).fill('6A8',21)
        self.assertFalse(d.actions)

    def test_existing_never_clicks(self):
        d = FakeDevice(existing=True)
        with self.assertRaises(RuntimeError):
            FormAssistant(d,threading.Event(),print).fill('6A8',21)
        self.assertFalse(d.actions)

    def test_stop_never_clicks(self):
        d = FakeDevice()
        stop = threading.Event()
        stop.set()
        with self.assertRaises(RuntimeError):
            FormAssistant(d,stop,print).fill('6A8',21)
        self.assertFalse(d.actions)

    def test_curriculum(self):
        data = json.loads((Path(__file__).parent/'ppct.json').read_text(encoding='utf-8'))
        for grade in ['6','7']:
            weeks = data[grade]['weeks']
            self.assertEqual(len(weeks),35)
            for w in range(1,36):
                self.assertEqual([r['period'] for r in weeks[str(w)]],list(range(4*w-3,4*w+1)))


if __name__ == '__main__':
    unittest.main()
