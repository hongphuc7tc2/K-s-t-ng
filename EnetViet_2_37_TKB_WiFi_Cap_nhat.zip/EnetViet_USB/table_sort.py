from row_colors import paint_rows
"""Display-only sorting: stable row IDs preserve edits and PPCT assignment."""
import re

def class_key(name):
    return tuple((1,int(part)) if part.isdigit() else (0,part.casefold()) for part in re.split(r'(\d+)',name))

def sort_key(row,mode):
    time=(row['day'],row['session']=='Chiều',row['slot'])
    if mode=='subject':return (row.get('subject',row.get('kind','')).casefold(),*time,class_key(row['classroom']))
    return (class_key(row['classroom']),*time) if mode=='classroom' else (*time,class_key(row['classroom']))

class TimetableSort:
    def __init__(self,tree,rows,class_column='classroom',before_sort=None,subject_column=None):
        self.subject_column=subject_column;self.tree=tree;self.rows=rows;self.class_column=class_column;self.mode='day';self.before_sort=before_sort
        tree.heading('day',command=lambda:self.select('day'))
        tree.heading(class_column,command=lambda:self.select('classroom'))
        if subject_column:tree.heading(subject_column,command=lambda:self.select('subject'))
        self.headers()
    def headers(self):
        self.tree.heading('day',text='Thứ ▲' if self.mode=='day' else 'Thứ ⇅')
        self.tree.heading(self.class_column,text='Lớp ▲' if self.mode=='classroom' else 'Lớp ⇅')
        if self.subject_column:self.tree.heading(self.subject_column,text='Môn ▲' if self.mode=='subject' else 'Môn ⇅')
    def select(self,mode):
        if self.before_sort:self.before_sort()
        self.mode=mode;self.apply()
    def apply(self):
        rows=self.rows()
        for index,iid in enumerate(sorted(self.tree.get_children(),key=lambda iid:sort_key(rows[iid],self.mode))):
            self.tree.move(iid,'',index)
        paint_rows(self.tree,rows,self.mode)
        self.headers()
