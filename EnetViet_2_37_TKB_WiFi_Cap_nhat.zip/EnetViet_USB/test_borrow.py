import unittest
import tempfile
from pathlib import Path
from datetime import date
from types import SimpleNamespace
import xml.etree.ElementTree as E
from borrow import BorrowAssistant,week_info,match_task,value,ids,one
from engine import label

def fixture(name):return list(E.parse(Path(__file__).parent/'borrow_fixtures'/(name+'.xml')).getroot().iter('node'))
def task():return dict(day=2,session='Sáng',slot=4,classroom='6A8',subject='Toán',period=21,valid=True)

class BorrowTests(unittest.TestCase):
    def test_actual_calendar_week(self):self.assertEqual(week_info(fixture('main')),(6,date(2026,10,12)))
    def test_actual_form_values(self):
        ns=fixture('form')
        self.assertEqual(value(ns,'Lớp'),'6A8');self.assertEqual(value(ns,'Tiết PPCT'),'21')
        self.assertEqual(match_task(ns,[task()],2,date(2026,10,12)),task())
    def test_wrong_date_rejected(self):
        with self.assertRaisesRegex(RuntimeError,'Ngày'):match_task(fixture('form'),[task()],2,date(2026,10,13))
    def test_wrong_class_or_subject_rejected(self):
        for field,val in [('classroom','6A1'),('subject','HĐTN'),('slot',3),('session','Chiều')]:
            t=task();t[field]=val
            with self.assertRaises(RuntimeError):match_task(fixture('form'),[t],2,date(2026,10,12))
    def test_duplicate_tkb_rejected(self):
        with self.assertRaises(RuntimeError):match_task(fixture('form'),[task(),task()],2,date(2026,10,12))
    def test_actual_card_edit_button(self):
        nav=BorrowAssistant.__new__(BorrowAssistant)
        cards=nav.titles(fixture('main'));self.assertEqual([name for name,_ in cards],['Tiết 4 Sáng'])
        self.assertTrue(cards[0][1].get('resource-id').endswith('/tvEditBorrowed'))
    def test_actual_search_and_week_mark(self):
        ns=fixture('search');self.assertEqual(label(one(ns,'etSearchLesson')),'21')
        self.assertEqual([label(n) for n in ids(ns,'tvSearchLesson')],['21'])
        ns=fixture('weeks');marked=[n for n in ns if ids(list(n),'animatedcheckbox') and ids(list(n),'tvName')]
        self.assertEqual(len(marked),1);self.assertTrue(label(one(list(marked[0]),'tvName')).startswith('Tuần 6:'))
    def test_copy_goes_directly_to_source_without_inventory(self):
        nav=BorrowAssistant.__new__(BorrowAssistant);nav.identity='teacher|year';nav.journal={};actions=[]
        nav.inventory=lambda *a:self.fail('must not inspect days before copying')
        nav.go_week=lambda w:actions.append(('week',w))
        nav.log=lambda s:None;nav.nodes=lambda:fixture('main')
        def click(n):actions.append(('click',n.get('resource-id').split('/')[-1]));raise RuntimeError('test reached copy button')
        nav.click=click
        with self.assertRaisesRegex(RuntimeError,'test reached'):nav.copy_week(5,6,[task()])
        self.assertEqual(actions,[('week',5),('click','tvCloneBill')])
    def test_unknown_copy_outcome_blocks_repeat(self):
        nav=BorrowAssistant.__new__(BorrowAssistant);nav.identity='teacher|year';nav.journal={'teacher|year|copy|5|6':'saving'}
        with self.assertRaisesRegex(RuntimeError,'trùng'):nav.copy_week(5,6,[task()])
    def test_correct_ppct_no_write(self):
        nav=BorrowAssistant.__new__(BorrowAssistant);nav.identity='teacher|year';nav.nodes=lambda:fixture('form');nav.log=lambda s:None
        actions=[];nav.mark=lambda k,s:actions.append(s);nav.back=lambda:actions.append('back')
        nav.update_form(task(),date(2026,10,12));self.assertEqual(actions,['back'])
    def test_unknown_save_outcome_blocks_new_write(self):
        nav=BorrowAssistant.__new__(BorrowAssistant);nav.identity='teacher|year';nav.nodes=lambda:fixture('form');nav.log=lambda s:None
        t=task();t['period']=22
        ns=fixture('form')
        for n in ids(ns,'tvHint'):
            if label(n)=='21':n.set('text','')
        nav.nodes=lambda:ns
        nav.journal={'teacher|year|save|2026-10-12|4|Sáng|6A8|Toán':'saving'}
        with self.assertRaisesRegex(RuntimeError,'chưa xác nhận'):nav.update_form(t,date(2026,10,12))

    def test_change_ppct_keep_equipment_save_and_read_back(self):
        nav=BorrowAssistant.__new__(BorrowAssistant);nav.identity='teacher|year';nav.journal={};nav.log=lambda s:None
        form=fixture('form');search=fixture('search');state=['form'];actions=[]
        for n in ids(form,'tvHint'):
            if label(n)=='21':n.set('text','Chọn tiết PPCT')
        t=task();t['period']=22
        def nodes():
            if state[0]=='search':return search
            if state[0]=='prompt':return [E.Element('node',text='Quý Thầy/Cô có muốn thay đổi lại danh sách thiết bị khi thay đổi Tiết PPCT không?'),E.Element('node',text='KHÔNG')]
            if state[0]=='main':return fixture('main')
            return form
        def click(n):
            text=label(n);actions.append(text)
            if text=='Tiết PPCT':state[0]='search'
            elif text=='22':state[0]='prompt'
            elif text=='KHÔNG':
                state[0]='form'
                for n in ids(form,'tvHint'):
                    if label(n)=='Chọn tiết PPCT':n.set('text','22')
            elif text=='Lưu':state[0]='main'
        def set_text(v):
            for n in ids(search,'etSearchLesson')+ids(search,'tvSearchLesson'):n.set('text',v)
        class Device:
            def __call__(self,**kw):return SimpleNamespace(set_text=set_text)
            def shell(self,cmd):return SimpleNamespace(output='mInputShown=false')
        nav.d=Device();nav.check=lambda:None;nav.nodes=nodes;nav.click=click
        def wait(pred,message,timeout=20):
            ns=nodes()
            if not pred(ns):raise RuntimeError(message)
            return ns
        nav.wait_nodes=wait;nav.mark=lambda k,s:actions.append(s)
        nav.open_card=lambda name:self.fail('Không mở lại phiếu vừa lưu')
        nav.back=lambda:actions.append('back')
        nav.update_form(t,date(2026,10,12))
        self.assertEqual(actions,['Tiết PPCT','22','KHÔNG','saving','Lưu','saved'])

    def test_any_existing_number_skips_even_when_tkb_differs(self):
        nav=BorrowAssistant.__new__(BorrowAssistant);nav.nodes=lambda:fixture('form');nav.log=lambda s:None
        actions=[];nav.back=lambda:actions.append('back')
        self.assertFalse(nav.process_card([],2,date(2026,10,12)))
        self.assertEqual(actions,['back'])
    def test_day_list_does_not_scroll(self):
        nav=BorrowAssistant.__new__(BorrowAssistant);nav.nodes=lambda:fixture('main');nav.require_main=lambda:None
        nav.swipe_region=lambda *a: self.fail('Không được cuộn danh sách ngày')
        self.assertEqual(nav.scan_cards(),['Tiết 4 Sáng'])
        actions=[];nav.click=lambda n:actions.append(label(n));nav.wait_nodes=lambda *a:fixture('form')
        nav.open_card('Tiết 4 Sáng');self.assertEqual(actions,['Chỉnh sửa'])
    def test_blank_ppct_matches_class_before_writing(self):
        nav=BorrowAssistant.__new__(BorrowAssistant);ns=fixture('form');nav.nodes=lambda:ns
        for n in ids(ns,'tvHint'):
            if label(n)=='21':n.set('text','')
        actions=[];nav.update_form=lambda t,d:actions.append((t['classroom'],t['period']))
        self.assertTrue(nav.process_card([task()],2,date(2026,10,12)))
        self.assertEqual(actions,[('6A8',21)])
