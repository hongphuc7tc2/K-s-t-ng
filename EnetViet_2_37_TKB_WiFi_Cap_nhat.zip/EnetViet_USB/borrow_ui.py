import copy
import tkinter as tk
from tkinter import ttk,messagebox,font as tkfont
from profiles import plan
from timetable import DAYS,SESSIONS
from branding import credit
from borrow import BorrowAssistant
from legacy_app import ROOT

def title_dimensions(titles,font):
    lines=[str(title).split('\n') for title in titles]
    height=max(32,max((len(parts) for parts in lines),default=1)*font.metrics('linespace')+14)
    width=max(460,max((font.measure(line) for parts in lines for line in parts),default=0)+32)
    return height,width

def open_borrow(app):
    if app.busy:return
    win=tk.Toplevel(app.root);win.title('Mượn đồ dùng — MISA SISAP')
    win.geometry(f'{min(1020,win.winfo_screenwidth()-60)}x{min(650,win.winfo_screenheight()-100)}')
    win.transient(app.root);credit(win)
    source=tk.IntVar(value=5);target=tk.IntVar(value=int(app.week.get()));mode=tk.StringVar(value='existing')
    profile=copy.deepcopy(app.profile)
    ttk.Label(win,text='Mượn đồ dùng • '+profile['name'],font=('Segoe UI',14,'bold')).pack(anchor='w',padx=12,pady=8)
    row=ttk.Frame(win);row.pack(fill='x',padx=12)
    for title,var in [('Tuần mẫu đã hoàn tất',source),('Tuần cần cập nhật',target)]:
        ttk.Label(row,text=title).pack(side='left',padx=5)
        ttk.Combobox(row,textvariable=var,values=list(range(1,54)),width=6,state='readonly').pack(side='left',padx=5)
    ttk.Radiobutton(win,text='Sao chép tuần mẫu rồi cập nhật PPCT (tuần đích phải chưa có phiếu)',variable=mode,value='copy').pack(anchor='w',padx=15,pady=5)
    ttk.Radiobutton(win,text='Chỉ điền PPCT còn trống — không sao chép thêm',variable=mode,value='existing').pack(anchor='w',padx=15)
    ttk.Label(win,text='Mở MISA SISAP ở trang có Thiết bị, phần mềm sẽ tự vào Kế hoạch mượn.\nPhiếu đã có số PPCT được giữ nguyên. Phiếu trống mới đối chiếu lớp, môn, ngày, buổi, tiết với TKB.\nGiữ đồ dùng và số lượng mẫu; bỏ ngày không có phiếu và Chủ Nhật. Bảng này dùng toàn bộ lớp của hồ sơ.',wraplength=930).pack(anchor='w',padx=12,pady=8)
    footer=ttk.Frame(win);footer.pack(side='bottom',fill='x',padx=12,pady=10)
    status=tk.StringVar();ttk.Label(win,textvariable=status,wraplength=930).pack(side='bottom',fill='x',padx=12,pady=5)
    frame=ttk.Frame(win);frame.pack(fill='both',expand=True,padx=12)
    frame.rowconfigure(0,weight=1);frame.columnconfigure(0,weight=1)
    cols=('day','session','slot','classroom','subject','period','title')
    style=ttk.Style(win);style_name=f'Borrow{id(win)}.Treeview'
    table_font=tkfont.Font(root=win,font=style.lookup('Treeview','font') or ('Segoe UI',11))
    style.configure(style_name,font=table_font,rowheight=32)
    tree=ttk.Treeview(frame,columns=cols,show='headings',style=style_name)
    for c,t,w in zip(cols,['Thứ','Buổi','Tiết','Lớp','Môn','PPCT','Bài dạy'],[100,110,50,80,110,60,460]):
        tree.heading(c,text=t);tree.column(c,width=w,minwidth=w,stretch=False)
    tree.grid(row=0,column=0,sticky='nsew')
    x=ttk.Scrollbar(frame,orient='horizontal',command=tree.xview);x.grid(row=1,column=0,sticky='ew')
    y=ttk.Scrollbar(frame,orient='vertical',command=tree.yview);y.grid(row=0,column=1,sticky='ns');tree.configure(xscrollcommand=x.set,yscrollcommand=y.set)
    tasks=[]
    def refresh(*args):
        tasks.clear();tree.delete(*tree.get_children())
        try:
            tasks.extend(plan(profile,target.get()))
            height,width=title_dimensions([t['title'] for t in tasks],table_font)
            style.configure(style_name,rowheight=height)
            tree.column('title',width=width,minwidth=460)
            for t in tasks:tree.insert('','end',values=(DAYS[t['day']],SESSIONS[t['session']],t['slot'],t['classroom'],t.get('subject','Toán'),t['period'],t['title']))
            status.set(f'{len(tasks)} tiết theo TKB tuần {target.get()}. Chỉ điền những phiếu mượn còn trống PPCT.')
        except Exception as e:status.set(str(e))
    def start():
        try:
            app.require_device();refresh()
            if not tasks:raise ValueError('Thiếu TKB; sửa hồ sơ trước khi chạy.')
            src,dst=source.get(),target.get();do_copy=mode.get()=='copy'
            if do_copy and src==dst:raise ValueError('Tuần mẫu và tuần đích phải khác nhau.')
            if any(t.get('schedule_provisional') for t in tasks):raise ValueError('Tuần này đang dùng TKB tạm suy ra. Thêm TKB đúng khoảng tuần trước khi mượn đồ dùng.')
            action=f'Sao chép toàn bộ phiếu tuần {src} sang tuần {dst}, sau đó điền PPCT còn trống.' if do_copy else f'Điền PPCT còn trống cho các phiếu của tuần {dst}.'
            if do_copy:action+='\nTuần đích phải chưa có phiếu. Phần mềm không dò từng ngày trước khi sao chép.'
            if not messagebox.askokcancel('Kiểm tra trước khi mượn đồ dùng',action+'\n\nGiữ nguyên thiết bị và số lượng. Đã mở đúng tài khoản giáo viên/năm học và kiểm tra TKB bên dưới? Phần mềm sẽ bấm Lưu các phiếu.',parent=win):return
            work=copy.deepcopy(tasks);win.destroy()
            app.run(lambda:BorrowAssistant(app.d,app.stop,app.log,ROOT/'tien_do_muon_do_dung.json',profile['id'],profile.get('school_year','')).run_week(src,dst,work,do_copy))
        except Exception as e:messagebox.showerror('Mượn đồ dùng',str(e),parent=win)
    from audit_ui import start_audit
    ttk.Button(footer,text='Rà soát phiếu mượn',command=lambda:start_audit(app,'borrow',target.get())).pack(side='left')
    ttk.Button(footer,text='Bắt đầu mượn đồ dùng',command=start).pack(side='right')
    ttk.Button(footer,text='Đóng',command=win.destroy).pack(side='right',padx=8)
    target.trace_add('write',refresh);refresh()
