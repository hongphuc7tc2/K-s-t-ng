import unittest
from types import SimpleNamespace
from xml.etree.ElementTree import Element
from engine import FormAssistant,period_number

class SearchTests(unittest.TestCase):
    def helper(self,keyboard=False,results=(31,131)):
        f=FormAssistant.__new__(FormAssistant);f.check=lambda:None;f.log=lambda s:None
        actions=[];query=['Tìm kiếm']
        def nodes():
            ns=[Element('node',text='Chọn Tiết PPCT',bounds='[0,100][500,145]'),
                Element('node',attrib={'class':'android.widget.EditText','text':query[0],'bounds':'[20,150][480,190]'}),
                Element('node',attrib={'class':'android.widget.EditText','text':'Nhập nhận xét','bounds':'[20,500][480,550]'})]
            if query[0]=='31':
                ns.extend(Element('node',text=f'Tiết PPCT: {n}',bounds=f'[20,{210+i*60}][480,{250+i*60}]') for i,n in enumerate(results))
            return ns
        def set_text(v):query[0]=v;actions.append(('input',v))
        f.d=SimpleNamespace(xpath=lambda s:SimpleNamespace(set_text=set_text),shell=lambda cmd:SimpleNamespace(output=f'mInputShown={str(keyboard).lower()}'),press=lambda k:actions.append(k))
        def wait(pred,msg,timeout):
            ns=nodes()
            if not pred(ns):raise RuntimeError('Chưa có kết quả chính xác')
            return ns
        f.wait_nodes=wait
        return f,actions
    def test_search_exact_number_and_hide_keyboard(self):
        f,a=self.helper(True);ns=f.search_ppct(31)
        self.assertEqual(a,[('input','31'),'back'])
        self.assertEqual(sum(period_number(n.get('text',''))==31 for n in ns),1)
    def test_no_back_if_keyboard_closed(self):
        f,a=self.helper();f.search_ppct(31);self.assertEqual(a,[('input','31')])
    def test_similar_number_not_accepted(self):
        f,a=self.helper(results=(131,))
        with self.assertRaises(RuntimeError):f.search_ppct(31)
        self.assertEqual(a,[('input','31')])
