from ui_scan import BidirectionalScan
from defaults import resolve_defaults
"""USB form assistant; teacher completion selection is left unchanged."""
import re
import unicodedata
import time
import xml.etree.ElementTree as ET


def bounds(node):
    values = list(map(int, re.findall(r'\d+', node.get('bounds', ''))))
    return values if len(values) == 4 else [0, 0, 0, 0]


def label(node):
    return (node.get('text') or node.get('content-desc') or '').strip()


def period_number(text):
    match = re.fullmatch(r'Tiết\s+PPCT\s*:\s*(\d+)', text.strip(), re.I)
    return int(match[1]) if match else None

def normalized(text):
    return re.sub(r'[^\w]+',' ',unicodedata.normalize('NFC',text).casefold()).strip()

def same_class(actual, expected):
    return re.sub(r'\s*\(CS2\)\s*','',actual,flags=re.I).strip().upper() == expected.upper()


def save_success(nodes):
    return any(' '.join(label(n).casefold().split()).rstrip('.!')
               == 'bạn đã ghi sổ đầu bài thành công' for n in nodes)


def save_confirmation(nodes):
    return (sum(label(n) == 'Bạn có chắc muốn hoàn tất ghi sổ đầu bài không?' for n in nodes) == 1
            and sum(label(n) == 'Đồng ý' for n in nodes) == 1
            and any(label(n) == 'Hủy' for n in nodes))


class FormAssistant:
    def __init__(self, device, stop, log, before_save=None, on_saved=None, complete_after=False, write_defaults=None):
        self.d, self.stop, self.log = device, stop, log
        self.write_defaults = resolve_defaults(write_defaults)
        self.package = None
        self.complete_after = complete_after
        self.before_save = before_save or (lambda: None)
        self.on_saved = on_saved or (lambda: None)

    def default(self, name):
        return resolve_defaults(getattr(self, 'write_defaults', None))[name]

    def check(self):
        if self.stop.is_set():
            raise RuntimeError('Đã dừng theo yêu cầu. Kiểm tra phiếu trên điện thoại trước khi tiếp tục.')
        if self.package and self.d.app_current().get('package') != self.package:
            raise RuntimeError('Ứng dụng đã đổi. Đã dừng.')

    def nodes(self):
        self.check()
        return list(ET.fromstring(self.d.dump_hierarchy()).iter('node'))

    def wait_nodes(self, predicate, message, timeout=20):
        """Poll without tapping; Stop stays available between device calls."""
        deadline = time.monotonic() + timeout
        self.log(message)
        while True:
            nodes = self.nodes()
            if predicate(nodes):
                return nodes
            if time.monotonic() >= deadline:
                raise RuntimeError(f'Chờ quá {timeout} giây: {message} Hãy kiểm tra mạng/app rồi thử lại.')
            if self.stop.wait(.5):
                self.check()

    def wait_ppct(self, previous=None):
        def ready(nodes):
            values = tuple(period_number(label(n)) for n in nodes
                           if period_number(label(n)) is not None)
            return (sum(label(n) == 'Chọn Tiết PPCT' for n in nodes) == 1
                    and bool(values) and values != previous)
        return self.wait_nodes(ready, 'Đang chờ danh sách PPCT tải xong...' if previous is None
                               else 'Đang chờ danh sách cập nhật sau khi cuộn...',
                               timeout=20 if previous is None else 8)

    def click(self, node):
        self.check()
        x1, y1, x2, y2 = bounds(node)
        if x2 <= x1 or y2 <= y1:
            raise RuntimeError('Không xác định được vị trí nút.')
        self.d.click((x1+x2)//2, (y1+y2)//2)
        time.sleep(.5)

    def exact(self, text, nodes=None):
        matches = [n for n in (nodes if nodes is not None else self.nodes()) if label(n) == text]
        if len(matches) != 1:
            raise RuntimeError(f'Không nhận diện duy nhất được mục: {text}. Hãy lấy dữ liệu màn hình.')
        return matches[0]

    def section(self, title, next_title):
        nodes = self.nodes()
        # Vivo exposes each label and its value inside one ViewGroup.
        labels = [n for n in nodes if label(n) == title]
        if len(labels) == 1:
            parents = [n for n in nodes if labels[0] in list(n)]
            if len(parents) == 1:
                group = parents[0]
                other_labels = [n for n in group.iter('node')
                                if n.get('resource-id', '').endswith('/textViewLabel')]
                if len(other_labels) == 1:
                    return [n for n in group.iter('node') if n is not group and n is not labels[0]]
        start, end = self.exact(title, nodes), self.exact(next_title, nodes)
        y0, y1 = bounds(start)[1], bounds(end)[1]
        if y1 <= y0:
            raise RuntimeError('Bố cục phiếu khác mẫu. Đã dừng.')
        return [n for n in nodes if bounds(n)[1] >= y0 and bounds(n)[3] <= y1 and label(n) != title]

    def scroll(self, forward=True):
        self.check()
        w, h = self.d.window_size()
        # Stay inside the list/form and away from the fixed bottom action.
        self.d.swipe(w*.45, h*(.72 if forward else .30), w*.45, h*(.30 if forward else .72), .4)
        time.sleep(.45)

    def field(self, title, next_title, value):
        scan=BidirectionalScan(limit=20)
        directed_steps=0
        last_notice=None
        def notice(message):
            nonlocal last_notice
            if message!=last_notice:self.log(message);last_notice=message
        def seek():
            nonlocal directed_steps
            ns=self.nodes()
            signature=tuple((label(n),n.get('bounds','')) for n in ns if label(n))
            # A label near the bottom means its input is further below, not above.
            _,height=self.d.window_size()
            labels=[n for n in ns if label(n)==title]
            preferred=None
            if len(labels)==1:
                b=bounds(labels[0])
                if b[3]>b[1]:preferred=(b[1]+b[3])/2 >= height*.35
            elif title in ('Học tập','Kỷ luật','Vệ sinh'):
                order=['Nhận xét của giáo viên','Giáo viên xác nhận','Học tập','Kỷ luật','Vệ sinh']
                seen=[order.index(label(n)) for n in ns if label(n) in order]
                if seen and max(seen)<order.index(title):preferred=True
                elif seen and min(seen)>order.index(title):preferred=False
            if preferred is not None and directed_steps<6:
                direction=preferred;directed_steps+=1
            else:direction=scan.next_direction(signature)
            if direction is None:raise RuntimeError(f'Không tìm thấy ô {title} sau khi cuộn hai chiều.')
            self.scroll(forward=direction)
        for _ in range(42):
            try:
                section = self.section(title, next_title)
            except RuntimeError:
                seek()
                continue
            edits = [n for n in section if n.get('class') == 'android.widget.EditText']
            if not edits:
                notice(f'Đang cuộn để hiện ô nhập {title}...')
                seek()
                continue
            if len(edits) > 1:
                raise RuntimeError(f'Không xác định ô nhập {title}; không nhập theo tọa độ đoán.')
            edit = edits[0]
            # A partially clipped EditText can already exist in the XML.
            # Bring it above the fixed Save bar before focusing it.
            x1, y1, x2, y2 = bounds(edit)
            _, height = self.d.window_size()
            save_nodes = [n for n in self.nodes() if label(n) == 'Lưu thay đổi']
            bottom = min([bounds(n)[1] for n in save_nodes] or [int(height*.87)])
            if (x2 <= x1 or y2-y1 < height*.018 or y2 >= bottom-height*.015
                    or edit.get('visible-to-user') == 'false'):
                notice(f'Đang cuộn để hiện ô nhập {title}...')
                seek()
                continue
            self.check()
            if edit.get('text') == value:
                self.log(f'{title}: đã đúng, bỏ qua nhập lại.')
                return False
            # Locate by label and parent, so keyboard-induced movement is harmless.
            selector = f'//*[@text="{title}"]/../android.widget.EditText'
            self.d.xpath(selector).set_text(value)
            time.sleep(.4)
            section = self.section(title, next_title)
            if not any(n.get('class') == 'android.widget.EditText' and label(n) == value for n in section):
                raise RuntimeError(f'Chưa xác minh được nội dung {title}; dừng để kiểm tra.')
            self.log(f'{title}: {value}')
            return True
        raise RuntimeError(f'Không tìm thấy ô {title}.')

    def search_ppct(self, period):
        def search_box(ns):
            heads=[n for n in ns if label(n)=='Chọn Tiết PPCT']
            if len(heads)!=1:return None
            bottom=bounds(heads[0])[3]
            rows=[bounds(n)[1] for n in ns if period_number(label(n)) is not None and bounds(n)[1]>=bottom]
            limit=min(rows) if rows else bottom+180
            edits=[n for n in ns if n.get('class')=='android.widget.EditText'
                   and bounds(n)[1]>=bottom and bounds(n)[3]<=limit
                   and bounds(n)[2]>bounds(n)[0] and bounds(n)[3]>bounds(n)[1]
                   and n.get('visible-to-user')!='false']
            named=[n for n in edits if normalized(label(n) or n.get('hint',''))=='tìm kiếm']
            return named[0] if len(named)==1 else edits[0] if len(edits)==1 else None
        ns=self.wait_nodes(lambda ns:search_box(ns) is not None,
                           'Đang chờ ô Tìm kiếm PPCT...',timeout=20)
        edit=search_box(ns)
        # Use the observed unique EditText bounds, never guessed screen coordinates.
        box=edit.get('bounds')
        self.check()
        self.d.xpath(f'//*[@class="android.widget.EditText" and @bounds="{box}"]').set_text(str(period))
        self.log(f'Đã nhập {period} vào ô tìm kiếm PPCT.')
        # Back only when Android reports an open input keyboard; otherwise it closes the picker.
        try:
            keyboard=self.d.shell('dumpsys input_method').output
        except Exception:
            keyboard=''
        if re.search(r'(?:mInputShown|isInputViewShown)\s*[=:]\s*true',keyboard):
            self.check();self.d.press('back')
        def ready(ns):
            if sum(label(n)=='Chọn Tiết PPCT' for n in ns)!=1:return False
            edit=search_box(ns)
            return (edit is not None and edit.get('text')==str(period)
                    and sum(period_number(label(n))==period for n in ns)==1)
        return self.wait_nodes(ready,f'Đang chờ kết quả đúng PPCT {period}...',timeout=20)

    def fill(self, classroom, period, expected_title=None, subjects=('Toán',)):
        self.package = self.d.app_current().get('package')
        nodes = self.nodes()
        if any(label(n) == 'Sổ đầu bài giáo viên' for n in nodes):
            raise RuntimeError('Đang ở danh sách tiết. Bấm vào đúng ô Toán để mở phiếu Ghi sổ đầu bài, rồi chạy lại.')
        if any(label(n) == 'Chọn Tiết PPCT' for n in nodes):
            raise RuntimeError('Đang mở danh sách PPCT. Đóng bảng chọn để về phiếu Ghi sổ đầu bài rồi chạy lại; chương trình sẽ tự mở và cuộn.')
        self.exact('Ghi sổ đầu bài', nodes)
        # Class and subject must both be explicitly visible in their own fields.
        if not any(same_class(label(n),classroom) for n in self.section('Lớp', 'Môn học')):
            raise RuntimeError(f'Phiếu không đúng lớp {classroom} hoặc đang cuộn. Mở đúng phiếu, cuộn lên đầu.')
        if not any(normalized(label(n)) in [normalized(x) for x in subjects] for n in self.section('Môn học', 'Kiểu giảng dạy')):
            raise RuntimeError('Môn học trên phiếu không khớp profile. Đã dừng.')
        ppct = self.section('Tiết theo PPCT', 'Bài dạy')
        if not any(label(n).startswith('Chọn tiết PPCT') for n in ppct):
            values = [label(n) for n in ppct if n.get('resource-id', '').endswith('/textViewValue')]
            if values == [str(period)]:
                self.verify_lesson(expected_title)
                self.log(f'PPCT {period} đã đúng; bỏ qua chọn lại, kiểm tra các mục còn lại.')
                self.field('Kiểm diện', 'Tiết theo PPCT', self.default('attendance'))
                self.field('Nhận xét của giáo viên', 'Giáo viên xác nhận', self.default('remark'))
                self.score_and_save()
                return
            raise RuntimeError('Phiếu đang có PPCT khác số đã chọn hoặc chưa đọc rõ. Đã dừng để tránh đổi nhầm bài.')
        self.click(self.exact('Tiết theo PPCT'))
        selected = False
        search_results = self.search_ppct(period)
        for _ in range(1):
            nodes = search_results
            self.exact('Chọn Tiết PPCT', nodes)
            choices = [(n, period_number(label(n))) for n in nodes]
            targets = [n for n, num in choices if num == period]
            if len(targets) == 1:
                parents = [n for n in nodes if targets[0] in list(n)]
                if len(parents) != 1:
                    raise RuntimeError('Không xác định được hàng chứa tiết PPCT.')
                if expected_title:
                    titles = [label(n) for n in parents[0].iter('node')
                              if n.get('resource-id','').endswith('/textViewTitle')]
                    if not any(normalized(x) == normalized(expected_title) for x in titles):
                        raise RuntimeError(f'PPCT {period} chưa đúng danh sách riêng. Cần bài: {expected_title}. '
                                           'Kiểm tra môn/kiểu giảng dạy của tiết này; đã dừng trước khi chọn.')
                checks = [n for n in parents[0].iter('node') if n.get('checkable') == 'true']
                if len(checks) != 1:
                    raise RuntimeError('Không nhận diện được ô đánh dấu PPCT.')
                if checks[0].get('checked') != 'true':
                    self.click(targets[0])
                def checked(nodes):
                    matches = [n for n in nodes if period_number(label(n)) == period]
                    if len(matches) != 1:
                        return False
                    parents = [n for n in nodes if matches[0] in list(n)]
                    return len(parents) == 1 and any(n.get('checked') == 'true' for n in parents[0].iter('node'))
                fresh = self.wait_nodes(checked, 'Đang chờ xác nhận dấu chọn PPCT...', timeout=8)
                target = self.exact(label(targets[0]), fresh)
                parent = [n for n in fresh if target in list(n)]
                if len(parent) != 1 or not any(n.get('checked') == 'true' for n in parent[0].iter('node')):
                    raise RuntimeError('Chưa đánh dấu được tiết PPCT. Đã dừng trước Đồng ý.')
                selected = True
                break
            raise RuntimeError(f'Không tìm thấy duy nhất PPCT {period} trong kết quả tìm kiếm. Chưa chọn hay bấm Đồng ý.')
        if not selected:
            raise RuntimeError(f'Chưa tìm thấy PPCT {period}.')
        self.click(self.exact('Đồng ý'))
        self.wait_nodes(lambda ns: any(label(n) == 'Ghi sổ đầu bài' for n in ns)
                        and not any(label(n) == 'Chọn Tiết PPCT' for n in ns)
                        and any(label(n) == str(period) for n in ns),
                        'Đang chờ phiếu cập nhật PPCT...')
        section = self.section('Tiết theo PPCT', 'Bài dạy')
        values = [label(n) for n in section if label(n)]
        if str(period) not in values or any(re.fullmatch(r'\d+\s*[,;]\s*\d+.*', v) for v in values):
            raise RuntimeError('PPCT sau chọn không khớp một tiết duy nhất. Kiểm tra trên điện thoại.')
        self.log(f'Đã xác minh PPCT {period}.')
        self.verify_lesson(expected_title)
        self.field('Kiểm diện', 'Tiết theo PPCT', self.default('attendance'))
        self.field('Nhận xét của giáo viên', 'Giáo viên xác nhận', self.default('remark'))
        self.score_and_save()

    def verify_lesson(self, expected_title):
        if expected_title and not any(normalized(label(n)) == normalized(expected_title)
                                     for n in self.section('Bài dạy','Nhận xét của giáo viên')):
            raise RuntimeError('Tên bài trên phiếu không khớp PPCT riêng: '+expected_title)

    def score_and_save(self):
        if getattr(self,'complete_after',False):
            self.select_completion()
        self.field('Học tập', 'Kỷ luật', self.default('learning'))
        self.field('Kỷ luật', 'Vệ sinh', self.default('discipline'))
        self.field('Vệ sinh', 'Lưu thay đổi', self.default('hygiene'))
        self.log('Đã xác minh điểm theo nội dung mặc định của giáo viên. Đang lưu...')
        self.save_current()

    def save_current(self):
        button=self.exact('Lưu thay đổi')
        self.check()
        self.before_save()
        self.click(button)
        # Never retry Save: a delayed response may already have committed the record.
        try:
            nodes = self.wait_nodes(lambda ns: save_success(ns) or save_confirmation(ns),
                                    'Đang chờ xác nhận lưu hoặc thông báo thành công...', timeout=30)
            if not save_success(nodes):
                # Re-read immediately before the click; never accept an unrelated dialog.
                nodes = self.nodes()
                if not save_confirmation(nodes):
                    raise RuntimeError('Hộp xác nhận lưu đã thay đổi. Đã dừng để thầy kiểm tra.')
                self.log('Xác nhận hoàn tất ghi sổ đầu bài: bấm Đồng ý.')
                self.click(self.exact('Đồng ý', nodes))
                self.wait_nodes(save_success, 'Đang chờ thông báo lưu thành công...', timeout=30)
        except RuntimeError as exc:
            raise RuntimeError('CHƯA XÁC NHẬN KẾT QUẢ LƯU. Không bấm lưu lại tự động. '
                               'Kiểm tra thông báo trên điện thoại; nếu app yêu cầu Hoàn thành, '
                               'thầy tự chọn rồi lưu. ' + str(exc)) from exc
        self.log('ĐÃ LƯU THÀNH CÔNG.')
        self.on_saved()
        self.close_success()

    def close_success(self):
        try:
            nodes = self.wait_nodes(lambda ns: save_success(ns)
                                    and sum(label(n) == 'Đóng' for n in ns) == 1,
                                    'Đã lưu; đang chờ nút Đóng...', timeout=8)
            self.click(self.exact('Đóng', nodes))
            self.wait_nodes(lambda ns: not save_success(ns),
                            'Đã lưu; đang đóng thông báo...', timeout=10)
            self.log('ĐÃ LƯU VÀ ĐÓNG THÔNG BÁO. Thầy có thể mở tiết tiếp theo.')
        except RuntimeError as exc:
            raise RuntimeError('ĐÃ LƯU THÀNH CÔNG nhưng chưa xác nhận đóng thông báo. '
                               'Thầy bấm Đóng trên điện thoại nếu còn hiện; không cần lưu lại. '
                               + str(exc)) from exc

    def completion_value(self, nodes):
        labels=[n for n in nodes if label(n)=='Giáo viên xác nhận' and n.get('resource-id','').endswith('/textViewLabel')]
        parents=[n for n in nodes if labels and labels[0] in list(n)]
        if len(labels)==1 and len(parents)==1:
            vals=[label(n) for n in parents[0].iter('node') if n.get('resource-id','').endswith('/textViewValue')]
            return vals[0] if len(vals)==1 else None
        return None

    def select_completion(self):
        # Start at the top, then locate the observed label by scrolling.
        for _ in range(5):
            if any(label(n)=='Lớp' for n in self.nodes()): break
            self.scroll(False)
        for _ in range(10):
            ns=self.nodes(); value=self.completion_value(ns)
            if value=='Hoàn thành': return False
            targets=[n for n in ns if label(n)=='Giáo viên xác nhận']
            if len(targets)==1:
                b=bounds(targets[0]); _,h=self.d.window_size()
                if b[1]>h*.1 and b[3]<h*.82:
                    self.click(targets[0]); break
            self.scroll()
        else: raise RuntimeError('Chưa tìm được mục Giáo viên xác nhận. Lấy dữ liệu màn hình.')
        ns=self.wait_nodes(lambda ns:sum(label(n)=='Hoàn thành' for n in ns)==1,'Chờ lựa chọn Hoàn thành...')
        self.click(self.exact('Hoàn thành',ns))
        self.wait_nodes(lambda ns:self.completion_value(ns)=='Hoàn thành','Xác minh Giáo viên xác nhận: Hoàn thành...')
        return True

    def complete_only(self,classroom,period,subjects=('Toán',)):
        self.package=self.d.app_current().get('package')
        self.exact('Ghi sổ đầu bài')
        if not any(same_class(label(n),classroom) for n in self.section('Lớp','Môn học')):
            raise RuntimeError('Phiếu không đúng lớp cần hoàn thành.')
        if not any(normalized(label(n)) in [normalized(x) for x in subjects] for n in self.section('Môn học','Kiểu giảng dạy')):
            raise RuntimeError('Phiếu không đúng môn cần hoàn thành.')
        values=[label(n) for n in self.section('Tiết theo PPCT','Bài dạy') if n.get('resource-id','').endswith('/textViewValue')]
        if values != [str(period)]:
            raise RuntimeError('Phiếu chưa có bài hoặc PPCT không khớp dòng chọn. Không xác nhận hoàn thành.')
        if not self.select_completion():
            self.log('Phiếu đã Hoàn thành; bỏ qua lưu lại.'); self.on_saved(); return
        self.save_current()
