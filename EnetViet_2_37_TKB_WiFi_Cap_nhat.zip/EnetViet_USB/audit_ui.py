import copy
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import ttk,messagebox,filedialog
from tkinter.scrolledtext import ScrolledText
from profiles import plan
from branding import credit
from legacy_app import ROOT
from audit import NotebookAudit,BorrowAudit

def start_audit(app,kind,week=None):
    if app.busy:return
    try:
        app.require_device();week=int(app.week.get()) if week is None else int(week)
        profile=copy.deepcopy(app.profile)
        tasks=plan(profile,week) if kind=='notebook' else []
        if kind=='notebook' and any(t.get('schedule_provisional') for t in tasks):
            raise ValueError('Tuần này chưa có TKB xác định. Cập nhật khoảng áp dụng TKB trước khi rà soát.')
        title=('Rà soát sổ đầu bài' if kind=='notebook' else 'Rà soát phiếu mượn')+f' — Tuần {week}'
        def worker():
            try:
                if kind=='notebook':
                    reader=NotebookAudit(app.d,app.stop,app.log);rows=reader.audit_week(tasks)
                else:
                    reader=BorrowAudit(app.d,app.stop,app.log,ROOT/'tien_do_muon_do_dung.json',profile['id'],profile.get('school_year',''))
                    rows=reader.audit_week(week)
            except Exception as exc:rows=[('Rà soát chưa hoàn tất',[str(exc)])]
            app.events.put(('audit_result',(title,rows)))
            bad=sum(bool(errors) for _,errors in rows)
            return {'state':'warning' if bad else 'ok','detail':f'{bad} mục cần kiểm tra; xem bảng kết quả.' if bad else 'Các mục đã rà soát đều đạt.'}
        app.run(worker)
    except Exception as exc:messagebox.showerror('Rà soát',str(exc),parent=app.root)

def show_audit(parent,title,rows):
    bad=sum(bool(issues) for _,issues in rows)
    summary='ĐÃ ĐỦ — tất cả mục đã rà soát đều đạt.' if not bad else f'CẦN KIỂM TRA — {bad} mục còn thiếu, sai hoặc chưa đọc được.'
    lines=[title,summary,'']
    for name,issues in rows:
        lines.append(('CẦN KIỂM TRA: ' if issues else 'ĐẠT: ')+name)
        lines.extend('  - '+error for error in issues)
    text='\n'.join(lines)
    win=tk.Toplevel(parent);win.title(title);win.geometry('900x600');win.transient(parent);credit(win)
    footer=ttk.Frame(win,padding=8);footer.pack(side='bottom',fill='x')
    ttk.Label(win,text=summary,foreground='#b42318' if bad else '#16803c',font=('Segoe UI',12,'bold'),wraplength=850).pack(fill='x',padx=10,pady=10)
    box=ScrolledText(win,wrap='word',font=('Segoe UI',11));box.pack(fill='both',expand=True,padx=10)
    box.tag_configure('bad',foreground='#b42318');box.tag_configure('ok',foreground='#16803c')
    for name,issues in rows:
        box.insert('end',('CẦN KIỂM TRA: ' if issues else 'ĐẠT: ')+name+'\n','bad' if issues else 'ok')
        for error in issues:box.insert('end','  - '+error+'\n')
    box.configure(state='disabled')
    def save():
        file=filedialog.asksaveasfilename(parent=win,defaultextension='.txt',initialfile='Ra_soat_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.txt',filetypes=[('Báo cáo','*.txt')])
        if file:Path(file).write_text(text,encoding='utf-8-sig')
    ttk.Button(footer,text='Xuất báo cáo',command=save).pack(side='left')
    ttk.Button(footer,text='Đóng',command=win.destroy).pack(side='right')
