"""Per-teacher writing defaults, independent of timetable and AI output."""
DEFAULTS = dict(attendance='0', remark='Tốt', learning='20', discipline='10', hygiene='10')
LABELS = dict(attendance='Kiểm diện / Hiện diện', remark='Nhận xét', learning='Học tập', discipline='Kỷ luật', hygiene='Vệ sinh')

def resolve_defaults(values=None):
    if values is None:
        return DEFAULTS.copy()
    if not isinstance(values, dict) or any(k not in DEFAULTS or not isinstance(v, str) for k, v in values.items()):
        raise ValueError('Nội dung mặc định phải gồm các ô văn bản hợp lệ.')
    return {**DEFAULTS, **values}

def describe_defaults(values=None):
    return '\n'.join(f'{LABELS[k]}: {v if v else "(để trống)"}' for k,v in resolve_defaults(values).items())

def preserve_defaults(original, result):
    result['write_defaults'] = resolve_defaults(original.get('write_defaults'))
    return result

def edit_defaults(parent, profile, on_save):
    from input_help import hint
    import copy
    import tkinter as tk
    from tkinter import ttk, messagebox
    win=tk.Toplevel(parent); win.title('Nội dung ghi sổ mặc định'); win.transient(parent); win.grab_set()
    from branding import credit
    credit(win)
    frame=ttk.Frame(win,padding=18); frame.pack(fill='both',expand=True)
    ttk.Label(frame,text='Giáo viên: '+profile['name']).grid(row=0,column=0,columnspan=2,sticky='w',pady=8)
    ttk.Label(frame,text='Áp dụng khi ghi sổ tiếp theo; không sửa các tiết đã ghi.').grid(row=1,column=0,columnspan=2,sticky='w')
    values=resolve_defaults(profile.get('write_defaults')); fields={}
    for i,k in enumerate(DEFAULTS,2):
        ttk.Label(frame,text=LABELS[k]).grid(row=i,column=0,sticky='nw',pady=8,padx=(0,16))
        if k=='remark':
            widget=tk.Text(frame,width=48,height=4,wrap='word'); widget.insert('1.0',values[k])
        else:
            widget=ttk.Entry(frame,width=48); widget.insert(0,values[k])
        widget.grid(row=i,column=1,sticky='ew',pady=8); fields[k]=widget
        hint(widget,'Nội dung '+LABELS[k]+' sẽ nhập khi ghi sổ cho giáo viên này. Để trống nghĩa là xóa nội dung ô đó; giá trị phải phù hợp eNetViet.')
    ttk.Label(frame,text='Giá trị phải phù hợp với ô nhập trên eNetViet. Để trống nghĩa là xóa nội dung ô đó.').grid(row=7,column=0,columnspan=2,sticky='w',pady=8)
    def reset():
        for k,w in fields.items():
            w.delete('1.0' if k=='remark' else 0,'end'); w.insert('1.0' if k=='remark' else 0,DEFAULTS[k])
    def save():
        updated=copy.deepcopy(profile)
        updated['write_defaults']={k:w.get('1.0','end-1c') if k=='remark' else w.get() for k,w in fields.items()}
        try: on_save(updated)
        except Exception as e: messagebox.showerror('Không lưu được',str(e),parent=win); return
        win.destroy()
    bar=ttk.Frame(frame);bar.grid(row=8,column=0,columnspan=2,sticky='e',pady=8)
    ttk.Button(bar,text='Khôi phục 0 / Tốt / 20 / 10 / 10',command=reset).pack(side='left',padx=5)
    ttk.Button(bar,text='Hủy',command=win.destroy).pack(side='left',padx=5)
    ttk.Button(bar,text='Lưu cho giáo viên này',command=save).pack(side='left',padx=5)
