import copy
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from onboarding import parse_classes,setup_profile,profile_names
from profiles import default_profile,validate,Store
from teacher_setup import preserve_setup
from app import App

class OnboardingTests(unittest.TestCase):
    def test_class_list_normalizes_duplicates(self):
        self.assertEqual(parse_classes('6a11, 6A2\n7a2;6A2'),['6A2','6A11','7A2'])
    def profile(self):
        p=default_profile();classes=['6A1','6A8','6A11','7A2']
        return setup_profile(p,'Cô A','Toán',classes,dict(hdtn=[],integrated=['6A11'],extra=['6A11']))
    def test_setup_roundtrip(self):
        p=self.profile();validate(p)
        with tempfile.TemporaryDirectory() as d:
            store=Store(Path(d)/'profiles');store.save(p);store.export(p,Path(d)/'p.zip')
            q,_=store.read_package(Path(d)/'p.zip');self.assertEqual(q['teaching_options'],p['teaching_options'])
    def test_integrated_without_extra_is_valid(self):
        p=self.profile();p['teaching_options']['extra']=[]
        p['schedules'][0]['rows']=[r for r in p['schedules'][0]['rows'] if r['course']!='6A11_TT']
        validate(p)
    def test_unlisted_class_rejected(self):
        p=self.profile();p['teaching_options']['hdtn']=['6A9']
        with self.assertRaises(ValueError):validate(p)
    def test_ai_cannot_overwrite_choices(self):
        p=self.profile();q=preserve_setup(p,copy.deepcopy(p));q['teaching_options']['extra'].append('7A2')
        self.assertEqual(p['teaching_options']['extra'],['6A11'])
        with self.assertRaises(ValueError):validate(q)
    def test_duplicate_names_are_distinguishable(self):
        p=self.profile();q=copy.deepcopy(p);q['id']='different'
        self.assertNotEqual(*profile_names([p,q]))

class FakeTree:
    def __init__(self):self.selected=set();self.ids=['a','b'];self.tags={};self.checks={}
    def selection(self):return tuple(self.selected)
    def get_children(self):return self.ids
    def selection_set(self,ids):self.selected=set(ids)
    def set(self,iid,col,value):self.checks[iid]=value
    def item(self,iid,**kw):self.tags[iid]=kw.get('tags')
    def identify_region(self,x,y):return 'cell'
    def identify_row(self,y):return self.ids[y]
    def selection_add(self,iid):self.selected.add(iid)
    def selection_remove(self,iid):self.selected.remove(iid)
    def focus(self,*a):pass
    def focus_set(self):pass

class SelectionTests(unittest.TestCase):
    def test_shift_range_uses_display_order(self):
        a=object.__new__(App);a.table=FakeTree();a.table.ids=['d','b','c','a'];a.busy=False;a.tasks=[1,2,3,4]
        a.toggle_row(SimpleNamespace(x=1,y=1,state=0))
        a.toggle_row(SimpleNamespace(x=1,y=3,state=1))
        self.assertEqual(a.table.selected,{'b','c','a'})
        a.toggle_row(SimpleNamespace(x=1,y=2,state=1))
        self.assertEqual(a.table.selected,{'b','c'})
    def test_ctrl_shift_keeps_other_selected_rows(self):
        a=object.__new__(App);a.table=FakeTree();a.table.ids=['a','b','c','d'];a.busy=False;a.tasks=[1,2,3,4]
        a.toggle_row(SimpleNamespace(x=1,y=0,state=0))
        a.toggle_row(SimpleNamespace(x=1,y=2,state=0))
        a.toggle_row(SimpleNamespace(x=1,y=3,state=5))
        self.assertEqual(a.table.selected,{'a','c','d'})
    def test_click_toggle_and_select_all(self):
        a=object.__new__(App);a.table=FakeTree();a.busy=False;a.tasks=[1,2]
        a.select_rows(True);self.assertEqual(a.table.selected,{'a','b'});self.assertEqual(a.table.tags['a'],('chosen',))
        a.toggle_row(SimpleNamespace(x=1,y=0));self.assertEqual(a.table.selected,{'b'});self.assertEqual(a.table.checks['a'],'☐')
        a.toggle_row(SimpleNamespace(x=1,y=0));self.assertEqual(a.table.selected,{'a','b'})
        a.select_rows(False);self.assertEqual(a.table.selected,set())
        a.busy=True;a.select_rows(True);self.assertEqual(a.table.selected,{'a','b'})

if __name__=='__main__':unittest.main()
