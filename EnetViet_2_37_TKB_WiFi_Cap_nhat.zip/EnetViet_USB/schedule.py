"""Timetable transcribed from teacher image effective 2026-10-19."""
import json
from pathlib import Path

ROOT = Path(__file__).parent
REGULAR = json.loads((ROOT/'ppct.json').read_text(encoding='utf-8'))
SPECIAL = json.loads((ROOT/'special_ppct.json').read_text(encoding='utf-8'))
TIMETABLE = [
    (2,'Sáng',4,'6A8','Toán'),
    (2,'Chiều',1,'6A11','Toán'), (2,'Chiều',2,'6A8','Toán'),
    (4,'Sáng',1,'7A2','Toán'), (4,'Sáng',3,'6A8','Toán'), (4,'Sáng',4,'7A2','Toán'),
    (4,'Chiều',1,'6A8','Toán'), (4,'Chiều',2,'7A2','Toán'), (4,'Chiều',4,'6A11','TT'),
    (5,'Sáng',1,'6A1','Toán'), (5,'Sáng',2,'6A1','Toán'),
    (6,'Sáng',1,'6A1','Toán'), (6,'Sáng',2,'6A1','Toán'),
    (6,'Sáng',3,'6A11','Toán'), (6,'Sáng',4,'7A2','Toán'),
]

def make_plan(week):
    if not 1 <= int(week) <= 35:
        raise ValueError('Tuần phải từ 1 đến 35.')
    week = int(week)
    counters, result = {}, []
    for day,session,slot,cls,kind in TIMETABLE:
        group = (cls,kind)
        ordinal = counters.get(group,0)+1
        counters[group] = ordinal
        if cls == '6A11':
            course = '6A11_TT' if kind == 'TT' else '6A11'
            period = week if kind == 'TT' else 2*(week-1)+ordinal
            title = SPECIAL[course]['periods'][str(period)]['title']
            expected_title = title
        else:
            record = REGULAR[cls[0]]['weeks'][str(week)][ordinal-1]
            period, title = record['period'], record['source_text']
            expected_title = None  # Original file combines titles for two periods.
        result.append(dict(week=week,day=day,session=session,slot=slot,classroom=cls,
                           kind=kind,ordinal=ordinal,period=period,title=title,
                           expected_title=expected_title))
    return result

def task_key(task):
    # PPCT changes do not erase the fact a time slot has already been saved.
    return '|'.join(map(str,['2026-2027',task['week'],task['day'],task['session'],
                             task['slot'],task['classroom'],task['kind']]))

class Progress:
    def __init__(self,path):
        self.path=Path(path)
        self.data=json.loads(self.path.read_text(encoding='utf-8')) if self.path.exists() else {}

    def mark(self,task,state,detail=''):
        self.data[task_key(task)]={'state':state,'period':task['period'],'detail':detail}
        temp=self.path.with_suffix('.tmp')
        temp.write_text(json.dumps(self.data,ensure_ascii=False,indent=2),encoding='utf-8')
        temp.replace(self.path)

    def state(self,task):
        return self.data.get(task_key(task),{}).get('state','pending')
