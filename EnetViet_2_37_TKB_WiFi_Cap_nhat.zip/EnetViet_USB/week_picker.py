"""Recognize week options only inside an observed list, never the main value."""
import re
from engine import label, bounds

def option_number(node):
    if node.get('resource-id','').endswith('/textViewValue'):return None
    m=re.match(r'^Tuần\s+(\d+)\b',label(node),re.I)
    return int(m[1]) if m and 1<=int(m[1])<=53 else None

def picker_list(nodes):
    candidates=[]
    for n in nodes:
        if n.get('resource-id','').endswith('/rvNotebook'):continue
        if n.get('scrollable')!='true' and not any(c in n.get('class','') for c in ('RecyclerView','ListView','ScrollView')):continue
        if any(option_number(x) is not None for x in n.iter('node')):candidates.append(n)
    # A containing ScrollView and its inner list are one region; keep inner list.
    leaves=[n for n in candidates if not any(other is not n and other in list(n.iter('node')) for other in candidates)]
    if len(leaves)>1:raise RuntimeError('Có nhiều danh sách tuần; dừng để tránh chọn nhầm.')
    return leaves[0] if leaves else None

def visible_options(region):
    x1,y1,x2,y2=bounds(region)
    result=[]
    for n in region.iter('node'):
        num=option_number(n)
        if num is None:continue
        a,b,c,d=bounds(n)
        if a>=x1 and c<=x2 and b>=y1+2 and d<=y2-2 and c>a and d>b and n.get('enabled','true')=='true':result.append((num,n))
    return result

class WeekSweep:
    def __init__(self):self.forward=False;self.previous=None;self.stalled=0;self.steps=0
    def next(self,signature):
        self.stalled=self.stalled+1 if signature==self.previous else 0
        self.previous=signature;self.steps+=1
        if not self.forward and (self.stalled>=2 or self.steps>=60):
            self.forward=True;self.previous=None;self.stalled=0;self.steps=0
        elif self.forward and (self.stalled>=3 or self.steps>=60):return None
        return self.forward
