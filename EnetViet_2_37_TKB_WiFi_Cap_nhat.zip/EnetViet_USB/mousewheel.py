"""Mouse wheel routing limited to one scrollable form and its children."""
import tkinter as tk

def wheel_units(event):
    if getattr(event,'num',None)==4:return -3
    if getattr(event,'num',None)==5:return 3
    delta=getattr(event,'delta',0)
    if not delta:return 0
    return -max(1,round(abs(delta)/120))*3 if delta>0 else max(1,round(abs(delta)/120))*3

def bind_form_wheel(canvas,content):
    tag='FormWheel'+str(id(canvas))
    sequences=('<MouseWheel>','<Button-4>','<Button-5>')
    def scroll(event):
        units=wheel_units(event)
        if not units:return 'break'
        widget=event.widget
        # Text/list areas consume the wheel only when they can move that way.
        if isinstance(widget,(tk.Text,tk.Listbox)):
            first,last=widget.yview()
            if (units<0 and first>0) or (units>0 and last<1):
                widget.yview_scroll(units,'units');return 'break'
        canvas.yview_scroll(units,'units')
        return 'break'
    def attach(widget):
        tags=widget.bindtags()
        if tag not in tags:widget.bindtags((tag,)+tags)
        for child in widget.winfo_children():attach(child)
    for sequence in sequences:canvas.bind_class(tag,sequence,scroll)
    attach(canvas)
    def refresh(event=None):attach(content)
    content.bind('<Configure>',refresh,add='+')
    def cleanup(event):
        if event.widget==canvas:
            for sequence in sequences:canvas.unbind_class(tag,sequence)
    canvas.bind('<Destroy>',cleanup,add='+')
    return refresh
