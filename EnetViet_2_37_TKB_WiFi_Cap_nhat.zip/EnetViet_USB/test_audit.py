import unittest
from unittest.mock import patch
from types import SimpleNamespace
from datetime import date
from xml.etree.ElementTree import Element,SubElement
from PIL import Image,ImageDraw
from audit import FIELDS,read_fields,lesson_issues,NotebookAudit,BorrowAudit,green_dot_days
from test_borrow import fixture,task
from engine import bounds
from borrow import one

class AuditTests(unittest.TestCase):
    def values(self):
        return dict(zip(FIELDS,('2','21','Có tiến bộ','Hoàn thành','18','9','8')))
    def test_nondefault_values_are_accepted(self):
        self.assertEqual(lesson_issues(self.values(),21),[])
    def test_missing_wrong_and_unfinished_reported(self):
        v=self.values();v['Học tập']='';v['Tiết theo PPCT']='22';v['Giáo viên xác nhận']='Chưa hoàn thành';del v['Vệ sinh']
        errors=lesson_issues(v,21)
        self.assertEqual(len(errors),4)
        self.assertIn('Thiếu Học tập',errors)
        self.assertTrue(any('đúng phải là 21' in e for e in errors))
        self.assertIn('Chưa đọc được Vệ sinh',errors)
    def test_placeholders_blank_but_zero_is_present(self):
        root=Element('node')
        for name,text,hint in [('Kiểm diện','0','Nhập học sinh nghỉ học...'),('Học tập','Tối đa 100 điểm','Tối đa 100 điểm')]:
            row=SubElement(root,'node')
            SubElement(row,'node',{'text':name,'resource-id':'app:id/textViewLabel'})
            SubElement(row,'node',{'text':text,'hint':hint,'class':'android.widget.EditText'})
        self.assertEqual(read_fields(list(root.iter('node'))),{'Kiểm diện':'0','Học tập':''})
    def test_calendar_green_dots_exclude_selected_cyan(self):
        ns=fixture('main');im=Image.new('RGB',(1260,2800),'white');draw=ImageDraw.Draw(im)
        cells=sorted([n for n in one(ns,'mcv_pager').iter('node') if n.get('class')=='android.widget.CheckedTextView'],key=lambda n:bounds(n)[0])
        for i in (0,2,4):
            x,y,xx,yy=bounds(cells[i]);draw.ellipse((x+10,y+10,x+24,y+24),fill=(30,190,80))
        x,y,xx,yy=bounds(cells[1]);draw.rectangle((x,y,xx,yy),fill=(20,175,220))
        self.assertEqual(green_dot_days(ns,im,(1260,2800)),[2,4,6])
    def test_notebook_order_and_no_creation(self):
        n=NotebookAudit.__new__(NotebookAudit);n.ensure_main=lambda:None;n.check=lambda:None;n.log=lambda s:None
        seen=[];n.open_task=lambda t,existing_only:seen.append((t['day'],t['session'],t['slot'],existing_only))
        n.audit_form=lambda t:[];n.leave_form=lambda:None
        tasks=[dict(task(),day=d,session=s,slot=k) for d,s,k in [(3,'Sáng',1),(2,'Chiều',2),(2,'Sáng',4),(2,'Sáng',1),(8,'Sáng',1)]]
        rows=n.audit_week(tasks)
        self.assertEqual(seen,[(2,'Sáng',1,True),(2,'Sáng',4,True),(2,'Chiều',2,True),(3,'Sáng',1,True)])
        self.assertEqual(len(rows),4)
    def borrow_reader(self):
        n=BorrowAudit.__new__(BorrowAudit);n.ensure_entry=lambda:None;n.go_week=lambda w:date(2026,10,12)
        n.wait_nodes=lambda *a,**k:None;n.stop=SimpleNamespace(wait=lambda t:False)
        n.nodes=lambda:fixture('main');n.calendar_ready=n.nodes;n.check=lambda:None;n.log=lambda s:None
        n.d=SimpleNamespace(screenshot=lambda:None,window_size=lambda:(1260,2800))
        n.days=[]
        def day(d,start):n.days.append(d);return date(2026,10,12)
        n.day=day;n.all_cards=lambda:['Tiết 4 Sáng'];n.open_audit_card=lambda name:fixture('form');n.back=lambda:None
        return n
    def test_one_loan_day_is_enough_and_sunday_skipped(self):
        n=self.borrow_reader()
        with patch('audit.green_dot_days',return_value=[2,8]):rows=n.audit_week(6)
        self.assertEqual(n.days,[2]);self.assertTrue(all(not e for _,e in rows))
    def test_empty_ppct_report(self):
        n=self.borrow_reader();ns=fixture('form')
        from borrow import value
        for parent in ns:
            if any(c.get('text')=='Tiết PPCT' for c in parent):
                for c in parent.iter('node'):
                    if c.get('resource-id','').endswith('/tvHint'):c.set('text','')
        n.open_audit_card=lambda name:ns
        with patch('audit.green_dot_days',return_value=[2]):rows=n.audit_week(6)
        self.assertTrue(any('Chưa có số tiết PPCT' in e for _,e in rows))
    def test_dot_without_readable_card_not_all_clear(self):
        n=self.borrow_reader();n.all_cards=lambda:[]
        with patch('audit.green_dot_days',return_value=[2]):rows=n.audit_week(6)
        self.assertTrue(any(any('chấm xanh' in s for s in e) for _,e in rows))
    def test_no_dots_fallback_checks_all_weekdays(self):
        n=self.borrow_reader();n.all_cards=lambda:[]
        with patch('audit.green_dot_days',return_value=[]):rows=n.audit_week(6)
        self.assertEqual(n.days,[2,3,4,5,6,7]);self.assertTrue(rows[0][1])

if __name__=='__main__':unittest.main()
