from branding import credit
from onboarding import setup_note, ProfileWizard
from table_sort import TimetableSort
from timetable import DAYS, SESSIONS, course_label, range_label, range_dialog, change_range, remove_revision
from ai_settings import credentials, configure
from input_help import attach, hint, HINTS
from defaults import preserve_defaults
import copy
import json
import queue
import threading
import time
import uuid
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog, font as tkfont
from profiles import validate, plan
from widgets import choose, add_tooltips
from analyzer import analyze, export_request, chatgpt_request

class ProfileEditor(tk.Toplevel):
    def __init__(self,parent,profile,on_save,mode='Tạo hồ sơ',review_only=False,resume=None):
        super().__init__(parent); self.title(mode); self.geometry(f'{min(1120,self.winfo_screenwidth()-40)}x{min(760,self.winfo_screenheight()-100)}'); self.transient(parent)
        self.review_only=review_only;credit(self)
        self.p=copy.deepcopy(profile); self.on_save=on_save; self.files=[]; self.results=queue.Queue(); self.running=False
        self.vars={k:tk.StringVar(value=str(self.p.get(k,''))) for k in ('name','subject','school_year')}
        self.integrated=tk.StringVar(value=', '.join(self.p.get('integrated_classes',[])))
        self.has_integrated=tk.BooleanVar(value=bool(self.p.get('integrated_classes')))
        bottom=ttk.Frame(self,padding=8);bottom.pack(side='bottom',fill='x')
        self.reviewed=tk.BooleanVar(value=False)
        ttk.Checkbutton(bottom,text='Tôi đã kiểm tra TKB, PPCT, tuần mốc và các ghi chú phân tích',variable=self.reviewed).pack(anchor='w',pady=(0,5))
        actions=ttk.Frame(bottom);actions.pack(fill='x')
        ttk.Button(actions,text='Đồng ý áp dụng TKB và PPCT' if review_only else 'Lưu hồ sơ',command=self.save,style='Primary.TButton').pack(side='right')
        ttk.Button(actions,text='Lưu nháp',command=lambda:self.save_draft(True)).pack(side='right',padx=6)
        self.draft_status=tk.StringVar(value='Tự lưu nháp mỗi 3 giây')
        ttk.Label(bottom,textvariable=self.draft_status).pack(anchor='w',pady=(4,0))
        self.book=ttk.Notebook(self); self.book.pack(fill='both',expand=True,padx=10,pady=10)
        source_page=ttk.Frame(self.book);self.book.add(source_page,text='1. Giáo viên và tài liệu')
        canvas=tk.Canvas(source_page,highlightthickness=0);canvas.pack(side='left',fill='both',expand=True)
        source_scroll=ttk.Scrollbar(source_page,orient='vertical',command=canvas.yview);source_scroll.pack(side='right',fill='y');canvas.configure(yscrollcommand=source_scroll.set)
        source=ttk.Frame(canvas,padding=10);source_window=canvas.create_window((0,0),window=source,anchor='nw')
        source.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',lambda e:canvas.itemconfigure(source_window,width=e.width))
        for key,title in [('name','Tên giáo viên'),('subject','Môn dạy chính'),('school_year','Năm học')]:
            row=ttk.Frame(source); row.pack(fill='x',pady=4); ttk.Label(row,text=title,width=30).pack(side='left'); ttk.Entry(row,textvariable=self.vars[key],width=45).pack(side='left')
        ttk.Button(source,text='Sửa tên, môn và các lớp giảng dạy…',command=self.reconfigure).pack(anchor='w',pady=5)
        self.teaching_summary=ttk.LabelFrame(source,text='Các nội dung giảng dạy đã chọn',padding=6)
        self.teaching_summary.pack(fill='x',pady=5)
        self.show_teaching_summary()
        ttk.Label(source,text='Tải TKB và PPCT phù hợp với các lớp đã chọn ở trên.').pack(anchor='w',pady=3)
        row=ttk.Frame(source);row.pack(fill='x')
        for role in ('TKB','PPCT khối','PPCT HĐTN','PPCT tích hợp','PPCT TT'):
            ttk.Button(row,text='Thêm '+role,command=lambda r=role:self.add_files(r)).pack(side='left',padx=3)
        self.source_list=tk.Listbox(source,height=4);self.source_list.pack(fill='x',pady=5)
        ttk.Button(source,text='Bỏ tệp chọn',command=self.remove_file).pack(anchor='w')
        action=ttk.Frame(source);action.pack(fill='x',pady=4)
        self.ai_mode=tk.StringVar(value='Phân tích toàn bộ')
        self.ai_course=tk.StringVar();self.ai_week=tk.IntVar(value=1)
        ttk.Combobox(action,textvariable=self.ai_mode,values=['Phân tích toàn bộ','Cập nhật PPCT hiện có','Cập nhật TKB mới nhất'],state='readonly',width=26).pack(side='left')
        self.ai_coursebox=ttk.Combobox(action,textvariable=self.ai_course,state='readonly',width=28);self.ai_coursebox.pack(side='left',padx=4)
        ttk.Label(action,text='TKB từ tuần:').pack(side='left')
        ttk.Combobox(action,textvariable=self.ai_week,values=list(range(1,54)),state='readonly',width=4).pack(side='left')
        self.ai_summary=tk.StringVar()
        ttk.Label(source,textvariable=self.ai_summary,wraplength=1000).pack(anchor='w')
        for v in (self.ai_mode,self.ai_course,self.ai_week):v.trace_add('write',lambda *args:self.update_ai_summary())
        self.has_note=tk.BooleanVar(value=False)
        ttk.Checkbutton(source,text='Có ghi chú',variable=self.has_note,command=self.toggle_note).pack(anchor='w')
        self.note=tk.Text(source,height=3);self.note.pack(fill='x');self.note.configure(state='disabled')
        row=ttk.Frame(source);row.pack(fill='x',pady=7)
        ttk.Button(row,text='Xuất bộ hồ sơ gửi ChatGPT',command=self.export).pack(side='left')
        ttk.Button(row,text='Nhập kết quả phân tích',command=self.import_result).pack(side='left',padx=5)
        ttk.Button(row,text='Sao chép lệnh gửi ChatGPT',command=self.copy_chatgpt_prompt).pack(side='left',padx=5)
        row=ttk.Frame(source);row.pack(fill='x',pady=3)
        self.provider=tk.StringVar(value='Gemini')
        ttk.Combobox(row,textvariable=self.provider,values=['Gemini','OpenAI'],state='readonly',width=10).pack(side='left',padx=5)
        ttk.Button(row,text='Cài đặt AI',command=lambda:configure(self,self.provider.get()) if not self.running else None).pack(side='left',padx=4)
        ttk.Button(row,text='Phân tích bằng API AI',command=self.ai).pack(side='left')
        ttk.Label(source,text='API là tùy chọn, cần khóa riêng và có thể phát sinh phí. Tệp chỉ gửi khi bấm xác nhận.\nKhông có API: xuất hồ sơ, gửi ChatGPT phân tích rồi nhập profile.json được trả lại.').pack(anchor='w',pady=6)
        self.msg=tk.StringVar(value='Chưa phân tích');ttk.Label(source,textvariable=self.msg,wraplength=1000).pack(anchor='w')
        self.progress=ttk.Progressbar(source,mode='indeterminate');self.progress.pack(fill='x')
        review=ttk.Frame(self.book,padding=8);self.book.add(review,text='2. Kiểm tra / sửa TKB')
        self.rev=tk.StringVar();self.revbox=ttk.Combobox(review,textvariable=self.rev,state='readonly',width=38);self.revbox.pack(anchor='w');self.revbox.bind('<<ComboboxSelected>>',lambda e:self.show_rows())
        views=ttk.Notebook(review);views.pack(fill='both',expand=True)
        from timetable_grid import TimetableGrid
        self.tkb_grid=TimetableGrid(views,self);views.add(self.tkb_grid,text='Lưới thời khóa biểu')
        details=ttk.Frame(views);views.add(details,text='Chi tiết / Tuần mốc / PPCT đầu')
        self.cols=('day','session','slot','classroom','subject','course','anchor_week','start_period')
        self.table=ttk.Treeview(details,columns=self.cols,show='headings',height=17)
        for col,title in zip(self.cols,['Thứ','Buổi','Tiết','Lớp','Môn','Phân phối chương trình','Tuần mốc','PPCT đầu']):self.table.heading(col,text=title);self.table.column(col,width=135)
        self.sorter=TimetableSort(self.table,lambda:{str(i):dict(r,subject=self.p['courses'][r['course']].get('subject',self.p.get('subject','Toán'))) for i,r in enumerate(self.revision()['rows'])} if self.revision() else {},before_sort=self.close_cell_editor,subject_column='subject')
        self.table.column('course',width=190);self.table.column('slot',width=50)
        tkb_actions=ttk.Frame(details);tkb_actions.pack(side='bottom',fill='x')
        self.table.pack(fill='both',expand=True);self.table.bind('<ButtonRelease-1>',self.edit_cell)
        row=ttk.Frame(tkb_actions);row.pack(fill='x')
        for label,fn in [('Thêm tiết',self.add_row),('Xóa tiết chọn',self.delete_rows),('Tạo TKB từ tuần mới',self.new_revision),('Sửa khoảng tuần',self.edit_range),('Xóa TKB đang chọn',self.delete_revision),('Xem lịch tuần',self.preview)]:ttk.Button(row,text=label,command=fn).pack(side='left',padx=3)
        course=ttk.Frame(self.book,padding=8);self.book.add(course,text='3. Kiểm tra / sửa PPCT')
        self.course=tk.StringVar();self.coursebox=ttk.Combobox(course,textvariable=self.course,state='readonly',width=45);self.coursebox.pack(anchor='w');self.coursebox.bind('<<ComboboxSelected>>',self.switch_course)
        self.course_name=tk.StringVar();self.kind=tk.StringVar();self.teaching=tk.StringVar();self.exact=tk.BooleanVar(value=True)
        row=ttk.Frame(course);row.pack(fill='x',pady=4)
        for title,var in [('Tên',self.course_name),('Kiểu giảng dạy trên app',self.teaching)]:ttk.Label(row,text=title).pack(side='left');ttk.Entry(row,textvariable=var,width=30).pack(side='left',padx=4)
        ttk.Combobox(row,textvariable=self.kind,values=['Thường','Tích hợp','TT'],state='readonly',width=12).pack(side='left')
        sr=ttk.Frame(course);sr.pack(fill='x',pady=4)
        self.course_subject=tk.StringVar();self.hdtn=tk.BooleanVar(value=False)
        ttk.Label(sr,text='Môn trên app:').pack(side='left')
        ttk.Combobox(sr,textvariable=self.course_subject,values=['Toán','HĐTN'],width=24).pack(side='left',padx=5)
        ttk.Checkbutton(sr,text='HĐTN: PPCT 3 tiết/tuần, chỉ dạy tiết 2 và 3',variable=self.hdtn).pack(side='left')
        ttk.Label(course,text='Với HĐTN: tuần mốc 1, PPCT đầu 2 → tuần 1: 2–3; tuần 2: 5–6.').pack(anchor='w')
        ttk.Checkbutton(course,text='Đối chiếu cả tên bài trên app (bỏ chọn nếu file gộp tên nhiều tiết)',variable=self.exact).pack(anchor='w')
        ttk.Label(course,text='Chọn bài trong bảng rồi bấm Sửa bài, hoặc nhấp đúp. Áp dụng PPCT trước khi đổi danh mục.').pack(anchor='w')
        course_actions=ttk.Frame(course);course_actions.pack(side='bottom',fill='x',pady=4)
        pf=ttk.Frame(course);pf.pack(fill='both',expand=True)
        self.ppct_style=ttk.Style(self);self.ppct_style_name=f'Ppct{id(self)}.Treeview'
        self.ppct_font=tkfont.Font(root=self,font=self.ppct_style.lookup('Treeview','font') or ('Segoe UI',11))
        self.periods=ttk.Treeview(pf,style=self.ppct_style_name,columns=('number','title'),show='headings',selectmode='browse',height=20)
        self.periods.heading('number',text='Tiết PPCT');self.periods.heading('title',text='Tên bài dạy')
        self.periods.column('number',width=90,stretch=False);self.periods.column('title',width=850)
        pf.rowconfigure(0,weight=1);pf.columnconfigure(0,weight=1)
        self.periods.grid(row=0,column=0,sticky='nsew')
        ps=ttk.Scrollbar(pf,orient='vertical',command=self.periods.yview);ps.grid(row=0,column=1,sticky='ns')
        px=ttk.Scrollbar(pf,orient='horizontal',command=self.periods.xview);px.grid(row=1,column=0,sticky='ew')
        self.periods.configure(yscrollcommand=ps.set,xscrollcommand=px.set)
        self.periods.bind('<<TreeviewSelect>>',lambda e:self.resize_ppct())
        self.periods.bind('<Double-1>',lambda e:self.edit_lesson())
        pr=ttk.Frame(course_actions);pr.pack(fill='x')
        for title,fn in [('Thêm bài',lambda:self.edit_lesson(True)),('Sửa bài',self.edit_lesson),('Xóa bài',self.delete_lesson)]:ttk.Button(pr,text=title,command=fn).pack(side='left',padx=4)

        row=ttk.Frame(course_actions);row.pack(fill='x')
        ttk.Button(row,text='Áp dụng PPCT đang sửa',command=self.apply_course).pack(side='left')
        ttk.Button(row,text='Thêm danh mục PPCT',command=self.add_course).pack(side='left',padx=6)
        from mousewheel import bind_form_wheel
        self.refresh_form_wheel=bind_form_wheel(canvas,source)
        self.reload();add_tooltips(self)
        attach(self,list((v,k) for k,v in self.vars.items())+[(getattr(self,k),k) for k in ('integrated','has_integrated','provider','reviewed')])
        hint(self.note,'Ghi rõ file của khối/lớp nào và thay đổi cần phân tích. Ví dụ tuần mốc 6, PPCT đầu 21. Thêm HĐTN có nút riêng ở màn hình chính.')
        self.after(150,self.poll)
        if review_only:
            self.book.hide(source_page);self.book.select(review)
            self.title('Đối chiếu kết quả AI — chưa áp dụng')
            ttk.Label(actions,text='Kiểm tra xong → tích ô phía trên → Đồng ý.',wraplength=330).pack(side='left')
        from drafts import DraftStore
        self._drafts=DraftStore()
        if resume:self.restore_draft(resume)
        self.save_draft();self.after(3000,self.auto_draft)
        self.protocol('WM_DELETE_WINDOW',self.close)
    def resize_ppct(self):
        from borrow_ui import title_dimensions
        titles=[self.periods.item(i,'values')[1] for i in self.periods.get_children()]
        height,width=title_dimensions(titles,self.ppct_font)
        self.ppct_style.configure(self.ppct_style_name,font=self.ppct_font,rowheight=height)
        self.periods.column('title',width=max(850,width),stretch=False)
    def update_ai_summary(self):
        mode=self.ai_mode.get()
        if mode=='Cập nhật PPCT hiện có':
            text='Thay PPCT '+self.ai_course.get()+'. Giữ nguyên TKB và các danh mục khác.'
        elif mode=='Cập nhật TKB mới nhất':
            text='Cập nhật TKB từ tuần '+str(self.ai_week.get())+'. Giữ lịch các tuần trước và PPCT hiện có.'
        else:text='Phân tích các tài liệu đã chọn để hoàn thiện hồ sơ.'
        self.ai_summary.set(text)
    def toggle_note(self):
        self.note.configure(state='normal' if self.has_note.get() else 'disabled')
    def show_teaching_summary(self):
        from teacher_setup import teaching_overview
        for w in self.teaching_summary.winfo_children():w.destroy()
        self.summary_vars=[]
        for key,title in [('hdtn','Có dạy HĐTN'),('integrated','Có dạy tích hợp'),('extra','Có dạy tăng tiết')]:
            classes=teaching_overview(self.p)[key]
            var=tk.BooleanVar(value=bool(classes));self.summary_vars.append(var)
            line=ttk.Frame(self.teaching_summary);line.pack(fill='x',pady=2)
            tick=tk.Checkbutton(line,text=title,variable=var,state='disabled',disabledforeground='#183c52',anchor='w',font=('Segoe UI',11,'bold'))
            tick.pack(side='left')
            ttk.Label(line,text='Lớp: '+', '.join(classes) if classes else 'Không dạy',wraplength=650).pack(side='left',padx=10)
    def reconfigure(self):
        if self.running:return
        def ready(p):
            self.p=p
            for k,v in self.vars.items():v.set(p[k])
            self.integrated.set(', '.join(p.get('integrated_classes',[])))
            self.has_integrated.set(bool(p.get('integrated_classes')))
            self.show_teaching_summary()
            self.reviewed.set(False)
        ProfileWizard(self,ready,self.p)
    def draft_payload(self):
        p=copy.deepcopy(self.p)
        for k,v in self.vars.items():p[k]=v.get()
        p['integrated_classes']=[x.strip() for x in self.integrated.get().split(',') if x.strip()] if self.has_integrated.get() else []
        buffer=dict(code=self.course.get(),name=self.course_name.get(),kind=self.kind.get(),teaching=self.teaching.get(),subject=self.course_subject.get(),hdtn=self.hdtn.get(),exact=self.exact.get(),periods=[list(self.periods.item(i,'values')) for i in self.periods.get_children()])
        return dict(ai_mode=self.ai_mode.get(),ai_course=self.ai_course.get(),ai_week=self.ai_week.get(),p=p,files=self.files,note=self.note.get('1.0','end-1c'),has_note=self.has_note.get(),buffer=buffer,review_only=self.review_only,tab=self.book.index(self.book.select()))
    def save_draft(self,notice=False):
        try:
            data=self._drafts.save('editor',self.p['id'],self.draft_payload())
            self.draft_status.set('Đã lưu nháp lúc '+data['saved_at'][11:])
            if notice:messagebox.showinfo('Đã lưu nháp','Dùng Tiếp tục bản nháp để mở lại công việc này.',parent=self)
            return True
        except Exception as e:
            self.draft_status.set('Chưa lưu được nháp: '+str(e))
            if notice:messagebox.showerror('Lưu nháp',str(e),parent=self)
            return False
    def auto_draft(self):
        if self.winfo_exists():self.save_draft();self.after(3000,self.auto_draft)
    def restore_draft(self,data):
        self.ai_mode.set(data.get('ai_mode','Phân tích toàn bộ'));self.ai_course.set(data.get('ai_course',self.ai_course.get()));self.ai_week.set(data.get('ai_week',1))
        self.files=[tuple(item) for item in data.get('files',[])];self.source_list.delete(0,'end')
        for role,path in self.files:self.source_list.insert('end',role+' — '+Path(path).name)
        self.note.configure(state='normal');self.note.delete('1.0','end');self.note.insert('1.0',data.get('note',''));self.has_note.set(data.get('has_note',False));self.toggle_note()
        b=data.get('buffer',{})
        if b.get('code') in self.p.get('courses',{}):
            self.course.set(b['code']);self.show_course()
            for attr,k in [('course_name','name'),('kind','kind'),('teaching','teaching'),('course_subject','subject'),('hdtn','hdtn'),('exact','exact')]:getattr(self,attr).set(b[k])
            self.periods.delete(*self.periods.get_children())
            for n,title in b.get('periods',[]):self.periods.insert('','end',iid=str(n),values=(n,title))
        self.resize_ppct()
        self.reviewed.set(False)
        try:self.book.select(data.get('tab',1 if self.review_only else 0))
        except tk.TclError:pass
    def close(self):
        if self.running: messagebox.showinfo('Đang phân tích','Chờ kết quả phân tích trước khi đóng.',parent=self);return
        if not self.save_draft():
            if not messagebox.askyesno('Chưa lưu được nháp','Vẫn đóng và bỏ các thay đổi chưa lưu?',parent=self):return
        self.destroy()
    def metadata(self):
        for k,v in self.vars.items():self.p[k]=v.get().strip()
        self.p['integrated_classes']=[x.strip() for x in self.integrated.get().split(',') if x.strip()] if self.has_integrated.get() else []
        if self.has_integrated.get() and not self.p['integrated_classes']:raise ValueError('Nhập các lớp tích hợp.')
        self.p['sources']=[{'role':r,'name':Path(f).name} for r,f in self.files] or self.p.get('sources',[])
        return self.p
    def add_files(self,role):
        for f in filedialog.askopenfilenames(parent=self,title='Chọn '+role,filetypes=[('Tài liệu','*.png *.jpg *.jpeg *.webp *.pdf *.xlsx *.xls *.docx *.csv *.txt *.json')]):self.files.append((role,f));self.source_list.insert('end',role+' — '+Path(f).name)
        self.reviewed.set(False)
    def remove_file(self):
        for i in reversed(self.source_list.curselection()):self.source_list.delete(i);self.files.pop(i)
    def request_data(self):
        p=self.metadata();roles={r for r,f in self.files}
        if not p['name'] or not p['subject']:raise ValueError('Điền tên giáo viên và môn học.')
        if not p.get('schedules') and 'TKB' not in roles:raise ValueError('Cần gửi TKB.')
        if not p.get('courses') and not {'PPCT khối','PPCT tích hợp','PPCT TT','PPCT HĐTN'}&roles:raise ValueError('Cần gửi PPCT của khối/lớp.')
        if not p.get('courses'):
            options=p.get('teaching_options')
            if options is None:
                if p['integrated_classes'] and not {'PPCT tích hợp','PPCT TT'}<=roles:raise ValueError('Cần gửi PPCT riêng và PPCT tăng tiết của lớp tích hợp.')
            else:
                for kind,role in [('hdtn','PPCT HĐTN'),('integrated','PPCT tích hợp'),('extra','PPCT TT')]:
                    if options.get(kind) and role not in roles:raise ValueError('Cần thêm tài liệu '+role+' cho các lớp đã chọn.')
        note=(self.note.get('1.0','end').strip() if self.has_note.get() else '')+'\n'+setup_note(p)+'\nVai trò các tệp: '+json.dumps(p['sources'],ensure_ascii=False)
        mode=self.ai_mode.get()
        if mode=='Cập nhật PPCT hiện có':
            code=self.ai_course_codes.get(self.ai_course.get())
            if not code:raise ValueError('Chọn danh mục PPCT cần thay.')
            files=[f for r,f in self.files if r.startswith('PPCT')]
            if not files:raise ValueError('Thêm tệp PPCT mới trước khi phân tích.')
            note+='\nCHỈ cập nhật thay thế toàn bộ periods của course '+code+' ('+p['courses'][code]['name']+'). Giữ mã course, TKB, week_assignments và các course khác. Dùng tệp mới làm nguồn PPCT mới nhất; không trộn bài cũ còn sót.'
        elif mode=='Cập nhật TKB mới nhất':
            files=[f for r,f in self.files if r=='TKB']
            if not files:raise ValueError('Thêm tệp TKB mới trước khi phân tích.')
            note+='\nCHỈ cập nhật TKB mới nhất áp dụng từ tuần '+str(self.ai_week.get())+'. Giữ các phiên bản tuần trước, điều chỉnh khoảng áp dụng không chồng nhau. Giữ nguyên courses/PPCT hiện có. Nếu số tiết thay đổi mà chưa đủ mốc PPCT, hỏi lại; không tự đoán.'
        else:files=[f for r,f in self.files]
        return copy.deepcopy(p),note,files
    def copy_chatgpt_prompt(self):
        try:
            p,n,files=self.request_data()
            self.clipboard_clear();self.clipboard_append(chatgpt_request(n));self.update_idletasks()
            self.msg.set('Đã sao chép lệnh. Xuất bộ hồ sơ cùng lựa chọn hiện tại, đính kèm ZIP trong ChatGPT rồi Ctrl+V. Không cần API.')
        except Exception as e:messagebox.showerror('Sao chép lệnh',str(e),parent=self)
    def export(self):
        try:
            p,n,files=self.request_data();target=filedialog.asksaveasfilename(parent=self,defaultextension='.zip',initialfile='Ho_so_can_phan_tich.zip')
            if target:export_request(p,n,files,target);self.msg.set('Đã xuất hồ sơ. Bấm Sao chép lệnh gửi ChatGPT, đính kèm ZIP rồi Ctrl+V. ZIP cũng có LENH_GUI_CHATGPT.txt.')
        except Exception as e:messagebox.showerror('Hồ sơ',str(e),parent=self)
    def import_result(self):
        f=filedialog.askopenfilename(parent=self,filetypes=[('Kết quả','*.json')])
        if not f:return
        try:
            from teacher_setup import preserve_setup
            p=validate(preserve_setup(self.p,json.loads(Path(f).read_text(encoding='utf-8-sig'))));p['id']=self.p['id'];self.accept_result(p)
        except Exception as e:messagebox.showerror('Kết quả',str(e),parent=self)
    def ai(self):
        if self.running:return
        try:p,n,files=self.request_data()
        except Exception as e:messagebox.showerror('Hồ sơ',str(e),parent=self);return
        provider=self.provider.get()
        saved=credentials(self,provider)
        if not saved:return
        model,secret=saved
        if not messagebox.askokcancel('Gửi tài liệu phân tích',f'Gửi {len(files)} tệp được chọn và nội dung hồ sơ tới {provider} API? Có thể phát sinh phí API. Kết quả cần được kiểm tra trước khi chạy điện thoại.',parent=self):return
        self.running=True;self.started=time.monotonic();self.stage='Đang chuẩn bị tài liệu';self.progress.start(15);self.reviewed.set(False)
        mode=self.ai_mode.get();code=self.ai_course_codes.get(self.ai_course.get())
        def worker():
            try:
                result=analyze(p,n,files,secret,model,provider,progress=lambda message:self.results.put(('progress',message)))
                if mode=='Cập nhật PPCT hiện có':
                    if code not in result['courses']:raise ValueError('AI không trả đúng danh mục PPCT đã chọn.')
                    merged=copy.deepcopy(p);merged['courses'][code]['periods']=result['courses'][code]['periods']
                    merged['courses'][code]['exact_title']=result['courses'][code].get('exact_title',False)
                    merged['analysis_notes']=result.get('analysis_notes','');merged['reviewed']=False;result=merged
                elif mode=='Cập nhật TKB mới nhất':result['courses']=copy.deepcopy(p['courses'])
                self.results.put(('ok',result))
            except Exception as e:self.results.put(('error',str(e)))
        threading.Thread(target=worker,daemon=True).start()
    def poll(self):
        try:
            while True:
                kind,value=self.results.get_nowait()
                if kind=='progress':self.stage=value;continue
                self.running=False;self.progress.stop()
                if kind=='ok':
                    self.msg.set('AI đã phân tích xong. Đang mở bảng đối chiếu — chưa áp dụng vào hồ sơ.')
                    try:validate(value);self.accept_result(value)
                    except Exception as e:self.msg.set('Kết quả chưa hợp lệ: '+str(e))
                else:self.msg.set('Phân tích chưa thành công: '+value)
        except queue.Empty:pass
        if self.running:self.msg.set(self.stage+f' • Đã chờ {int(time.monotonic()-self.started)} giây')
        self.after(150,self.poll)
    def accept_result(self,p):
        from teacher_setup import preserve_setup
        from ppct_cleanup import repair_merged_lessons
        candidate=repair_merged_lessons(preserve_defaults(self.p,preserve_setup(self.p,copy.deepcopy(p))))
        validate(candidate)
        def approved(result):
            self.p=copy.deepcopy(result)
            for k,v in self.vars.items():v.set(self.p[k])
            self.integrated.set(', '.join(self.p.get('integrated_classes',[])))
            self.has_integrated.set(bool(self.p.get('integrated_classes')))
            self.show_teaching_summary();self.reload();self.reviewed.set(True)
            self.msg.set('Đã đồng ý kết quả TKB và PPCT. Bấm Lưu hồ sơ để lưu xuống máy.')
            self.book.select(1)
        editor=ProfileEditor(self,candidate,approved,'Đối chiếu kết quả AI',review_only=True)
        if 'đã tách ô gộp trùng' in candidate.get('analysis_notes',''):
            messagebox.showinfo('Đã kiểm tra ô PPCT gộp',candidate['analysis_notes'],parent=editor)
        editor.grab_set();self.wait_window(editor)
        if self.winfo_exists():self.grab_set()
    def reload(self):
        self.ai_course_codes={str(c.get('name',code))+' ['+code+']':code for code,c in self.p.get('courses',{}).items()}
        self.ai_coursebox['values']=list(self.ai_course_codes)
        if self.ai_course.get() not in self.ai_course_codes:self.ai_course.set(next(iter(self.ai_course_codes),''))
        self.update_ai_summary()
        self.revisions=sorted(self.p.get('schedules',[]),key=lambda r:r['from_week'])
        self.revbox['values']=[range_label(self.revisions,r) for r in self.revisions]
        if self.revisions:self.revbox.current(len(self.revisions)-1)
        self.show_rows();self.coursebox['values']=list(self.p.get('courses',{}))
        if self.p.get('courses'):self.course.set(next(iter(self.p['courses'])))
        self.show_course()
    def revision(self):
        i=self.revbox.current()
        return self.revisions[i] if 0<=i<len(self.revisions) else None
    def select_revision(self,start):
        for i,r in enumerate(self.revisions):
            if r['from_week']==start:self.revbox.current(i);break
        self.show_rows()
    def close_cell_editor(self):
        if getattr(self,'cell_editor',None):self.cell_editor.destroy();self.cell_editor=None
    def show_rows(self):
        if getattr(self,'cell_editor',None):self.cell_editor.destroy();self.cell_editor=None
        self.table.delete(*self.table.get_children());rev=self.revision()
        if rev:
            for i,r in enumerate(rev['rows']):
                values=[DAYS[r['day']],SESSIONS[r['session']],r['slot'],r['classroom'],self.p['courses'][r['course']].get('subject',self.p.get('subject','Toán')),course_label(r['course'],self.p['courses'][r['course']]),r['anchor_week'],r['start_period']]
                self.table.insert('','end',iid=str(i),values=values)
        self.sorter.apply()
        self.tkb_grid.render()
    def edit_cell(self,event):
        if self.table.identify_region(event.x,event.y)!='cell':return
        row=self.table.identify_row(event.y);col=self.table.identify_column(event.x)
        if not row or not col:return
        k=self.cols[int(col[1:])-1];r=self.revision()['rows'][int(row)]
        if k=='subject':return
        if k=='day':choices=list(DAYS.items())
        elif k=='session':choices=list(SESSIONS.items())
        elif k=='slot':choices=[(n,'Tiết '+str(n)) for n in range(1,6)]
        elif k=='anchor_week':choices=[(n,'Tuần '+str(n)) for n in range(1,54)]
        elif k=='classroom':choices=[(x,x) for x in sorted({row['classroom'] for rev in self.p.get('schedules',[]) for row in rev['rows']}|set(self.p.get('integrated_classes',[]))|set(self.p.get('declared_classes',[])))]
        elif k=='course':choices=[(code,course_label(code,c)) for code,c in self.p.get('courses',{}).items()]
        else:
            course=self.p.get('courses',{}).get(r['course'],{})
            choices=[(int(n),title) for n,title in sorted(course.get('periods',{}).items(),key=lambda x:int(x[0]))]
        def apply(v):
            if k in ('anchor_week','start_period'):
                for other in self.revision()['rows']:
                    if (other['classroom'],other['course'])==(r['classroom'],r['course']):other[k]=v
            else:r[k]=v
            self.show_rows();self.reviewed.set(False)
        if k in ('anchor_week','start_period'):
            v=choose(self,'Chọn '+self.table.heading(k)['text'],self.table.heading(k)['text']+'\n'+HINTS[k],choices,r[k])
            if v is not None:apply(v)
            return
        if getattr(self,'cell_editor',None):self.cell_editor.destroy()
        bounds=self.table.bbox(row,col)
        if not bounds:return
        labels=[label for value,label in choices]
        # Preserve readable names; disambiguate only when two catalogs share a name.
        if len(set(labels))!=len(labels):labels=[f'{label} ({value})' for value,label in choices]
        box=ttk.Combobox(self.table,values=labels,state='normal' if k=='classroom' else 'readonly',height=12)
        self.cell_editor=box;box.place(x=bounds[0],y=bounds[1],width=max(bounds[2],180 if k=='course' else bounds[2]),height=bounds[3])
        current=next((i for i,(v,label) in enumerate(choices) if v==r[k]),-1)
        if current>=0:box.current(current)
        else:box.set(str(r[k]))
        def selected(event=None):
            i=box.current()
            if i>=0:apply(choices[i][0])
            elif k=='classroom' and box.get().strip():apply(box.get().strip())
        box.bind('<<ComboboxSelected>>',selected);box.bind('<Return>',selected)
        box.bind('<Escape>',lambda e:box.destroy());box.focus_set()
        box.after_idle(lambda:box.event_generate('<Down>') if box.winfo_exists() else None)
    def add_row(self):
        if not self.revision():self.new_revision()
        if self.revision():self.revision()['rows'].append(dict(day=2,session='Sáng',slot=1,classroom='LỚP',course=self.course.get(),anchor_week=self.revision()['from_week'],start_period=1));self.show_rows();self.reviewed.set(False)
    def delete_rows(self):
        for i in sorted(map(int,self.table.selection()),reverse=True):self.revision()['rows'].pop(i)
        self.show_rows();self.reviewed.set(False)
    def new_revision(self):
        old=self.revision();value=range_dialog(self,(old['from_week']+1 if old and old['from_week']<53 else 1))
        if value is None:return
        try:self.p['schedules']=change_range(self.p.get('schedules',[]),None,*value,old['rows'] if old else [])
        except ValueError as e:messagebox.showerror('TKB',str(e),parent=self);return
        self.reload();self.select_revision(value[0]);self.reviewed.set(False)
        messagebox.showinfo('Mốc PPCT','Đã tạo bản sao lịch để sửa. Nếu số tiết/tuần thay đổi, đặt tuần mốc và PPCT đầu để tiếp nối đúng.',parent=self)
    def edit_range(self):
        old=self.revision()
        if not old:return
        value=range_dialog(self,old['from_week'],old.get('to_week'))
        if value is None:return
        try:self.p['schedules']=change_range(self.p['schedules'],old['from_week'],*value,old['rows'])
        except ValueError as e:messagebox.showerror('TKB',str(e),parent=self);return
        self.reload();self.select_revision(value[0]);self.reviewed.set(False)
    def delete_revision(self):
        old=self.revision()
        if not old:return
        if not messagebox.askyesno('Xóa phiên bản TKB','Xóa '+range_label(self.p['schedules'],old)+' khỏi hồ sơ? Không xóa sổ đã ghi trên điện thoại. Các tuần mất lịch cần thêm TKB mới.',parent=self):return
        try:self.p['schedules']=remove_revision(self.p['schedules'],old['from_week'])
        except ValueError as e:messagebox.showerror('TKB',str(e),parent=self);return
        self.reload();self.reviewed.set(False)
    def switch_course(self,event=None):
        target=self.course.get();previous=getattr(self,'loaded_course',None)
        if self.review_only and previous and previous in self.p['courses']:
            self.course.set(previous)
            if not self.apply_course():return
            self.course.set(target)
        self.show_course()
    def show_course(self):
        self.loaded_course=self.course.get()
        c=self.p.get('courses',{}).get(self.course.get(),{})
        self.course_subject.set(c.get('subject',self.vars['subject'].get()));self.hdtn.set(c.get('weekly_stride')==3 and c.get('taught_offsets')==[2,3])
        self.course_name.set(c.get('name',''));self.kind.set(c.get('kind','Thường'));self.teaching.set(c.get('teaching_type',''));self.exact.set(c.get('exact_title',True))
        self.periods.delete(*self.periods.get_children())
        for n,title in sorted(c.get('periods',{}).items(),key=lambda x:int(x[0])):self.periods.insert('','end',iid=str(n),values=(n,title))
        self.resize_ppct()
    def edit_lesson(self,new=False):
        selected=self.periods.selection()
        if not new and not selected:return
        if new:
            n=simpledialog.askinteger('Thêm bài','Số tiết trong PPCT (không phải tiết trên TKB):',minvalue=1,parent=self)
            if n is None:return
            if self.periods.exists(str(n)):messagebox.showinfo('PPCT','Số PPCT đã có. Chọn bài đó để sửa.',parent=self);return
            current=''
        else:
            n=int(selected[0]);current=self.periods.item(selected[0],'values')[1]
        title=simpledialog.askstring('Tên bài dạy',f'PPCT {n} — tên đúng trên ứng dụng:',initialvalue=current,parent=self)
        if title is None or not title.strip():return
        if self.periods.exists(str(n)):self.periods.item(str(n),values=(n,title.strip()))
        else:self.periods.insert('','end',iid=str(n),values=(n,title.strip()))
        self.resize_ppct()
        for i,item in enumerate(sorted(self.periods.get_children(),key=int)):self.periods.move(item,'',i)
        self.periods.selection_set(str(n));self.periods.see(str(n));self.reviewed.set(False)
    def delete_lesson(self):
        selected=self.periods.selection()
        if selected and messagebox.askokcancel('Xóa bài','Xóa bài khỏi danh mục đang chỉnh? Không xóa sổ trên eNetViet.',parent=self):
            self.periods.delete(*selected);self.reviewed.set(False)
    def apply_course(self):
        try:
            periods={}
            for item in self.periods.get_children():
                n,title=self.periods.item(item,'values');periods[str(int(n))]=title.strip()
            if not self.course.get():raise ValueError('Chọn/thêm danh mục trước.')
            old=self.p.get('courses',{}).get(self.course.get(),{})
            self.p.setdefault('courses',{})[self.course.get()]={'name':self.course_name.get(),'kind':self.kind.get(),'teaching_type':self.teaching.get(),'exact_title':self.exact.get(),'periods':periods}
            updated=self.p['courses'][self.course.get()]
            updated['subject']=self.course_subject.get().strip() or self.vars['subject'].get().strip()
            if self.hdtn.get():updated.update(weekly_stride=3,taught_offsets=[2,3])
            elif old.get('taught_offsets') and old.get('taught_offsets')!=[2,3]:
                updated.update(weekly_stride=old['weekly_stride'],taught_offsets=old['taught_offsets'])
            self.reviewed.set(False);return True
        except Exception as e:messagebox.showerror('PPCT',str(e),parent=self);return False
    def add_course(self):
        key=simpledialog.askstring('PPCT mới','Mã danh mục (ví dụ Toan8 hoặc 8A1_TT):',parent=self)
        if not key:return
        if key in self.p.get('courses',{}):return
        self.p.setdefault('courses',{})[key]={'name':key,'kind':'Thường','periods':{}}
        self.coursebox['values']=list(self.p['courses']);self.course.set(key);self.show_course();self.reviewed.set(False)
    def preview(self):
        w=simpledialog.askinteger('Xem lịch','Tuần:',minvalue=1,maxvalue=53,parent=self)
        if w is None:return
        try:
            tasks=plan(self.metadata(),w)
            win=tk.Toplevel(self);win.title('Lịch tuần '+str(w));win.geometry('1000x550');text=tk.Text(win,wrap='word');text.pack(fill='both',expand=True)
            for t in tasks:text.insert('end',f"{DAYS[t['day']]} {SESSIONS[t['session']]} tiết {t['slot']} | {t['classroom']} | {course_label(t['course'],self.p['courses'][t['course']])} | PPCT {t['period']} | {t['title']}\n")
            text.configure(state='disabled')
        except Exception as e:messagebox.showerror('Lịch',str(e),parent=self)
    def save(self):
        if self.running:return
        if not self.reviewed.get():messagebox.showinfo('Kiểm tra','Kiểm tra các tab, áp dụng PPCT đã sửa rồi đánh dấu đã kiểm tra.',parent=self);return
        try:
            if self.course.get() and not self.apply_course():return
            p=validate(self.metadata());p['reviewed']=True;self.on_save(p);self._drafts.delete('editor',p['id']);self._drafts.delete('wizard',p['id']);self.destroy()
        except Exception as e:messagebox.showerror('Hồ sơ',str(e),parent=self)


def empty_profile():
    return dict(schema=2,id=str(uuid.uuid4()),name='',subject='Toán',school_year='2026-2027',integrated_classes=[],courses={},schedules=[],sources=[],reviewed=False)
