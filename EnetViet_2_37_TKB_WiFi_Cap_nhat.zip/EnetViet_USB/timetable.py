import copy
import re
DAYS={2:'Thứ Hai',3:'Thứ Ba',4:'Thứ Tư',5:'Thứ Năm',6:'Thứ Sáu',7:'Thứ Bảy',8:'Chủ Nhật'}
SESSIONS={'Sáng':'Buổi sáng','Chiều':'Buổi chiều'}

def course_label(code,course):
    name=course.get('name',code)
    if code=='6A11' and name=='6A11':return 'Toán 6 Tích hợp'
    if code=='6A11_TT' and name=='6A11_TT':return 'Toán 6 Tăng tiết'
    return name

def end_week(schedules,rev):
    later=[s['from_week'] for s in schedules if s['from_week']>rev['from_week']]
    return min(rev.get('to_week') or 53, min(later)-1 if later else 53)

def active_revision(schedules,week):
    matches=[r for r in schedules if r['from_week']<=week<=end_week(schedules,r)]
    return max(matches,key=lambda r:r['from_week']) if matches else None

def range_label(schedules,rev):
    end=end_week(schedules,rev)
    return f"Tuần {rev['from_week']}–{end}" if end<53 or rev.get('to_week') else f"Từ tuần {rev['from_week']} trở đi"

def change_range(schedules,old_start,start,end,rows):
    if not 1<=start<=53 or (end is not None and not start<=end<=53):raise ValueError('Tuần kết thúc phải từ tuần bắt đầu đến 53.')
    result=copy.deepcopy([r for r in schedules if r['from_week']!=old_start])
    if any(r['from_week']==start for r in result):raise ValueError('Đã có TKB bắt đầu ở tuần này.')
    later=[r['from_week'] for r in result if r['from_week']>start]
    if end is not None and later and end>=min(later):raise ValueError('Khoảng tuần trùng TKB sau. Chọn kết thúc trước tuần '+str(min(later))+'.')
    for r in result:
        if r['from_week']<start and (r.get('to_week') or 53)>=start:r['to_week']=start-1
    result.append({'from_week':start,'to_week':end,'rows':copy.deepcopy(rows)})
    return sorted(result,key=lambda r:r['from_week'])

def remove_revision(schedules,start):
    if len(schedules)<=1:raise ValueError('Cần giữ ít nhất một TKB. Hãy thêm TKB mới trước khi xóa bản cũ.')
    # Freeze previous effective ends so deletion never extends an older schedule.
    result=[]
    for r in schedules:
        if r['from_week']==start:continue
        v=copy.deepcopy(r);v['to_week']=end_week(schedules,r);result.append(v)
    return result

def range_dialog(parent,start,end=None):
    import tkinter as tk
    from tkinter import ttk,messagebox
    win=tk.Toplevel(parent);win.title('Thời gian áp dụng TKB');win.transient(parent)
    previous=parent.grab_current();win.grab_set();result=[]
    a=tk.StringVar(value=str(start));b=tk.StringVar(value=str(end or start));forever=tk.BooleanVar(value=end is None)
    from branding import credit
    credit(win)
    box=ttk.Frame(win,padding=18);box.pack()
    ttk.Label(box,text='TKB bắt đầu áp dụng từ tuần:').grid(row=0,column=0,sticky='w',pady=8)
    ttk.Combobox(box,textvariable=a,values=list(range(1,54)),state='readonly',width=6).grid(row=0,column=1)
    ttk.Label(box,text='Đến hết tuần:').grid(row=1,column=0,sticky='w',pady=8)
    last=ttk.Combobox(box,textvariable=b,values=list(range(1,54)),state='readonly',width=6);last.grid(row=1,column=1)
    def state():last.configure(state='disabled' if forever.get() else 'readonly')
    ttk.Checkbutton(box,text='Áp dụng từ tuần này trở đi',variable=forever,command=state).grid(row=2,column=0,columnspan=2,sticky='w');state()
    ttk.Label(box,text='TKB mới sẽ thay lịch cũ từ tuần bắt đầu.\nNếu có TKB sau đó, lịch này dừng trước tuần của TKB sau.').grid(row=3,column=0,columnspan=2,pady=10)
    def save():
        first=int(a.get());last=None if forever.get() else int(b.get())
        if last is not None and last<first:messagebox.showerror('Khoảng tuần','Tuần kết thúc phải bằng hoặc sau tuần bắt đầu.',parent=win);return
        result.append((first,last));win.destroy()
    ttk.Button(box,text='Áp dụng',command=save).grid(row=4,column=1)
    ttk.Button(box,text='Hủy',command=win.destroy).grid(row=4,column=0)
    parent.wait_window(win)
    if previous:previous.grab_set()
    return result[0] if result else None
