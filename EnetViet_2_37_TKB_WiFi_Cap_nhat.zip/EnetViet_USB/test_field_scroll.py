import unittest
from types import SimpleNamespace
from xml.etree.ElementTree import Element
from engine import FormAssistant

class FieldScrollTests(unittest.TestCase):
    def test_bottom_label_scrolls_down_before_scanning_up(self):
        f=FormAssistant.__new__(FormAssistant);moves=[];logs=[]
        f.d=SimpleNamespace(window_size=lambda:(500,900));f.log=logs.append;f.check=lambda:None
        lab=Element('node',text='Học tập',bounds='[20,730][400,770]')
        edit=Element('node',attrib={'class':'android.widget.EditText','text':'20','bounds':'[20,400][400,450]'})
        f.nodes=lambda:[lab]
        f.section=lambda a,b:[] if len(moves)<2 else [edit]
        f.scroll=lambda forward=True:moves.append(forward)
        self.assertFalse(f.field('Học tập','Kỷ luật','20'))
        self.assertEqual(moves,[True,True]);self.assertEqual(len(logs),2)
    def test_scores_below_remark_scroll_down(self):
        f=FormAssistant.__new__(FormAssistant);moves=[]
        f.d=SimpleNamespace(window_size=lambda:(500,900));f.log=lambda s:None;f.check=lambda:None
        f.nodes=lambda:[Element('node',text='Nhận xét của giáo viên')]
        edit=Element('node',attrib={'class':'android.widget.EditText','text':'20','bounds':'[20,400][400,450]'})
        def section(a,b):
            if not moves:raise RuntimeError('not visible')
            return [edit]
        f.section=section;f.scroll=lambda forward=True:moves.append(forward)
        self.assertFalse(f.field('Học tập','Kỷ luật','20'));self.assertEqual(moves,[True])
