"""Separate incomplete work from runnable teacher profiles."""
import json
import uuid
from datetime import datetime
from pathlib import Path

class DraftStore:
    def __init__(self,root=None):
        self.root=Path(root) if root else Path(__file__).parent/'ban_nhap'
    def path(self,kind,identity):
        uuid.UUID(identity)
        if kind not in ('wizard','editor'):raise ValueError('Loại bản nháp không hợp lệ.')
        return self.root/(kind+'_'+identity+'.json')
    def save(self,kind,identity,data):
        from profiles import atomic_json
        result=dict(data,kind=kind,identity=identity,saved_at=datetime.now().isoformat(timespec='seconds'))
        atomic_json(self.path(kind,identity),result)
        return result
    def delete(self,kind,identity):self.path(kind,identity).unlink(missing_ok=True)
    def list(self):
        if not self.root.exists():return []
        result=[]
        for path in self.root.glob('*.json'):
            try:
                data=json.loads(path.read_text(encoding='utf-8'))
                self.path(data['kind'],data['identity']);result.append(data)
            except (ValueError,KeyError,TypeError):continue
        return sorted(result,key=lambda d:d['saved_at'],reverse=True)

def resume_draft(parent,on_saved):
    from widgets import choose
    from profile_ui import ProfileEditor
    from onboarding import ProfileWizard
    from tkinter import messagebox
    items=DraftStore().list()
    if not items:messagebox.showinfo('Bản nháp','Chưa có bản nháp đang làm dở.',parent=parent);return
    options=[]
    for i,d in enumerate(items):
        p=d.get('p',d.get('base',{}))
        name=d.get('name') or p.get('name') or 'Chưa nhập tên'
        options.append((i,name+' — '+('Tạo hồ sơ' if d['kind']=='wizard' else 'TKB / PPCT')+' — '+d['saved_at']))
    index=choose(parent,'Tiếp tục bản nháp','Chọn hồ sơ đang làm dở để tiếp tục:',options)
    if index is None:return
    d=items[index]
    def ready(p):
        editor=ProfileEditor(parent,p,on_saved,'Tiếp tục hồ sơ');editor.grab_set()
    if d['kind']=='wizard':ProfileWizard(parent,ready,base=d['base'],resume=d)
    else:
        editor=ProfileEditor(parent,d['p'],on_saved,'Tiếp tục bản nháp',review_only=d.get('review_only',False),resume=d);editor.grab_set()
