import unittest
from ppct_cleanup import repair_merged_lessons

class CleanupTests(unittest.TestCase):
    def profile(self,text,count=2):return {'courses':{'7':{'name':'Toán 7','periods':{str(23+i):text for i in range(count)}}}}
    def test_user_example_keeps_prefix_only_on_23(self):
        text='KTTX2 - HH - CHƯƠNG 3 - LMS\nCHƯƠNG 4: HAI TAM GIÁC BẰNG NHAU.\nBÀI 12. Tổng các góc trong một tam giác\nBài 13. Hai tam giác bằng nhau. Trường hợp bằng nhau thứ nhất của tam giác (t1)'
        source=self.profile(text);out=repair_merged_lessons(source);periods=out['courses']['7']['periods']
        self.assertEqual(periods['23'],text.rsplit('\n',1)[0]);self.assertEqual(periods['24'],text.rsplit('\n',1)[1])
        self.assertEqual(source['courses']['7']['periods']['23'],text)
        self.assertEqual(repair_merged_lessons(out),out)
    def test_one_lesson_over_two_periods_unchanged(self):
        source=self.profile('Bài 12. Một bài\nTiếp tục luyện tập')
        self.assertEqual(repair_merged_lessons(source),source)
    def test_ambiguous_three_periods_stops(self):
        with self.assertRaisesRegex(ValueError,'chưa đủ căn cứ'):repair_merged_lessons(self.profile('Bài 12. Một\nBài 13. Hai',3))
