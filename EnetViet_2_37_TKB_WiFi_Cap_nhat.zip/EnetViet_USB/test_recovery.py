import copy
import json
import tempfile
import unittest
from pathlib import Path
from drafts import DraftStore
from profiles import Store,Ledger,default_profile,plan,key,atomic_json
from preflight import data_checks,device_checks
from status_cells import COLORS,TEXT
from types import SimpleNamespace

class RecoveryTests(unittest.TestCase):
    def test_incomplete_draft_roundtrip_separate_from_profiles(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);drafts=DraftStore(root/'ban_nhap');p=default_profile();p['name']='';p['courses']={}
            payload=dict(p=p,note='Đang sửa',has_note=False,buffer={'name':'Bài chưa chốt'},files=[['TKB','C:/tkb.xlsx']],review_only=True)
            drafts.save('editor',p['id'],payload)
            result=DraftStore(root/'ban_nhap').list()[0]
            self.assertEqual(result['buffer'],payload['buffer']);self.assertTrue(result['review_only'])
            self.assertEqual(Store(root/'profiles').list(),[])
            drafts.delete('editor',p['id']);self.assertEqual(drafts.list(),[])
    def test_backup_has_old_profile_and_own_progress(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);store=Store(root/'profiles');p=default_profile();store.save(p)
            task=plan(p,7)[0];progress={key(task):{'write':'saved'},'another|teacher':{'write':'saved'}}
            atomic_json(root/'tien_do_profiles.json',progress)
            changed=copy.deepcopy(p);changed['name']='Tên mới';store.save(changed)
            files=list((root/'sao_luu').glob('*.zip'));self.assertEqual(len(files),1)
            previous,saved=store.read_package(files[0]);self.assertEqual(previous['name'],p['name']);self.assertEqual(set(saved),{key(task)})
            store.save(previous);self.assertEqual(store.list()[0]['name'],p['name'])
    def test_preflight_blocks_ambiguous_and_missing_ppct(self):
        with tempfile.TemporaryDirectory() as d:
            p=default_profile();tasks=plan(p,7);ledger=Ledger(Path(d)/'progress.json')
            self.assertEqual(data_checks(p,tasks,ledger)[0],[])
            ledger.mark(tasks[0],'saving');self.assertTrue(data_checks(p,tasks,ledger)[0])
            ledger.mark(tasks[0],'pending');tasks[0]['valid']=False;self.assertTrue(data_checks(p,tasks,ledger)[0])
    def test_preflight_missing_phone_does_not_write(self):
        with self.assertRaisesRegex(RuntimeError,'Chưa kết nối'):device_checks(None,None,lambda s:None,[])
        fake=SimpleNamespace(app_current=lambda:{'package':'other'})
        with self.assertRaisesRegex(RuntimeError,'eNetViet'):device_checks(fake,None,lambda s:None,[])
    def test_status_labels(self):
        self.assertEqual(TEXT['saved'],'Đã xong');self.assertEqual(TEXT['pending'],'Chưa xong')
        self.assertNotEqual(COLORS['pending'],COLORS['saved'])

if __name__=='__main__':unittest.main()
