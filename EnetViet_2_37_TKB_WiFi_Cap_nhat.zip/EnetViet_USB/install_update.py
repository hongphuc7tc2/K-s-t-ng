"""Standalone installer copied to staging before the running app exits."""
import ctypes,os,shutil,subprocess,sys,time
from pathlib import Path

def wait_parent(pid):
    if os.name=='nt':
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        kernel.OpenProcess.restype=ctypes.c_void_p
        kernel.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong]
        kernel.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_ulong]
        kernel.CloseHandle.argtypes=[ctypes.c_void_p]
        handle=kernel.OpenProcess(0x00100000,False,pid)
        if handle:
            try:
                if kernel.WaitForSingleObject(handle,60000)!=0:raise RuntimeError('Phần mềm cũ chưa đóng; chưa cập nhật.')
            finally:kernel.CloseHandle(handle)
    else:
        deadline=time.monotonic()+60
        while time.monotonic()<deadline:
            try:os.kill(pid,0)
            except ProcessLookupError:return
            time.sleep(.2)
        raise RuntimeError('Phần mềm cũ chưa đóng.')

def install(root,folder):
    source=folder/'files';backup=root/'sao_luu_phien_ban'/time.strftime('%Y%m%d_%H%M%S')
    changed=[]
    try:
        for p in source.rglob('*'):
            if not p.is_file():continue
            rel=p.relative_to(source);dst=root/rel;old=backup/rel
            if dst.exists():old.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(dst,old)
            changed.append((dst,old));dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
    except Exception:
        for dst,old in reversed(changed):
            if old.exists():shutil.copy2(old,dst)
            elif dst.exists():dst.unlink()
        raise

if __name__=='__main__':
    root=Path(sys.argv[1]);folder=Path(sys.argv[2])
    try:
        wait_parent(int(sys.argv[3]));install(root,folder)
        subprocess.Popen([sys.executable,str(root/'app.py')],cwd=str(root),creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        shutil.rmtree(folder,ignore_errors=True)
    except Exception as exc:
        import tkinter as tk
        from tkinter import messagebox
        win=tk.Tk();win.withdraw();messagebox.showerror('Cập nhật thất bại',str(exc)+'\nMở lại phần mềm và thử lại.');win.destroy()
