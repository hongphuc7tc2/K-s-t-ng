from branding import credit
"""Guided teacher setup. Incomplete profiles cannot run on the phone."""
import copy
import re
import tkinter as tk
from tkinter import ttk,messagebox,filedialog
from collections import Counter
from table_sort import class_key

SUBJECTS=['Toán','Ngữ văn','Tiếng Anh','Khoa học tự nhiên','Lịch sử và Địa lí','Tin học','Công nghệ','Giáo dục công dân','Giáo dục thể chất','Âm nhạc','Mĩ thuật','HĐTN']
TYPES={'hdtn':'HĐTN','integrated':'Tích hợp','extra':'Tăng tiết'}

def parse_classes(text):
    return sorted(set(x.strip().upper() for x in re.split(r'[,;\n]+',text) if x.strip()),key=class_key)

def setup_profile(base,name,subject,classes,options):
    if not name.strip() or not subject.strip() or not classes:raise ValueError('Điền tên giáo viên, môn dạy và ít nhất một lớp.')
    if any(not set(items)<=set(classes) for items in options.values()):raise ValueError('Lớp được chọn phải có trong danh sách lớp dạy.')
    p=copy.deepcopy(base);p.update(name=name.strip(),subject=subject.strip(),declared_classes=list(classes),teaching_options=copy.deepcopy(options),integrated_classes=list(options['integrated']))
    return p

def setup_note(p):
    options=p.get('teaching_options',{})
    if not options:return ''
    lines=['Các lựa chọn đã xác nhận của giáo viên:', 'Môn chính: '+p['subject'], 'Lớp dạy: '+', '.join(p['declared_classes'])]
    for key,title in TYPES.items():lines.append(title+': '+(', '.join(options.get(key,[])) or 'Không dạy'))
    lines+=['Chỉ phân tích các lớp đã khai báo. Tích hợp và tăng tiết là hai lựa chọn độc lập, không tự thêm TT khi chỉ chọn tích hợp.',
            'Nếu có HĐTN: PPCT 3 tiết/tuần nhưng chỉ lấy hai tiết sau (tuần 1: 2–3, tuần 2: 5–6). Mỗi lớp/môn có bộ đếm riêng.',
            'Giữ declared_classes, teaching_options và integrated_classes như lựa chọn này. TKB chưa rõ tuần áp dụng thì yêu cầu làm rõ, không tự đoán.']
    return '\n'.join(lines)

def profile_names(profiles):
    counts=Counter(p['name'] for p in profiles)
    return [p['name'] if counts[p['name']]==1 else p['name']+' — '+p.get('subject','')+' — '+p['id'][:4] for p in profiles]

class ProfileWizard(tk.Toplevel):
    def __init__(self,parent,on_ready,base=None,resume=None):
        from profile_ui import empty_profile
        super().__init__(parent);self.title('Tạo hồ sơ giáo viên');self.geometry('820x680');self.transient(parent)
        self.is_new=base is None;self.previous=parent.grab_current();self.grab_set();self.on_ready=on_ready;self.base=copy.deepcopy(base or empty_profile());self.step=0
        self.name=tk.StringVar(value=self.base.get('name',''));self.subject=tk.StringVar(value=self.base.get('subject','Toán'))
        self.classes=list(self.base.get('declared_classes',sorted({r['classroom'] for rev in self.base.get('schedules',[]) for r in rev['rows']},key=class_key)))
        inferred={k:[] for k in TYPES}
        for rev in self.base.get('schedules',[]):
            for r in rev['rows']:
                c=self.base['courses'][r['course']]
                kind='hdtn' if c.get('subject',self.base.get('subject'))=='HĐTN' else 'integrated' if c['kind']=='Tích hợp' else 'extra' if c['kind']=='TT' else None
                if kind and r['classroom'] not in inferred[kind]:inferred[kind].append(r['classroom'])
        self.chosen=copy.deepcopy(self.base.get('teaching_options',inferred))
        self.enabled={k:tk.BooleanVar(value=bool(self.chosen.get(k))) for k in TYPES}
        credit(self)
        self.body=ttk.Frame(self,padding=22);self.body.pack(fill='both',expand=True)
        from drafts import DraftStore
        self._drafts=DraftStore()
        if resume:
            self.name.set(resume.get('name',''));self.subject.set(resume.get('subject','Toán'))
            self.classes=resume.get('classes',[]);self.chosen=resume.get('chosen',self.chosen);self.step=resume.get('step',0);self.is_new=resume.get('is_new',True)
            for k,v in self.enabled.items():v.set(resume.get('enabled',{}).get(k,False))
        self.protocol('WM_DELETE_WINDOW',self.cancel);self.show();self.after(3000,self.auto_draft)
    def save_draft(self,notice=False):
        classes=parse_classes(self.class_text.get('1.0','end')) if self.step==0 else self.classes
        try:
            self._drafts.save('wizard',self.base['id'],dict(base=self.base,name=self.name.get(),subject=self.subject.get(),classes=classes,chosen=self.chosen,enabled={k:v.get() for k,v in self.enabled.items()},step=self.step,is_new=self.is_new))
            if notice:messagebox.showinfo('Đã lưu nháp','Có thể đóng cửa sổ và bấm Tiếp tục bản nháp khi mở lại.',parent=self)
            return True
        except Exception as e:
            if notice:messagebox.showerror('Không lưu được nháp',str(e),parent=self)
            return False
    def auto_draft(self):
        if self.winfo_exists():self.save_draft();self.after(3000,self.auto_draft)
    def cancel(self):
        if not self.save_draft(notice=False):
            if not messagebox.askyesno('Chưa lưu được nháp','Không lưu được bản nháp. Vẫn đóng và bỏ các thay đổi chưa lưu?',parent=self):return False
        self.destroy()
        if self.previous and self.previous.winfo_exists():self.previous.grab_set()
    def show(self):
        for w in self.body.winfo_children():w.destroy()
        ttk.Label(self.body,text=['Bước 1/3 — Giáo viên và lớp dạy','Bước 2/3 — Các nội dung có giảng dạy','Bước 3/3 — Kiểm tra thông tin'][self.step],font=('Segoe UI',17,'bold')).pack(anchor='w',pady=(0,18))
        if self.step==0:
            for title,var in [('Tên giáo viên',self.name),('Môn dạy chính',self.subject)]:
                ttk.Label(self.body,text=title).pack(anchor='w',pady=(8,4))
                widget=ttk.Combobox(self.body,textvariable=var,values=SUBJECTS,width=45) if var is self.subject else ttk.Entry(self.body,textvariable=var,width=48)
                widget.pack(fill='x',ipady=5)
            ttk.Label(self.body,text='Các lớp dạy (ví dụ: 6A1, 6A8, 6A11, 7A2)').pack(anchor='w',pady=(18,4))
            self.class_text=tk.Text(self.body,height=4,font=('Segoe UI',12));self.class_text.pack(fill='x');self.class_text.insert('1.0',', '.join(self.classes))
            ttk.Label(self.body,text='Ngăn cách các lớp bằng dấu phẩy hoặc xuống dòng.\nNhập cả các lớp chỉ dạy HĐTN, tích hợp hoặc tăng tiết.').pack(anchor='w',pady=8)
        elif self.step==1:
            ttk.Label(self.body,text='Chọn Có nếu giảng dạy, rồi chọn từng lớp trong danh sách xổ xuống.').pack(anchor='w')
            for key,title in TYPES.items():
                frame=ttk.LabelFrame(self.body,text='Có dạy '+title+' không?',padding=10);frame.pack(fill='x',pady=8)
                line=ttk.Frame(frame);line.pack(fill='x')
                for text,value in [('Không',False),('Có',True)]:ttk.Radiobutton(line,text=text,variable=self.enabled[key],value=value,command=self.show).pack(side='left',padx=8)
                if self.enabled[key].get():
                    selected=tk.StringVar();box=ttk.Combobox(line,textvariable=selected,values=self.classes,state='readonly',width=18);box.pack(side='left',padx=12)
                    box.set('Chọn lớp…')
                    def add(event,k=key,v=selected):
                        value=v.get()
                        if value in self.classes and value not in self.chosen[k]:self.chosen[k].append(value)
                        self.show()
                    box.bind('<<ComboboxSelected>>',add)
                    labels=ttk.Frame(frame);labels.pack(fill='x',pady=(8,0))
                    for i,cls in enumerate(self.chosen[key]):
                        def remove(k=key,c=cls):self.chosen[k].remove(c);self.show()
                        ttk.Button(labels,text=cls+' ×',command=remove).grid(row=i//6,column=i%6,padx=3,pady=2)
                    if not self.chosen[key]:ttk.Label(labels,text='Chưa chọn lớp.').pack(anchor='w')
        else:
            p=self.build();ttk.Label(self.body,text='Giáo viên: '+p['name'],font=('Segoe UI',13,'bold')).pack(anchor='w',pady=8)
            ttk.Label(self.body,text='Môn chính: '+p['subject']).pack(anchor='w',pady=5)
            ttk.Label(self.body,text='Lớp dạy: '+', '.join(p['declared_classes']),wraplength=740).pack(anchor='w',pady=5)
            for k,title in TYPES.items():ttk.Label(self.body,text=title+': '+(', '.join(p['teaching_options'][k]) or 'Không dạy'),wraplength=740).pack(anchor='w',pady=7)
            ttk.Label(self.body,text='Tiếp theo: tải TKB và các PPCT tương ứng, phân tích và kiểm tra.\nProfile chỉ được lưu sau khi lịch và PPCT đã đầy đủ.',wraplength=740).pack(anchor='w',pady=22)
        bar=ttk.Frame(self.body);bar.pack(side='bottom',fill='x',pady=16)
        ttk.Button(bar,text='Lưu nháp và đóng',command=self.cancel).pack(side='left')
        if self.step:ttk.Button(bar,text='← Quay lại',command=self.back).pack(side='left',padx=10)
        ttk.Button(bar,text='Tiếp tục →' if self.step<2 else 'Tiếp tục: Tải TKB và PPCT →',command=self.next,style='Primary.TButton').pack(side='right')
    def build(self):
        return setup_profile(self.base,self.name.get(),self.subject.get(),self.classes,{k:list(self.chosen[k]) if self.enabled[k].get() else [] for k in TYPES})
    def next(self):
        if self.step==0:
            self.classes=parse_classes(self.class_text.get('1.0','end'))
            for k in TYPES:self.chosen[k]=[c for c in self.chosen[k] if c in self.classes]
        try:
            self.build()
            if self.step==1:
                for k in TYPES:
                    if self.enabled[k].get() and not self.chosen[k]:raise ValueError('Chọn ít nhất một lớp cho '+TYPES[k]+', hoặc chọn Không.')
        except ValueError as e:messagebox.showinfo('Cần bổ sung',str(e),parent=self);return
        if self.step<2:self.step+=1;self.show()
        else:
            p=self.build()
            if self.is_new:
                from ai_settings import configure
                configure(self,'Gemini',allow_skip=True)
            if self.cancel() is False:return
            self.on_ready(p)
            if hasattr(self,'_drafts'):self._drafts.delete('wizard',self.base['id'])
    def back(self):self.step-=1;self.show()


def select_teacher(root,store):
    """Shown before the main interface, including on a fresh installation."""
    from profile_ui import ProfileEditor
    win=tk.Toplevel(root);win.title('Chọn giáo viên');win.geometry('680x590');win.grab_set();result=[];profiles=[]
    credit(win)
    frame=ttk.Frame(win,padding=28);frame.pack(fill='both',expand=True)
    ttk.Label(frame,text='CHỌN GIÁO VIÊN',font=('Segoe UI',20,'bold')).pack(anchor='w',pady=(0,20))
    ttk.Label(frame,text='Thầy/cô chọn tên của mình để bắt đầu.').pack(anchor='w',pady=8)
    box=ttk.Combobox(frame,state='readonly',width=45,font=('Segoe UI',13));box.pack(fill='x',ipady=6)
    def refresh(selected=None):
        profiles[:]=store.list();box['values']=profile_names(profiles)
        if profiles:box.current(next((i for i,p in enumerate(profiles) if p['id']==selected),0))
        else:box.set('Chưa có giáo viên — hãy tạo hồ sơ')
    def ready(p,progress=None):
        def saved(p):
            store.save(p);refresh(p['id'])
            if progress and messagebox.askyesno('Tiến độ đi kèm','Nhập tiến độ ghi sổ đi kèm hồ sơ? Chọn Có nếu đây là bản mới nhất.',parent=win):
                from profiles import Ledger,atomic_json
                ledger=Ledger(store.root.parent/'tien_do_profiles.json');ledger.data.update(progress);atomic_json(ledger.path,ledger.data)
        editor=ProfileEditor(win,p,saved,'Tải TKB và PPCT');editor.grab_set();win.wait_window(editor)
        if win.winfo_exists():win.grab_set()
    def create():
        wizard=ProfileWizard(win,ready);win.wait_window(wizard)
    ttk.Button(frame,text='＋ Tạo hồ sơ giáo viên mới',command=create).pack(fill='x',pady=16)
    def import_profile():
        path=filedialog.askopenfilename(parent=win,filetypes=[('Hồ sơ giáo viên','*.zip *.json')])
        if not path:return
        try:
            p,progress=store.read_package(path)
            if any(x['id']==p['id'] for x in profiles) and not messagebox.askyesno('Thay hồ sơ','Hồ sơ đã có. Thay bằng hồ sơ vừa nhập?',parent=win):return
            ready(p,progress)
        except Exception as e:messagebox.showerror('Không nhập được',str(e),parent=win)
    ttk.Button(frame,text='Nhập hồ sơ đã có',command=import_profile).pack(fill='x')
    def resume_work():
        from drafts import resume_draft
        def saved(p):store.save(p);refresh(p['id'])
        resume_draft(win,saved)
    ttk.Button(frame,text='Tiếp tục bản nháp',command=resume_work).pack(fill='x',pady=5)
    actions=ttk.Frame(frame);actions.pack(fill='x',pady=8)
    def edit_existing():
        i=box.current()
        if 0<=i<len(profiles):ready(profiles[i])
    def delete_existing():
        i=box.current()
        if not 0<=i<len(profiles):return
        p=profiles[i]
        if not messagebox.askyesno('Xóa hồ sơ','Xóa hồ sơ '+p['name']+' khỏi danh sách? Bản sao giữ trong profiles/_da_xoa; không xóa sổ trên điện thoại.',parent=win):return
        try:store.delete(p['id']);refresh()
        except Exception as e:messagebox.showerror('Không xóa được',str(e),parent=win)
    ttk.Button(actions,text='Sửa hồ sơ đã chọn',command=edit_existing).pack(side='left',padx=4)
    ttk.Button(actions,text='Xóa hồ sơ đã chọn',command=delete_existing).pack(side='left',padx=4)
    def proceed():
        if not profiles:return
        i=box.current()
        if i>=0:result.append(profiles[i]['id']);win.destroy()
    ttk.Button(frame,text='Vào phần mềm →',command=proceed,style='Primary.TButton').pack(fill='x',pady=20)
    refresh();root.wait_window(win)
    return result[0] if result else None
