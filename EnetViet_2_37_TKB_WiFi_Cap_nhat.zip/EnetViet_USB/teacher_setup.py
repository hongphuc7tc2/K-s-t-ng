import copy

def preserve_setup(original,result):
    for k in ('declared_classes','teaching_options','integrated_classes'):
        if k in original and 'teaching_options' in original:result[k]=copy.deepcopy(original[k])
    return result

def validate_setup(p):
    options=p.get('teaching_options')
    if options is None:return
    classes=p.get('declared_classes',[])
    if not isinstance(classes,list) or not classes or any(not isinstance(c,str) or not c.strip() for c in classes):raise ValueError('Danh sách lớp dạy không hợp lệ.')
    if not isinstance(options,dict) or set(options)!={'hdtn','integrated','extra'}:raise ValueError('Thiếu lựa chọn HĐTN, tích hợp hoặc tăng tiết.')
    for items in options.values():
        if not isinstance(items,list) or any(c not in classes for c in items):raise ValueError('Lớp đặc biệt không có trong danh sách lớp dạy.')
    if set(p.get('integrated_classes',[]))!=set(options['integrated']):raise ValueError('Các lớp tích hợp không khớp lựa chọn ban đầu.')
    rows=[r for rev in p.get('schedules',[]) for r in rev['rows']]
    if any(r['classroom'] not in classes for r in rows):raise ValueError('TKB có lớp ngoài danh sách giáo viên đã khai báo.')
    actual={k:set() for k in options}
    for r in rows:
        c=p['courses'][r['course']]
        if c.get('subject',p['subject'])=='HĐTN':
            actual['hdtn'].add(r['classroom'])
            if c.get('weekly_stride')!=3 or c.get('taught_offsets')!=[2,3]:raise ValueError('HĐTN cần quy tắc chỉ dạy hai tiết sau của mỗi tuần.')
        if c['kind']=='Tích hợp':actual['integrated'].add(r['classroom'])
        if c['kind']=='TT':actual['extra'].add(r['classroom'])
    for k in options:
        if actual[k]!=set(options[k]):raise ValueError('TKB/PPCT chưa khớp các lớp '+{'hdtn':'HĐTN','integrated':'tích hợp','extra':'tăng tiết'}[k]+' đã chọn. Kiểm tra lại tài liệu và kết quả phân tích.')


def teaching_overview(p):
    if 'teaching_options' in p:return copy.deepcopy(p['teaching_options'])
    result={'hdtn':[],'integrated':list(p.get('integrated_classes',[])),'extra':[]}
    for rev in p.get('schedules',[]):
        for r in rev['rows']:
            c=p.get('courses',{}).get(r['course'],{})
            keys=[]
            if c.get('subject',p.get('subject'))=='HĐTN':keys.append('hdtn')
            if c.get('kind')=='Tích hợp':keys.append('integrated')
            if c.get('kind')=='TT':keys.append('extra')
            for k in keys:
                if r['classroom'] not in result[k]:result[k].append(r['classroom'])
    return result
