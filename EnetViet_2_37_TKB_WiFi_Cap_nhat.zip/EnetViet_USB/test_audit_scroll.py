import unittest
from test_borrow import fixture
from audit import BorrowAudit
from borrow import one

class AuditScrollTests(unittest.TestCase):
    def reader(self,scrollable=False):
        nav=BorrowAudit.__new__(BorrowAudit);ns=fixture('main')
        one(ns,'rvData').set('scrollable',str(scrollable).lower())
        nav.nodes=lambda:ns;nav.calls=[]
        nav.swipe_region=lambda *args:nav.calls.append('scroll')
        nav.open_card=lambda name:nav.calls.append('edit') or fixture('form')
        return nav
    def test_fitting_list_does_not_scroll(self):
        n=self.reader()
        for name in n.all_cards():n.open_audit_card(name)
        self.assertEqual(n.calls,['edit'])
    def test_visible_card_opened_before_scanning_long_list(self):
        n=self.reader(True);cards=n.all_cards()
        n.open_audit_card(next(cards))
        self.assertEqual(n.calls,['edit'])
        self.assertEqual(list(cards),[])
        self.assertIn('scroll',n.calls)
    def test_empty_fitting_list_does_not_scroll(self):
        n=self.reader();n.titles=lambda ns:[]
        self.assertEqual(list(n.all_cards()),[]);self.assertEqual(n.calls,[])
    def test_discovery_error_is_reported(self):
        n=self.reader();n.check=lambda:None
        def fail():raise RuntimeError('Không đọc được danh sách')
        n.all_cards=fail;rows=[]
        self.assertEqual(list(n.safe_cards(2,rows)),[])
        self.assertIn('Chưa rà soát hết phiếu',rows[0][1][0])

if __name__=='__main__':unittest.main()
