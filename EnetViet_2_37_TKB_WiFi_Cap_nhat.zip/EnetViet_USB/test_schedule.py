import tempfile
import unittest
from pathlib import Path
from collections import Counter
from schedule import make_plan, Progress, task_key
from engine import same_class, normalized, FormAssistant

class ScheduleTests(unittest.TestCase):
    def test_week_seven(self):
        tasks=make_plan(7)
        self.assertEqual(Counter(t['classroom'] for t in tasks),{'6A8':4,'6A1':4,'7A2':4,'6A11':3})
        self.assertEqual([(t['day'],t['session'],t['slot'],t['period']) for t in tasks if t['classroom']=='6A11'],[(2,'Chiều',1,13),(4,'Chiều',4,7),(6,'Sáng',3,14)])
        for cls in ('6A8','6A1','7A2'):
            self.assertEqual([t['period'] for t in tasks if t['classroom']==cls],[25,26,27,28])
        self.assertFalse(any(t['classroom']=='6A1' and t['day']==2 for t in tasks))
    def test_whole_year(self):
        for week in range(1,36):
            tasks=make_plan(week)
            self.assertEqual(len(set(task_key(t) for t in tasks)),15)
            self.assertEqual([t['period'] for t in tasks if t['kind']=='TT'],[week])
            self.assertTrue(all(t['expected_title'] for t in tasks if t['classroom']=='6A11'))
    def test_save_status_survives_restart_and_ppct_change(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'progress.json'; task=make_plan(7)[0]
            p=Progress(path); p.mark(task,'saving')
            self.assertEqual(Progress(path).state(task),'saving')
            p.mark(task,'saved'); task['period']=99
            self.assertEqual(Progress(path).state(task),'saved')
    def test_aliases(self):
        self.assertTrue(same_class('6A1 (CS2)','6A1'))
        self.assertFalse(same_class('6A11','6A1'))
    def test_callback_marks_saved_before_close_failure(self):
        import xml.etree.ElementTree as E
        states=[]
        runner=object.__new__(FormAssistant)
        runner.field=lambda *a:None; runner.log=lambda *a:None
        runner.exact=lambda *a:object(); runner.check=lambda:None; runner.click=lambda *a:None
        runner.before_save=lambda:states.append('saving'); runner.on_saved=lambda:states.append('saved')
        runner.wait_nodes=lambda *a,**kw:[E.Element('node',text='Bạn đã ghi sổ đầu bài thành công')]
        def fail(): raise RuntimeError('close failed')
        runner.close_success=fail
        with self.assertRaises(RuntimeError): runner.score_and_save()
        self.assertEqual(states,['saving','saved'])

if __name__=='__main__': unittest.main()
