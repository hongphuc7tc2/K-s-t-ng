from table_sort import TimetableSort
from timetable import DAYS, SESSIONS, active_revision, change_range
from ai_settings import credentials, configure
from input_help import attach, hint, HINTS
"""Dedicated HDTN setup: AI reads PPCT, deterministic code owns schedule merge."""
import copy
import json
import queue
import threading
import uuid
from pathlib import Path
import tkinter as tk
from tkinter import ttk,filedialog,messagebox,simpledialog
from profiles import validate,plan
from analyzer import analyze,export_request


def hdtn_draft(base,rows,from_week,anchor_week,start_period):
    if not rows:raise ValueError('Thêm ít nhất một lớp và hai tiết HĐTN của lớp đó.')
    if not 1<=from_week<=53 or not 1<=anchor_week<=53 or start_period<1:raise ValueError('Tuần/mốc PPCT không hợp lệ.')
    p={k:copy.deepcopy(base[k]) for k in ('schema','id','name','school_year')}
    p.update(subject='HĐTN',integrated_classes=[],sources=[],reviewed=False,courses={'hdtn':{'name':'PPCT HĐTN','subject':'HĐTN','kind':'Thường','teaching_type':'Lên lớp','exact_title':True,'weekly_stride':3,'taught_offsets':[2,3],'periods':{}}})
    p['schedules']=[{'from_week':from_week,'rows':[dict(r,course='hdtn',anchor_week=anchor_week,start_period=start_period) for r in rows]}]
    return p


def merge_hdtn(base,draft,result):
    # Never use AI-written timetable or let AI mutate the teacher's other subjects.
    validate(result)
    if len(result['courses'])!=1:raise ValueError('Kết quả phải có đúng một PPCT HĐTN. Mỗi lần thêm các lớp dùng chung một PPCT.')
    course=copy.deepcopy(next(iter(result['courses'].values())))
    course.update(subject='HĐTN',kind='Thường',weekly_stride=3,taught_offsets=[2,3])
    p=copy.deepcopy(base);rev=copy.deepcopy(draft['schedules'][0]);week=rev['from_week']
    original=active_revision(p['schedules'],week)
    if original is None:
        earliest=min(p['schedules'],key=lambda r:r['from_week'])
        if 'to_week' not in earliest and week<earliest['from_week']:original=earliest
        else:raise ValueError('Chưa có TKB cho tuần này. Thêm TKB trước khi thêm HĐTN.')
    classes={r['classroom'] for r in rev['rows']}
    rows=[copy.deepcopy(r) for r in original['rows'] if not (r['classroom'] in classes and p['courses'][r['course']].get('subject',p['subject'])=='HĐTN')]
    code='hdtn_'+uuid.uuid4().hex[:10];p['courses'][code]=course
    rows += [dict(r,course=code) for r in rev['rows']]
    p['schedules']=change_range(p['schedules'],week,week,original.get('to_week'),rows)
    p['reviewed']=False
    p['analysis_notes']=str(result.get('analysis_notes',''))
    # Discard no unrelated courses, source descriptions, or progress.
    p.setdefault('sources',[]).extend(draft.get('sources',[]))
    if 'teaching_options' in p:
        p['declared_classes']=sorted(set(p['declared_classes'])|classes)
        p['teaching_options']['hdtn']=sorted(set(p['teaching_options']['hdtn'])|classes)
    validate(p)
    tasks=[t for t in plan(p,week) if t['course']==code]
    if any(not t['valid'] for t in tasks):raise ValueError('PPCT chưa có đủ bài cho tuần áp dụng. Kiểm tra tuần mốc hoặc file PPCT.')
    return p


class HdtnWizard(tk.Toplevel):
    def __init__(self,parent,profile,on_save):
        super().__init__(parent);self.title('Thêm môn HĐTN');self.geometry('1020x740');self.transient(parent)
        self.base=copy.deepcopy(profile);self.on_save=on_save;self.rows=[];self.files=[];self.running=False;self.results=queue.Queue();self.merged=None;self.snapshot=None
        from branding import credit
        credit(self)
        wrap=ttk.Frame(self,padding=14);wrap.pack(fill='both',expand=True)
        ttk.Label(wrap,text='THÊM MÔN HĐTN',font=('Segoe UI',17,'bold')).pack(anchor='w')
        ttk.Label(wrap,text='PPCT 3 tiết/tuần • GV dạy hai tiết sau: tuần 1 lấy 2–3, tuần 2 lấy 5–6.\nMỗi lần thêm các lớp dùng chung một file/danh mục PPCT. Các môn khác được giữ nguyên.').pack(anchor='w',pady=6)
        row=ttk.Frame(wrap);row.pack(fill='x',pady=4)
        self.from_week=tk.StringVar(value=str(min(r['from_week'] for r in profile['schedules'])));self.anchor=tk.StringVar(value='1');self.start=tk.StringVar(value='2')
        for text,var in [('TKB áp dụng từ tuần',self.from_week),('Tuần mốc',self.anchor),('PPCT đầu GV dạy',self.start)]:
            ttk.Label(row,text=text).pack(side='left',padx=4);ttk.Spinbox(row,from_=1,to=999 if var is self.start else 53,textvariable=var,width=6).pack(side='left')
        for var in (self.from_week,self.anchor,self.start):var.trace_add('write',lambda *a:self.invalidate())
        self.table=ttk.Treeview(wrap,columns=('class','day','session','slot'),show='headings',height=7)
        for k,title in [('class','Lớp'),('day','Thứ'),('session','Buổi'),('slot','Tiết TKB')]:self.table.heading(k,text=title);self.table.column(k,width=200)
        self.sorter=TimetableSort(self.table,lambda:{str(i):r for i,r in enumerate(self.rows)},class_column='class')
        self.table.pack(fill='x',pady=8)
        ttk.Label(wrap,text='Bấm Thứ ⇅ để xếp theo thời gian; Lớp ⇅ để nhóm theo lớp. ▲ là cách xếp đang chọn.').pack(anchor='w')
        row=ttk.Frame(wrap);row.pack(fill='x')
        ttk.Button(row,text='Chọn lớp và hai tiết HĐTN',command=self.edit_class).pack(side='left')
        ttk.Button(row,text='Bỏ lớp được chọn',command=self.remove_class).pack(side='left',padx=8)
        self.table.bind('<Double-1>',lambda e:self.edit_class() if self.table.identify_region(e.x,e.y)=='cell' else None)
        row=ttk.Frame(wrap);row.pack(fill='x',pady=8)
        ttk.Button(row,text='Tải PPCT HĐTN',command=self.add_files).pack(side='left')
        self.file_label=tk.StringVar(value='Chưa chọn file');ttk.Label(row,textvariable=self.file_label,wraplength=780).pack(side='left',padx=8)
        row=ttk.Frame(wrap);row.pack(fill='x')
        self.provider=tk.StringVar(value='Gemini');ttk.Combobox(row,textvariable=self.provider,values=['Gemini','OpenAI'],state='readonly',width=12).pack(side='left')
        ttk.Button(row,text='Cài đặt AI',command=lambda:configure(self,self.provider.get()) if not self.running else None).pack(side='left',padx=4)
        ttk.Button(row,text='Phân tích PPCT',command=self.ai).pack(side='left',padx=5)
        ttk.Button(row,text='Xuất hồ sơ gửi ChatGPT',command=self.export).pack(side='left')
        ttk.Button(row,text='Nhập kết quả phân tích',command=self.import_result).pack(side='left',padx=5)
        self.msg=tk.StringVar(value='Chọn lớp, lịch dạy và file PPCT. Phần mềm tự tạo lệnh phân tích; không cần ghi chú.')
        ttk.Label(wrap,textvariable=self.msg,wraplength=970).pack(anchor='w',pady=8)
        self.preview=tk.Text(wrap,height=10,wrap='word',state='disabled');self.preview.pack(fill='both',expand=True)
        self.reviewed=tk.BooleanVar(value=False)
        ttk.Checkbutton(wrap,text='Tôi đã kiểm tra lịch HĐTN và tên bài trong bảng xem trước',variable=self.reviewed).pack(anchor='w',pady=6)
        ttk.Button(wrap,text='Lưu HĐTN vào hồ sơ',command=self.save).pack(anchor='e')
        from widgets import add_tooltips
        add_tooltips(self)
        attach(self,[(self.provider,'provider'),(self.reviewed,'reviewed')])
        self.protocol('WM_DELETE_WINDOW',self.close);self.after(150,self.poll);self.grab_set()
    def invalidate(self):
        self.merged=None
        if hasattr(self,'reviewed'):self.reviewed.set(False)
    def redraw(self):
        self.table.delete(*self.table.get_children())
        for i,r in enumerate(self.rows):self.table.insert('','end',iid=str(i),values=(r['classroom'],DAYS[r['day']],SESSIONS[r['session']],r['slot']))
        self.sorter.apply()
        self.invalidate()
    def edit_class(self):
        if self.running:return
        selected=self.table.selection();old=self.rows[int(selected[0])]['classroom'] if selected else None
        win=tk.Toplevel(self);win.title('Chọn lớp và lịch HĐTN');win.transient(self);win.grab_set()
        cls=tk.StringVar(value=old or '')
        classes=sorted({r['classroom'] for rev in self.base['schedules'] for r in rev['rows']})
        ttk.Label(win,text='Lớp (chọn hoặc nhập lớp mới):').pack(anchor='w',padx=12,pady=6)
        ttk.Combobox(win,textvariable=cls,values=classes,width=22).pack(anchor='w',padx=12)
        existing=[r for r in self.rows if r['classroom']==old] if old else []
        controls=[]
        for i in range(2):
            r=existing[i] if len(existing)==2 else dict(day=2,session='Sáng' if i==0 else 'Chiều',slot=2 if i==0 else 3)
            row=ttk.Frame(win,padding=10);row.pack(fill='x');ttk.Label(row,text='Ô HĐTN '+str(i+1)).pack(side='left')
            variables=[]
            for k,values in [('day',list(DAYS.values())),('session',list(SESSIONS.values())),('slot',list(range(1,6)))]:
                var=tk.StringVar(value=DAYS[r[k]] if k=='day' else SESSIONS[r[k]] if k=='session' else str(r[k]));box=ttk.Combobox(row,textvariable=var,values=values,state='readonly',width=13);box.pack(side='left',padx=4);variables.append(var)
            controls.append(variables)
        ttk.Label(win,text='Chọn vị trí thật trên TKB; phần mềm tự xếp hai ô theo thời gian.').pack(padx=12,pady=6)
        def apply():
            name=cls.get().strip()
            if not name:return
            new=[dict(classroom=name,day=next(k for k,x in DAYS.items() if x==v[0].get()),session=next(k for k,x in SESSIONS.items() if x==v[1].get()),slot=int(v[2].get())) for v in controls]
            if len({(r['day'],r['session'],r['slot']) for r in new})!=2:messagebox.showerror('Lịch','Hai tiết không được trùng giờ.',parent=win);return
            self.rows=[r for r in self.rows if r['classroom'] not in (old,name)]+new;self.rows.sort(key=lambda r:(r['day'],r['session']=='Chiều',r['slot']))
            self.redraw();win.destroy()
        ttk.Button(win,text='Áp dụng lịch lớp',command=apply).pack(pady=10)
        self.wait_window(win);self.grab_set()
    def remove_class(self):
        if self.running:return
        selected=self.table.selection()
        if selected:
            cls=self.rows[int(selected[0])]['classroom'];self.rows=[r for r in self.rows if r['classroom']!=cls];self.redraw()
    def add_files(self):
        if self.running:return
        files=filedialog.askopenfilenames(parent=self,title='Chọn PPCT HĐTN',filetypes=[('PPCT','*.xlsx *.xls *.pdf *.docx *.png *.jpg *.jpeg *.webp *.csv *.txt *.json')])
        if files:self.files=list(files);self.file_label.set(', '.join(Path(f).name for f in files));self.invalidate()
    def prepare(self,require_files=True):
        if require_files and not self.files:raise ValueError('Bấm Tải PPCT HĐTN và chọn file trước.')
        draft=hdtn_draft(self.base,self.rows,int(self.from_week.get()),int(self.anchor.get()),int(self.start.get()))
        draft['sources']=[{'role':'PPCT HĐTN','name':Path(f).name} for f in self.files]
        # Check collisions before any paid request, using a temporary nonempty catalog.
        check=copy.deepcopy(draft);check['courses']['hdtn']['periods']={str(n):'Kiểm tra cấu trúc' for n in range(1,1000)}
        merge_hdtn(self.base,draft,check)
        note='Chỉ trích xuất đầy đủ số PPCT và tên bài từ các file HĐTN thành đúng một course hdtn. Giữ nguyên các lớp, ô TKB, tuần áp dụng và mốc đã chọn trong mẫu. Mẫu đã xác định lịch và quy tắc; không cần file TKB khác. Không dùng tên bài kiểm tra cấu trúc; phải đọc tên thật từ file. Không thay đổi môn khác. subject=HĐTN; weekly_stride=3; taught_offsets=[2,3].'
        return draft,note
    def ai(self):
        if self.running:return
        try:draft,note=self.prepare()
        except Exception as e:messagebox.showerror('HĐTN',str(e),parent=self);return
        provider=self.provider.get()
        saved=credentials(self,provider)
        if not saved:return
        model,secret=saved
        if not messagebox.askokcancel('Phân tích PPCT',f'Gửi {len(self.files)} tệp PPCT và lịch HĐTN đã chọn tới {provider}? Có thể phát sinh phí API.',parent=self):return
        self.snapshot=draft;files=list(self.files);self.running=True;self.invalidate();self.msg.set('Đang phân tích PPCT HĐTN…')
        def worker():
            try:self.results.put(('ok',analyze(draft,note,files,secret,model,provider)))
            except Exception as e:self.results.put(('error',str(e)))
        threading.Thread(target=worker,daemon=True).start()
    def poll(self):
        try:
            kind,result=self.results.get_nowait();self.running=False
            if kind=='ok':
                try:self.accept(result,self.snapshot)
                except Exception as e:self.msg.set(str(e))
            else:self.msg.set(result)
        except queue.Empty:pass
        self.after(150,self.poll)
    def accept(self,result,draft):
        # Reject stale form edits while the API was running.
        current,_=self.prepare(False)
        if current['schedules']!=draft['schedules']:raise ValueError('Lịch/mốc đã đổi trong lúc phân tích. Phân tích lại với lịch hiện tại.')
        candidate=merge_hdtn(self.base,draft,result)
        def approved(merged):
            self.merged=copy.deepcopy(merged);self.reviewed.set(True)
            lines=[]
            for w in range(draft['schedules'][0]['from_week'],min(53,draft['schedules'][0]['from_week']+2)+1):
                try:tasks=plan(self.merged,w)
                except ValueError:continue
                for t in tasks:
                    if t['subject']=='HĐTN':lines.append(f"Tuần {w} | {t['classroom']} | {DAYS[t['day']]} {SESSIONS[t['session']]} tiết {t['slot']} | PPCT {t['period']} | {t['title']}")
            self.preview.configure(state='normal');self.preview.delete('1.0','end');self.preview.insert('1.0','\n'.join(lines));self.preview.configure(state='disabled')
            self.msg.set('Đã đồng ý bảng đối chiếu. Bấm Lưu HĐTN vào hồ sơ để lưu.')
        from profile_ui import ProfileEditor
        editor=ProfileEditor(self,candidate,approved,'Đối chiếu HĐTN',review_only=True)
        editor.grab_set();self.wait_window(editor)
        if self.winfo_exists():self.grab_set()
    def export(self):
        if self.running:return
        try:
            p,n=self.prepare();target=filedialog.asksaveasfilename(parent=self,defaultextension='.zip',initialfile='Ho_so_HDTN.zip')
            if target:export_request(p,n,self.files,target);self.msg.set('Gửi ZIP này cho ChatGPT, rồi nhập profile.json được trả lại tại đây.')
        except Exception as e:messagebox.showerror('HĐTN',str(e),parent=self)
    def import_result(self):
        if self.running:return
        path=filedialog.askopenfilename(parent=self,filetypes=[('Kết quả','*.json')])
        if not path:return
        try:
            draft,_=self.prepare(False);self.accept(json.loads(Path(path).read_text(encoding='utf-8-sig')),draft)
        except Exception as e:messagebox.showerror('HĐTN',str(e),parent=self)
    def save(self):
        if self.running:return
        if self.merged is None or not self.reviewed.get():messagebox.showinfo('Kiểm tra','Phân tích/nhập PPCT và kiểm tra bảng xem trước trước khi lưu.',parent=self);return
        self.merged['reviewed']=True;self.on_save(self.merged);self.destroy()
    def close(self):
        if self.running:messagebox.showinfo('Đang phân tích','Chờ kết quả trước khi đóng.',parent=self);return
        self.destroy()
