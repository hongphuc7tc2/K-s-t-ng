"""Author utility: create release metadata for a ZIP, without editing application settings."""
import hashlib,json
from pathlib import Path
import tkinter as tk
from tkinter import filedialog,simpledialog,messagebox
from updates import VERSION,https_url,version_tuple

if __name__=='__main__':
    root=tk.Tk();root.withdraw()
    try:
        file=filedialog.askopenfilename(title='Chọn ZIP phiên bản phát hành',filetypes=[('ZIP','*.zip')])
        if not file:raise SystemExit
        version=simpledialog.askstring('Phiên bản','Số phiên bản của ZIP:',initialvalue=VERSION)
        if not version:raise SystemExit
        version_tuple(version)
        url=simpledialog.askstring('Địa chỉ tải ZIP','URL HTTPS tải trực tiếp ZIP đã đăng lên máy chủ/GitHub Releases:')
        if not url:raise SystemExit
        https_url(url)
        notes=simpledialog.askstring('Nội dung cập nhật','Tóm tắt phiên bản mới:') or ''
        data={'version':version,'download_url':url,'sha256':hashlib.sha256(Path(file).read_bytes()).hexdigest(),'notes':notes}
        out=filedialog.asksaveasfilename(title='Lưu version.json',initialfile='version.json',defaultextension='.json')
        if out:Path(out).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');messagebox.showinfo('Đã tạo','Đăng version.json cùng ZIP lên nơi phát hành. Nhập URL cố định của version.json vào Cài đặt cập nhật.')
    except Exception as exc:messagebox.showerror('Tạo thông tin cập nhật',str(exc))
    finally:root.destroy()
