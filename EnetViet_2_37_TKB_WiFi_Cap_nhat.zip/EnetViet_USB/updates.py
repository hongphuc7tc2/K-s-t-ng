"""Opt-in release feed with bounded downloads and staged, verified updates."""
import hashlib,json,re,shutil,subprocess,sys,tempfile,threading,zipfile
from pathlib import Path,PurePosixPath
from urllib.request import urlopen,Request
from urllib.parse import urlparse
from tkinter import ttk,messagebox
import tkinter as tk
from profiles import atomic_json
from legacy_app import ROOT
VERSION='2.37'
SETTINGS=ROOT/'cap_nhat_settings.json'

def version_tuple(value):
    if not isinstance(value,str) or not re.fullmatch(r'\d+(?:\.\d+){1,3}',value):raise ValueError('Số phiên bản không hợp lệ.')
    return tuple(int(x) for x in value.split('.'))+(0,)*(4-len(value.split('.')))

def https_url(value):
    p=urlparse(value)
    if p.scheme!='https' or not p.netloc or p.username or p.password:raise ValueError('Địa chỉ cập nhật phải là HTTPS.')
    return value

def fetch(url,limit):
    with urlopen(Request(https_url(url),headers={'User-Agent':'EnetViet-USB/'+VERSION}),timeout=20) as r:
        https_url(r.url)
        data=r.read(limit+1)
        if len(data)>limit:raise ValueError('Tệp cập nhật vượt kích thước cho phép.')
        return data

def settings():
    try:return json.loads(SETTINGS.read_text(encoding='utf-8'))
    except (OSError,ValueError):return {}

def check_feed(url):
    data=json.loads(fetch(url,128*1024).decode('utf-8-sig'))
    if version_tuple(data['version'])<=version_tuple(VERSION):return None
    https_url(data['download_url'])
    if not re.fullmatch(r'[0-9a-fA-F]{64}',data.get('sha256','')):raise ValueError('Bản phát hành thiếu mã SHA-256 hợp lệ.')
    return data

def start_check(app,manual=False):
    url=settings().get('manifest_url','')
    if not url:
        if manual:messagebox.showinfo('Cập nhật','Chưa đặt địa chỉ phát hành. Mở Cài đặt cập nhật để nhập URL version.json.')
        return
    def work():
        try:app.events.put(('update_result',{'release':check_feed(url),'manual':manual}))
        except Exception as exc:
            if manual:app.events.put(('update_result',{'error':str(exc),'manual':True}))
    threading.Thread(target=work,daemon=True).start()

def safe_members(z):
    files=[];total=0;seen=set()
    for item in z.infolist():
        if item.is_dir():continue
        path=PurePosixPath(item.filename)
        if '\\' in item.filename or path.is_absolute() or '..' in path.parts or not path.parts or path.parts[0]!='EnetViet_USB':raise ValueError('ZIP cập nhật có đường dẫn không hợp lệ.')
        rel=PurePosixPath(*path.parts[1:])
        allowed=(len(rel.parts)==1 and rel.suffix in ('.py','.txt','.bat')) or (len(rel.parts)==2 and rel.parts[0]=='icons' and rel.suffix=='.png') or (len(rel.parts)==2 and rel.parts[0]=='borrow_fixtures' and rel.suffix=='.xml') or str(rel) in ('ppct.json','special_ppct.json')
        if not allowed:raise ValueError('ZIP chứa tệp không thuộc phần mềm: '+str(rel))
        if any(':' in p for p in rel.parts) or (item.external_attr>>16)&0o170000==0o120000:raise ValueError('ZIP có tệp liên kết/đường dẫn không hợp lệ.')
        key=str(rel).lower()
        if key in seen:raise ValueError('ZIP trùng tên tệp.')
        seen.add(key);total+=item.file_size
        if total>80*1024*1024:raise ValueError('Gói giải nén quá lớn.')
        files.append((item,str(rel)))
    if not {'app.py','borrow.py','LICH_SU_PHIEN_BAN.txt'.lower()}<=seen:raise ValueError('ZIP không đủ tệp ứng dụng.')
    return files

def stage_release(release):
    data=fetch(release['download_url'],30*1024*1024)
    if hashlib.sha256(data).hexdigest()!=release['sha256'].lower():raise ValueError('Mã kiểm tra gói tải không khớp. Chưa cài đặt.')
    folder=Path(tempfile.mkdtemp(prefix='EnetViet_update_'));archive=folder/'release.zip';archive.write_bytes(data)
    try:
        with zipfile.ZipFile(archive) as z:
            members=safe_members(z)
            for item,rel in members:
                dst=folder/'files'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(z.read(item))
        return folder
    except Exception:
        shutil.rmtree(folder,ignore_errors=True);raise

def offer_update(app,result):
    if result.get('error'):messagebox.showwarning('Kiểm tra cập nhật',result['error']);return
    release=result.get('release')
    if not release:
        if result.get('manual'):messagebox.showinfo('Cập nhật','Đang dùng phiên bản mới nhất: '+VERSION)
        return
    win=tk.Toplevel(app.root);win.title('Có phiên bản mới');win.geometry('560x290')
    ttk.Label(win,text=f"Có bản {release['version']} — đang dùng {VERSION}",font=('Segoe UI',13,'bold')).pack(padx=15,pady=12)
    ttk.Label(win,text=str(release.get('notes',''))[:1600],wraplength=520).pack(fill='both',expand=True,padx=15)
    def install():
        if app.busy:messagebox.showinfo('Đang chạy','Chờ tác vụ điện thoại kết thúc rồi cập nhật.',parent=win);return
        if not messagebox.askokcancel('Cập nhật','Lưu các cửa sổ chỉnh sửa trước. Phần mềm sẽ tải gói, đóng và mở lại sau khi cập nhật. Hồ sơ và thiết lập cá nhân được giữ.',parent=win):return
        win.destroy()
        def work():
            app.log('Đang tải và kiểm tra gói cập nhật...')
            folder=stage_release(release)
            if app.stop.is_set():
                shutil.rmtree(folder,ignore_errors=True);raise RuntimeError('Đã hủy cập nhật theo yêu cầu.')
            app.events.put(('update_staged',str(folder)))
            return {'state':'ok','detail':'Đã tải gói; chuẩn bị cài đặt.'}
        app.run(work)
    row=ttk.Frame(win);row.pack(fill='x',padx=15,pady=12)
    ttk.Button(row,text='Cập nhật',command=install).pack(side='right')
    ttk.Button(row,text='Bỏ qua',command=win.destroy).pack(side='right',padx=8)

def launch_install(app,folder):
    import os
    script=Path(folder)/'install_update.py';shutil.copy2(ROOT/'install_update.py',script)
    subprocess.Popen([sys.executable,str(script),str(ROOT),str(folder),str(os.getpid())],creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    app.root.destroy()

def configure(app):
    win=tk.Toplevel(app.root);win.title('Cài đặt cập nhật');win.geometry('650x240')
    ttk.Label(win,text='Địa chỉ HTTPS cố định của version.json do tác giả phát hành.\nKhi mở phần mềm: có bản mới mới thông báo; mất mạng hoặc đã mới nhất thì vào bình thường.',wraplength=610).pack(padx=12,pady=12)
    url=tk.StringVar(value=settings().get('manifest_url',''));ttk.Entry(win,textvariable=url,width=80).pack(fill='x',padx=12)
    def save():
        try:
            text=url.get().strip()
            if text:https_url(text)
            atomic_json(SETTINGS,{'manifest_url':text});win.destroy();start_check(app,True)
        except Exception as exc:messagebox.showerror('Cập nhật',str(exc),parent=win)
    ttk.Button(win,text='Lưu địa chỉ và kiểm tra',command=save).pack(pady=12)
