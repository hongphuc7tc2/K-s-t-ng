from timetable import active_revision, end_week
"""Portable teacher profiles. No credentials in profile or archives."""
import copy
import json
import uuid
import zipfile
from pathlib import Path
from collections import Counter
from defaults import resolve_defaults
from schedule import REGULAR, SPECIAL, TIMETABLE


def atomic_json(path,data):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix('.tmp'); temp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8'); temp.replace(path)


def validate(p):
    resolve_defaults(p.get('write_defaults'))
    if p.get('unresolved_questions'):
        raise ValueError('Cần làm rõ trước khi lưu profile: '+'; '.join(map(str,p['unresolved_questions'])))
    if p.get('schema')!=2: raise ValueError('Hồ sơ không đúng phiên bản 2.')
    for key in ('id','name','subject','school_year'):
        if not isinstance(p.get(key),str) or not p[key].strip(): raise ValueError('Thiếu '+key)
    uuid.UUID(p['id'])
    courses=p.get('courses',{})
    if not courses: raise ValueError('Chưa có PPCT.')
    for key,c in courses.items():
        if c.get('kind') not in ('Thường','Tích hợp','TT'): raise ValueError('Loại PPCT phải là Thường, Tích hợp hoặc TT.')
        if not c.get('name') or not c.get('periods'): raise ValueError('PPCT thiếu tên hoặc bài dạy.')
        if c.get('subject') is not None and (not isinstance(c['subject'],str) or not c['subject'].strip()): raise ValueError('Tên môn của danh mục không hợp lệ.')
        offsets=c.get('taught_offsets')
        if offsets is not None:
            stride=c.get('weekly_stride')
            if type(stride)!=int or stride<1 or not isinstance(offsets,list) or not offsets or any(type(n)!=int or not 1<=n<=stride for n in offsets) or sorted(set(offsets))!=offsets:
                raise ValueError('Quy tắc lấy tiết PPCT trong tuần không hợp lệ.')
        for n,title in c['periods'].items():
            if not str(n).isdigit() or int(n)<1 or not isinstance(title,str) or not title.strip(): raise ValueError('Số/tên bài PPCT không hợp lệ.')
    schedules=p.get('schedules',[])
    if not schedules: raise ValueError('Chưa có TKB.')
    weeks=set()
    for rev in schedules:
        w=rev['from_week']
        if type(w)!=int or not 1<=w<=53 or w in weeks: raise ValueError('Tuần áp dụng TKB trùng hoặc không hợp lệ.')
        end=rev.get('to_week')
        if end is not None and (type(end)!=int or not w<=end<=53):raise ValueError('Tuần kết thúc TKB không hợp lệ.')
        if end is not None and any(w<r['from_week']<=end for r in schedules):raise ValueError('Khoảng tuần TKB bị trùng.')
        weeks.add(w); occupied=set(); groups={}
        if not rev.get('rows'): raise ValueError('TKB trống.')
        for r in rev['rows']:
            if r['course'] not in courses: raise ValueError('TKB dùng PPCT chưa có: '+str(r['course']))
            if type(r['day'])!=int or r['day'] not in range(2,9) or r['session'] not in ('Sáng','Chiều') or type(r['slot'])!=int or not 1<=r['slot']<=15: raise ValueError('Thứ/buổi/tiết không hợp lệ.')
            if not isinstance(r['classroom'],str) or not r['classroom'].strip(): raise ValueError('Thiếu tên lớp.')
            pos=(r['day'],r['session'],r['slot'])
            if pos in occupied: raise ValueError('TKB có hai lớp trùng giờ: '+str(pos))
            occupied.add(pos)
            for k in ('anchor_week','start_period'):
                if type(r[k])!=int or r[k]<1: raise ValueError('Tuần mốc và PPCT đầu phải là số nguyên dương.')
            group=(r['classroom'],r['course']); anchor=(r['anchor_week'],r['start_period'])
            if group in groups and groups[group]!=anchor: raise ValueError('Cùng lớp/PPCT phải có cùng tuần mốc và PPCT đầu.')
            groups[group]=anchor
    for revision in schedules:
        counts=Counter((r['classroom'],r['course']) for r in revision['rows'])
        for (cls,code),count in counts.items():
            offsets=courses[code].get('taught_offsets')
            if offsets is not None and len(offsets)!=count: raise ValueError(f'{cls} / {code}: TKB cần {len(offsets)} tiết theo quy tắc PPCT, hiện có {count}.')
    assignments=set()
    for item in p.get('week_assignments',[]):
        group=(item['classroom'],item['course'],item['week'])
        if group in assignments: raise ValueError('Trùng phân tuần PPCT: '+str(group))
        assignments.add(group)
        if item['course'] not in courses or type(item['week'])!=int or not 1<=item['week']<=53: raise ValueError('Phân tuần PPCT không hợp lệ.')
        versions=[r for r in schedules if r['from_week']<=item['week']<=end_week(schedules,r)]
        if not versions: raise ValueError('Phân tuần chưa có TKB tương ứng.')
        rows=max(versions,key=lambda r:r['from_week'])['rows']
        count=sum(r['classroom']==item['classroom'] and r['course']==item['course'] for r in rows)
        if not count or len(item['periods'])!=count: raise ValueError('Số PPCT phân tuần không bằng số tiết TKB: '+str(group))
        if any(type(n)!=int or str(n) not in courses[item['course']]['periods'] for n in item['periods']): raise ValueError('Phân tuần chứa PPCT chưa có trong danh mục.')
    integrated=set(p.get('integrated_classes',[]))
    for cls in integrated:
        kinds={courses[r['course']]['kind'] for rev in schedules for r in rev['rows'] if r['classroom']==cls}
        required={'Tích hợp','TT'} if 'teaching_options' not in p else {'Tích hợp'}
        if not required<=kinds:raise ValueError(f'Lớp {cls} thiếu PPCT tích hợp hoặc TT theo cấu hình.')
    from teacher_setup import validate_setup
    validate_setup(p)
    return p


def default_profile():
    courses={}
    for grade in ('6','7'):
        courses[grade]={'name':'Toán '+grade,'kind':'Thường','exact_title':False,'teaching_type':'Lên lớp',
            'periods':{str(r['period']):r['source_text'] for rows in REGULAR[grade]['weeks'].values() for r in rows}}
    for key,kind in [('6A11','Tích hợp'),('6A11_TT','TT')]:
        courses[key]={'name':key,'kind':kind,'exact_title':True,'teaching_type':'Lên lớp' if kind!='TT' else '',
            'periods':{n:r['title'] for n,r in SPECIAL[key]['periods'].items()}}
    rows=[dict(day=d,session=s,slot=n,classroom=c,course=('6A11_TT' if k=='TT' else '6A11') if c=='6A11' else c[0],anchor_week=1,start_period=1) for d,s,n,c,k in TIMETABLE]
    return validate(dict(schema=2,id='16862bf4-77df-4e2e-a9e4-dcd6819ee536',name='Nguyễn Hồng Phúc',subject='Toán',school_year='2026-2027',integrated_classes=['6A11'],courses=courses,schedules=[{'from_week':7,'rows':rows}],sources=[],reviewed=True))


def plan(p,week):
    validate(p)
    revision=active_revision(p['schedules'],week);provisional=False
    if revision is None:
        earliest=min(p['schedules'],key=lambda r:r['from_week'])
        if week<earliest['from_week'] and 'to_week' not in earliest:
            revision=earliest;provisional=True
        else:raise ValueError(f'Chưa có TKB áp dụng cho tuần {week}. Mở Đổi TKB để thêm hoặc sửa khoảng tuần.')
    rows=sorted(revision['rows'],key=lambda r:(r['day'],r['session']=='Chiều',r['slot']))
    counts=Counter((r['classroom'],r['course']) for r in rows); seen=Counter(); result=[]
    for r in rows:
        group=(r['classroom'],r['course']); seen[group]+=1; course=p['courses'][r['course']]
        offsets=course.get('taught_offsets')
        if offsets:
            # start_period is the first TAUGHT period at anchor_week (2 for HDTN week 1).
            period=r['start_period']+(week-r['anchor_week'])*course['weekly_stride']+offsets[seen[group]-1]-offsets[0]
        else: period=r['start_period']+(week-r['anchor_week'])*counts[group]+seen[group]-1
        subject=course.get('subject',p['subject'])
        assigned=[a for a in p.get('week_assignments',[]) if (a['classroom'],a['course'])==group]
        if assigned:
            current=next((a for a in assigned if a['week']==week),None)
            period=current['periods'][seen[group]-1] if current else 0
        title=course['periods'].get(str(period))
        result.append(dict(r,schedule_provisional=provisional,schedule_from_week=revision['from_week'],schedule_to_week=end_week(p['schedules'],revision),week=week,profile_id=p['id'],school_year=p['school_year'],subject=subject,kind='TT' if course['kind']=='TT' else subject,ordinal=seen[group],period=period,title=title or 'CHƯA CÓ PPCT — cần cập nhật',expected_title=title if course.get('exact_title',True) else None,teaching_type=course.get('teaching_type',''),valid=title is not None))
    return result


def key(t):
    return '|'.join(map(str,[t['profile_id'],t['school_year'],t['week'],t['day'],t['session'],t['slot'],t['classroom'],t['subject']]))

class Ledger:
    def __init__(self,path):
        self.path=Path(path); self.data=json.loads(self.path.read_text(encoding='utf-8')) if self.path.exists() else {}
    def state(self,t,mode='write'): return self.data.get(key(t),{}).get(mode,'pending')
    def mark(self,t,state,mode='write'):
        self.data.setdefault(key(t),{}).update({mode:state,'period':t['period']}); atomic_json(self.path,self.data)

class Store:
    def __init__(self,root):
        self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True)
    def list(self):
        return [validate(json.loads(p.read_text(encoding='utf-8'))) for p in sorted(self.root.glob('*.json'))]
    def save(self,p):
        validate(p);path=self.root/(p['id']+'.json')
        if path.exists():
            previous=json.loads(path.read_text(encoding='utf-8'))
            if previous!=p:self.backup(previous)
        atomic_json(path,p)
    def backup(self,p):
        from datetime import datetime
        folder=self.root.parent/'sao_luu';folder.mkdir(exist_ok=True)
        target=folder/(p['id']+'_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.zip')
        progress_path=self.root.parent/'tien_do_profiles.json'
        progress=json.loads(progress_path.read_text(encoding='utf-8')) if progress_path.exists() else {}
        self.export(p,target,progress)
        return target
    def delete(self,profile_id):
        import datetime
        uuid.UUID(profile_id)
        path=self.root/(profile_id+'.json')
        if not path.exists():raise ValueError('Không tìm thấy hồ sơ cần xóa.')
        archive=self.root/'_da_xoa';archive.mkdir(exist_ok=True)
        target=archive/(profile_id+'_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.json')
        path.replace(target)
        return target
    def export(self,p,path,progress=None):
        validate(p)
        with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
            z.writestr('profile.json',json.dumps(p,ensure_ascii=False,indent=2))
            if progress is not None:
                z.writestr('progress.json',json.dumps({k:v for k,v in progress.items() if k.startswith(p['id']+'|')},ensure_ascii=False))
    def read_package(self,path):
        path=Path(path)
        if path.stat().st_size>20_000_000: raise ValueError('Hồ sơ quá lớn.')
        if path.suffix.lower()=='.json': return validate(json.loads(path.read_text(encoding='utf-8-sig'))),{}
        with zipfile.ZipFile(path) as z:
            if sum(n.file_size for n in z.infolist())>20_000_000: raise ValueError('Hồ sơ quá lớn.')
            p=validate(json.loads(z.read('profile.json')))
            progress=json.loads(z.read('progress.json')) if 'progress.json' in z.namelist() else {}
            if not isinstance(progress,dict) or any(not k.startswith(p['id']+'|') for k in progress): raise ValueError('Tiến độ không thuộc profile.')
            allowed={'pending','working','saving','saved','skipped'}
            if any(not isinstance(v,dict) or any(v.get(m,'pending') not in allowed for m in ('write','complete')) for v in progress.values()): raise ValueError('Tiến độ không hợp lệ.')
            return p,progress
