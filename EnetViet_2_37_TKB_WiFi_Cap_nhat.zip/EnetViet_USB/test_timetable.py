import copy
import unittest
import xml.etree.ElementTree as ET
from profiles import default_profile, plan, validate
from timetable import active_revision, change_range, remove_revision, course_label, DAYS
from navigator import selected_day

class TimetableTests(unittest.TestCase):
    def test_change_closes_previous_and_preserves_rows(self):
        p=default_profile();old=copy.deepcopy(p['schedules'])
        p['schedules']=change_range(old,None,10,None,old[0]['rows'])
        self.assertEqual(p['schedules'][0]['to_week'],9)
        self.assertNotIn('to_week',old[0])
        self.assertEqual(plan(p,9)[0]['schedule_from_week'],7)
        self.assertEqual(plan(p,10)[0]['schedule_from_week'],10)
    def test_bounded_schedule_does_not_run_outside_range(self):
        p=default_profile();p['schedules'][0]['to_week']=9
        self.assertEqual(len(plan(p,9)),15)
        for week in (6,10):
            with self.assertRaisesRegex(ValueError,'Chưa có TKB'):plan(p,week)
    def test_delete_does_not_revive_old_schedule(self):
        p=default_profile();old=p['schedules'][0]
        p['schedules'].append(dict(from_week=10,rows=copy.deepcopy(old['rows'])))
        p['schedules']=remove_revision(p['schedules'],10)
        self.assertEqual(p['schedules'][0]['to_week'],9)
        with self.assertRaises(ValueError):plan(p,10)
    def test_overlap_and_invalid_range_rejected(self):
        rows=default_profile()['schedules'][0]['rows']
        with self.assertRaises(ValueError):change_range([],None,10,9,rows)
        with self.assertRaises(ValueError):change_range([dict(from_week=10,rows=rows)],None,7,12,rows)
        with self.assertRaises(ValueError):remove_revision([dict(from_week=7,rows=rows)],7)
    def test_sunday_and_names(self):
        p=default_profile();p['schedules'][0]['rows'][0]['day']=8
        validate(p)
        self.assertEqual(plan(p,7)[-1]['day'],8)
        self.assertEqual(DAYS[8],'Chủ Nhật')
        self.assertTrue(selected_day([ET.Element('node',text='CN',selected='true')],8))
        self.assertEqual(course_label('6A11',p['courses']['6A11']),'Toán 6 Tích hợp')
        self.assertEqual(course_label('6A11_TT',p['courses']['6A11_TT']),'Toán 6 Tăng tiết')

if __name__=='__main__':unittest.main()
