from ui_scan import BidirectionalScan
from week_picker import picker_list, visible_options, WeekSweep
import re
import time
from engine import FormAssistant, label, bounds, same_class, normalized, save_success

PACKAGE='enetviet.corp.qi.enetvietnew'

def field_value(nodes,title):
    labels=[n for n in nodes if label(n)==title and n.get('resource-id','').endswith('/textViewLabel')]
    if len(labels)!=1:
        return None
    parents=[n for n in nodes if labels[0] in list(n)]
    if len(parents)!=1:
        return None
    vals=[label(n) for n in parents[0] if n.get('resource-id','').endswith('/textViewValue')]
    return vals[0] if len(vals)==1 else None

def week_number(nodes):
    value=field_value(nodes,'Chọn tuần') or ''
    m=re.match(r'Tuần\s+(\d+)\b',value)
    return int(m[1]) if m else None

def day_labels(day):
    return ('CN','Chủ Nhật','Chủ nhật') if day==8 else (f'T{day}',)

def selected_day(nodes,day):
    return any(label(n) in day_labels(day) and n.get('selected')=='true' for n in nodes)

def period_card(nodes,slot):
    lists=[n for n in nodes if n.get('resource-id','').endswith('/rvNotebook')]
    if len(lists)!=1:
        return None
    cards=[n for n in lists[0] if any(label(c)==f'Tiết {slot}' for c in n.iter('node'))]
    return cards[0] if len(cards)==1 else None

class Navigator(FormAssistant):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.package=PACKAGE

    def ensure_main(self):
        nodes=self.nodes()
        def ready(ns):
            return week_number(ns) is not None and any(n.get('resource-id','').endswith('/rvNotebook') for n in ns)
        def menu(ns,title):
            return [n for n in ns if n.get('resource-id')==PACKAGE+':id/tv_title' and label(n)==title]
        if ready(nodes):return
        teacher=menu(nodes,'Sổ đầu bài giáo viên')
        if not teacher:
            entry=menu(nodes,'Sổ đầu bài')
            if len(entry)==1:
                self.click(entry[0])
                nodes=self.wait_nodes(lambda ns:len(menu(ns,'Sổ đầu bài giáo viên'))==1,'Đang mở chức năng Sổ đầu bài...',timeout=30)
                teacher=menu(nodes,'Sổ đầu bài giáo viên')
        if len(teacher)==1:
            self.click(teacher[0])
        elif not any(label(n)=='Sổ đầu bài giáo viên' for n in nodes):
            raise RuntimeError('Mở trang chủ eNetViet có mục Sổ đầu bài hoặc màn hình Sổ đầu bài giáo viên trước khi chạy.')
        self.wait_nodes(ready,'Đang chờ sổ đầu bài tải tuần và danh sách tiết...',timeout=30)

    def return_after_saved(self):
        nodes=self.nodes()
        if save_success(nodes):
            self.close_success()
            nodes=self.nodes()
        if any(label(n)=='Sổ đầu bài giáo viên' for n in nodes):
            return
        if any(label(n)=='Ghi sổ đầu bài' for n in nodes):
            buttons=[n for n in nodes if n.get('resource-id')==PACKAGE+':id/img_action_left']
            if len(buttons)!=1:
                raise RuntimeError('Đã lưu nhưng chưa tìm được nút quay về danh sách.')
            self.click(buttons[0])
            self.wait_nodes(lambda ns:any(label(n)=='Sổ đầu bài giáo viên' for n in ns),
                            'Đã lưu; chờ trở về danh sách tiết...')
        else:
            raise RuntimeError('Đã lưu nhưng màn hình tiếp theo chưa nhận diện được.')

    def select_week(self,week):
        self.ensure_main()
        if week_number(self.nodes())==week:return
        self.log(f'Đang chuyển eNetViet sang tuần {week}...')
        self.click(self.exact('Chọn tuần'))
        self.wait_nodes(lambda ns:picker_list(ns) is not None,'Đang tải danh sách tuần...')
        sweep=WeekSweep()
        for _ in range(122):
            nodes=self.nodes();region=picker_list(nodes)
            if region is None:raise RuntimeError('Bảng chọn tuần đã đóng hoặc đổi. Dừng trước khi mở tiết.')
            options=visible_options(region)
            matches=[n for number,n in options if number==week]
            if len(matches)>1:raise RuntimeError(f'Có nhiều mục Tuần {week}; không chọn khi chưa rõ.')
            if len(matches)==1:
                self.click(matches[0])
                self.wait_nodes(lambda ns:week_number(ns)==week and picker_list(ns) is None
                    and any(label(n)=='Sổ đầu bài giáo viên' for n in ns),f'Đang xác nhận tuần {week} đã được chọn...')
                self.log(f'Đã xác nhận eNetViet đang ở tuần {week}.');return
            signature=tuple((number,n.get('bounds','')) for number,n in options)
            forward=sweep.next(signature)
            if forward is None:break
            x1,y1,x2,y2=bounds(region);w,h=self.d.window_size()
            x1=max(0,x1);x2=min(w,x2);y1=max(0,y1);y2=min(h,y2)
            if x2-x1<40 or y2-y1<80:raise RuntimeError('Vùng chọn tuần quá nhỏ để cuộn an toàn.')
            top=y1+(y2-y1)*.2;bottom=y1+(y2-y1)*.8;x=(x1+x2)/2
            self.check();self.log('Tìm tuần: cuộn '+('xuống' if forward else 'lên')+' danh sách...')
            self.d.swipe(x,bottom if forward else top,x,top if forward else bottom,.4)
            if self.stop.wait(.6):self.check()
        raise RuntimeError(f'Không tìm thấy Tuần {week} trong danh sách. Chưa mở hay ghi tiết; lấy dữ liệu màn hình để kiểm tra.')

    def open_task(self,task,existing_only=False):
        self.ensure_main()
        self.select_week(task['week'])
        nodes=self.nodes()
        if selected_day(nodes,task['day']):
            self.log('Thứ đã đúng, bỏ qua chọn lại.')
        else:
            candidates=[n for n in nodes if label(n) in day_labels(task['day'])]
            if len(candidates)!=1:raise RuntimeError('Không xác định duy nhất được thứ trên eNetViet. Hãy lấy dữ liệu màn hình.')
            self.click(candidates[0])
            self.wait_nodes(lambda ns:selected_day(ns,task['day']), 'Đang chọn thứ...')
        desired='Buổi '+task['session'].lower()
        nodes=self.nodes()
        if field_value(nodes,'Chọn buổi')==desired:
            self.log('Buổi đã đúng, bỏ qua chọn lại.')
        else:
            self.click(self.exact('Chọn buổi',nodes))
            nodes=self.wait_nodes(lambda ns: sum(label(n)==desired for n in ns)==1
                                  and any(label(n)=='Cả ngày' for n in ns), 'Đang chờ bảng chọn buổi...')
            self.click(self.exact(desired,nodes))
        def positioned(ns):
            return (week_number(ns)==task['week'] and selected_day(ns,task['day'])
                    and field_value(ns,'Chọn buổi')==desired
                    and any(n.get('resource-id','').endswith('/rvNotebook') for n in ns)
                    and not any(label(n)=='Cả ngày' for n in ns))
        self.wait_nodes(positioned,'Đang tải danh sách tiết của buổi...')
        # Wait for the network-backed list to settle before selecting a row.
        time.sleep(1)
        sweep=BidirectionalScan(limit=30)
        for attempt in range(70):
            nodes=self.nodes()
            if not positioned(nodes):
                raise RuntimeError('Thứ/buổi/tuần đã đổi. Đã dừng.')
            card=period_card(nodes,task['slot'])
            preferred=None
            target=None
            if card is not None:
                _,height=self.d.window_size()
                texts=[label(n) for n in card.iter('node') if n.get('resource-id','').endswith('/textViewClassNameSubject')]
                if texts:
                    if len(texts)!=1:
                        raise RuntimeError('Một tiết đang chứa nhiều bản ghi; cần kiểm tra thủ công.')
                    m=re.match(r'(.+?)\s*-\s*(.+)',texts[0])
                    if not m or not same_class(m[1],task['classroom']) or not (normalized(m[2])==normalized(task.get('subject','Toán')) or normalized(m[2]).startswith(normalized(task.get('subject','Toán'))+' ')):
                        raise RuntimeError('Ô TKB khác lớp/môn dự kiến: '+texts[0]+'. Không mở để sửa.')
                    target=[n for n in card.iter('node') if label(n)==texts[0]][0]
                else:
                    add=[n for n in card.iter('node') if n.get('resource-id','').endswith('/imageViewAdd')]
                    if len(add)>1:raise RuntimeError('Có nhiều nút mở tiết; cần kiểm tra thủ công.')
                    if len(add)==1:target=add[0]
                    if existing_only and target is not None:
                        raise RuntimeError('Tiết chưa có sổ đầu bài; không tạo mới trong chế độ Hoàn thành.')
                b=bounds(target) if target is not None else bounds(card)
                lists=[n for n in nodes if n.get('resource-id','').endswith('/rvNotebook')]
                list_top=bounds(lists[0])[1] if lists else height*.2
                list_bottom=min(bounds(lists[0])[3],height*.94)
                preferred=(b[1]+b[3])/2 >= (list_top+list_bottom)/2
                if target is not None and b[2]>b[0] and b[3]-b[1]>25 and b[1]>=list_top+4 and b[3]<list_bottom-4:
                    self.click(target)
                    self.wait_nodes(lambda ns:any(label(n)=='Ghi sổ đầu bài' for n in ns),
                                    'Đang mở phiếu ghi sổ đầu bài...')
                    return
            signature=tuple((label(n),n.get('bounds','')) for n in nodes if re.fullmatch(r'Tiết \d+',label(n)))
            if preferred is None:
                visible=[int(label(n).split()[-1]) for n in nodes
                         if re.fullmatch(r'Tiết \d+',label(n))]
                if visible and task['slot']>max(visible):preferred=True
                elif visible and task['slot']<min(visible):preferred=False
            # First bring a clipped/offscreen target into view, then bounded full scan.
            direction=preferred if attempt<8 and preferred is not None else sweep.next_direction(signature)
            if direction is None: break
            self.log('Tìm tiết: cuộn về phía '+('dưới' if direction else 'trên')+' danh sách...')
            self.scroll_timetable(nodes,direction)
        raise RuntimeError('Không tìm được ô tiết theo TKB.')

    def scroll_timetable(self,nodes,forward):
        lists=[n for n in nodes if n.get('resource-id','').endswith('/rvNotebook')]
        if len(lists)!=1:raise RuntimeError('Không xác định vùng danh sách tiết để cuộn.')
        x1,y1,x2,y2=bounds(lists[0]);w,h=self.d.window_size()
        y1=max(y1,h*.15);y2=min(y2,h*.93)
        if x2<=x1 or y2-y1<80:raise RuntimeError('Vùng danh sách tiết chưa hiển thị đủ.')
        self.check();x=(x1+x2)/2;top=y1+(y2-y1)*.18;bottom=y1+(y2-y1)*.82
        self.d.swipe(x,bottom if forward else top,x,top if forward else bottom,.4)
        if self.stop.wait(.6):self.check()

    def dropdown(self,title,desired,aliases=()):
        nodes=self.nodes()
        current=field_value(nodes,title)
        accepted=(desired,)+tuple(aliases)
        if current in accepted:
            self.log(title+': đã đúng, bỏ qua chọn lại.')
            return
        blank=current is None or current.startswith('Chọn') or current==title
        if title in ('Lớp','Môn học') and not blank:
            raise RuntimeError(f'{title} trên phiếu là {current}, không khớp {desired}.')
        self.click(self.exact(title,nodes))
        for _ in range(12):
            nodes=self.nodes()
            matches=[n for n in nodes if label(n) in accepted and
                     not n.get('resource-id','').endswith('/textViewValue')]
            if len(matches)==1:
                self.click(matches[0])
                self.wait_nodes(lambda ns:field_value(ns,title) in accepted,'Đang chọn '+title+'...')
                return
            if len(matches)>1:
                raise RuntimeError('Có nhiều lựa chọn trùng tên '+desired)
            self.scroll()
        raise RuntimeError('Không tìm thấy lựa chọn '+desired+'. Lấy dữ liệu màn hình để hiệu chỉnh tên mục.')

    def prepare_form(self,task,tt_type=''):
        self.dropdown('Lớp',task['classroom'],(task['classroom']+'(CS2)',task['classroom']+' (CS2)'))
        subjects=self.subjects(task)
        self.dropdown('Môn học',subjects[0],subjects[1:])
        teaching=task.get('teaching_type','Lên lớp')
        if task['kind']=='TT' and tt_type.strip(): teaching=tt_type.strip()
        if teaching: self.dropdown('Kiểu giảng dạy',teaching)
        return subjects

    @staticmethod
    def subjects(task):
        s=task.get('subject','Toán')
        return (s,s+' (TT)',s+'(TT)',s+' TT') if task['kind']=='TT' else (s,)


class TimetableSweep:
    """Inspect current position, scan toward top, then toward bottom; bounded."""
    def __init__(self):
        self.forward=False;self.previous=None;self.stalled=0;self.steps=0
    def next_direction(self,signature):
        self.stalled=self.stalled+1 if signature==self.previous else 0
        self.previous=signature;self.steps+=1
        if not self.forward and (self.stalled>=2 or self.steps>=9):
            self.forward=True;self.stalled=0;self.steps=0;self.previous=None
        elif self.forward and (self.stalled>=3 or self.steps>=16):return None
        return self.forward
