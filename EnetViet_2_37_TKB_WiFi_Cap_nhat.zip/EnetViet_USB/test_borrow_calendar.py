import unittest
from types import SimpleNamespace
from datetime import date
from test_borrow import fixture
from borrow import BorrowAssistant,calendar_cells,calendar_region,one
from engine import bounds

class CalendarTests(unittest.TestCase):
    def test_missing_or_duplicate_pager_uses_day_row(self):
        for duplicate in (False,True):
            ns=fixture('main');pager=one(ns,'mcv_pager')
            if duplicate:
                from xml.etree.ElementTree import Element
                ns.append(Element('node',pager.attrib))
            else:pager.set('resource-id','')
            self.assertEqual(len(calendar_cells(ns)),7)
            self.assertGreater(bounds(calendar_region(ns))[2]-bounds(calendar_region(ns))[0],1000)
    def test_incomplete_calendar_rejected(self):
        ns=fixture('main');calendar_cells(ns)[0].set('visible-to-user','false')
        with self.assertRaises(RuntimeError):calendar_cells(ns)
    def test_wrong_dates_rejected(self):
        ns=fixture('main');calendar_cells(ns)[0].set('text','30')
        with self.assertRaises(RuntimeError):calendar_cells(ns)
    def reader(self):
        n=BorrowAssistant.__new__(BorrowAssistant);n.log=lambda s:None;n.check=lambda:None
        n.stop=SimpleNamespace(wait=lambda s:False);return n
    def test_loaded_calendar_no_scroll(self):
        n=self.reader();n.nodes=lambda:fixture('main');n.swipe_region=lambda *a: self.fail('unnecessary scroll')
        self.assertEqual(len(calendar_cells(n.calendar_ready())),7)
    def test_loading_calendar_waits_without_swipe(self):
        n=self.reader();pending=fixture('main')
        for c in calendar_cells(pending):c.set('visible-to-user','false')
        states=iter([pending,pending,fixture('main')]);n.nodes=lambda:next(states)
        n.swipe_region=lambda *a:self.fail('must wait before scrolling')
        self.assertEqual(len(calendar_cells(n.calendar_ready())),7)
    def test_collapsed_calendar_revealed(self):
        n=self.reader();pending=fixture('main')
        for c in calendar_cells(pending):c.set('visible-to-user','false')
        state=[pending];calls=[];n.nodes=lambda:state[0]
        def swipe(region,forward):calls.append(forward);state[0]=fixture('main')
        n.swipe_region=swipe
        self.assertEqual(len(calendar_cells(n.calendar_ready())),7);self.assertEqual(calls,[False])
    def test_transient_missing_calendar_during_day_selection(self):
        n=self.reader();ns=fixture('main');one(ns,'mcv_pager').set('resource-id','')
        for c in calendar_cells(ns):c.set('checked','false')
        n.calendar_ready=lambda:ns;n.click=lambda node:node.set('checked','true')
        def wait(predicate,message):
            self.assertFalse(predicate([]));self.assertTrue(predicate(ns));return ns
        n.wait_nodes=wait
        self.assertEqual(n.day(2,date(2026,10,12)),date(2026,10,12))

if __name__=='__main__':unittest.main()
