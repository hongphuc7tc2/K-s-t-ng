"""Machine-local AI settings. Windows DPAPI protects saved API keys."""
import base64
import ctypes
from ctypes import wintypes
import json
import os
from pathlib import Path

MODELS={'Gemini':'gemini-2.5-flash','OpenAI':'gpt-4.1'}


def crypt(data, decrypt=False):
    if os.name!='nt':
        raise RuntimeError('Lưu khóa API được hỗ trợ trên Windows. Không lưu khóa dạng văn bản.')
    class Blob(ctypes.Structure):
        _fields_=[('size',wintypes.DWORD),('data',ctypes.POINTER(ctypes.c_ubyte))]
    dll=ctypes.WinDLL('crypt32',use_last_error=True)
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    fn=dll.CryptUnprotectData if decrypt else dll.CryptProtectData
    fn.argtypes=[ctypes.POINTER(Blob),ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(Blob)]
    fn.restype=wintypes.BOOL
    kernel.LocalFree.argtypes=[ctypes.c_void_p];kernel.LocalFree.restype=ctypes.c_void_p
    buf=ctypes.create_string_buffer(data)
    source=Blob(len(data),ctypes.cast(buf,ctypes.POINTER(ctypes.c_ubyte)));target=Blob()
    if not fn(ctypes.byref(source),None,None,None,None,1,ctypes.byref(target)):
        raise RuntimeError('Windows không thể bảo vệ/đọc khóa API. Hãy nhập lại khóa trên tài khoản Windows này.')
    try:return ctypes.string_at(target.data,target.size)
    finally:kernel.LocalFree(ctypes.cast(target.data,ctypes.c_void_p))


class Settings:
    def __init__(self,path=None,cipher=crypt):
        self.path=Path(path) if path else Path(os.environ.get('APPDATA',Path.home()))/'EnetViet_USB'/'ai_settings.json'
        self.cipher=cipher
    def read(self):
        if not self.path.exists():return {}
        try:
            data=json.loads(self.path.read_text(encoding='utf-8'))
            if not isinstance(data,dict):raise ValueError()
            return data
        except Exception:raise RuntimeError('Không đọc được cấu hình AI. Mở Cài đặt AI để lưu lại cấu hình.') from None
    def load(self,provider):
        entry=self.read().get(provider,{})
        key=self.cipher(base64.b64decode(entry['key']),True).decode('utf-8') if entry.get('key') else ''
        return entry.get('model',MODELS[provider]),key
    def save(self,provider,model,key):
        model=model.strip();key=key.strip()
        if not model or not key:raise ValueError('Nhập đủ model và khóa API.')
        encrypted=base64.b64encode(self.cipher(key.encode('utf-8'))).decode('ascii')
        data=self.read();data[provider]={'model':model,'key':encrypted}
        self.write(data)
    def write(self,data):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        temp=self.path.with_suffix('.tmp');temp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(self.path)
    def forget(self,provider):
        data=self.read();data.pop(provider,None);self.write(data)


def configure(parent,provider='Gemini',allow_skip=False):
    import tkinter as tk
    from tkinter import ttk,messagebox
    from widgets import Tooltip
    store=Settings();win=tk.Toplevel(parent);win.title(('Thiết lập AI cho hồ sơ mới — ' if allow_skip else 'Cài đặt AI — ')+provider);win.transient(parent)
    previous=parent.grab_current();win.grab_set();result=[]
    try:model,key=store.load(provider)
    except Exception as e:
        model,key=MODELS[provider],'';messagebox.showwarning('Cấu hình AI',str(e),parent=win)
    from branding import credit
    credit(win)
    frame=ttk.Frame(win,padding=18);frame.pack(fill='both',expand=True)
    ttk.Label(frame,text='Nhớ model và API '+provider,font=('Segoe UI',12,'bold')).pack(anchor='w')
    ttk.Label(frame,text='Model (tên chính xác được cấp cho API của thầy):').pack(anchor='w',pady=(12,3))
    mv=tk.StringVar(value=model);me=ttk.Entry(frame,textvariable=mv,width=62);me.pack(fill='x')
    me._tooltip=Tooltip(me,'Tên model gửi tới API. Phần mềm nhớ tên này cho lần phân tích sau; nhập model hỗ trợ tài liệu đang dùng.')
    ttk.Label(frame,text='Khóa API:').pack(anchor='w',pady=(10,3))
    kv=tk.StringVar(value=key);ke=ttk.Entry(frame,textvariable=kv,show='*',width=62);ke.pack(fill='x')
    ke._tooltip=Tooltip(ke,'Khóa được mã hóa bằng Windows và chỉ dùng trên tài khoản Windows đã lưu. Không nằm trong hồ sơ xuất ra.')
    show=tk.BooleanVar(value=False)
    ttk.Checkbutton(frame,text='Hiện khóa API',variable=show,command=lambda:ke.configure(show='' if show.get() else '*')).pack(anchor='w',pady=5)
    ttk.Label(frame,text='Lưu một lần, dùng chung cho phân tích TKB/PPCT và thêm HĐTN.\nCó thể đổi hoặc xóa tại đây. Chuyển máy cần nhập khóa lại.',wraplength=520).pack(anchor='w',pady=8)
    if allow_skip:
        ttk.Label(frame,text='Chưa có API? Bấm Tạm thời bỏ qua để tiếp tục. Có thể nhập sau tại Cài đặt AI.\nKhông có API vẫn dùng được cách xuất hồ sơ gửi ChatGPT rồi nhập kết quả.',wraplength=560).pack(anchor='w',pady=8)
    def save():
        try:store.save(provider,mv.get(),kv.get())
        except Exception as e:messagebox.showerror('Không lưu được',str(e),parent=win);return
        result.append((mv.get().strip(),kv.get().strip()));win.destroy()
    def forget():
        try:store.forget(provider)
        except Exception as e:messagebox.showerror('Không xóa được',str(e),parent=win);return
        kv.set('');mv.set(MODELS[provider]);messagebox.showinfo('Đã xóa','Đã xóa cấu hình '+provider+' đã lưu.',parent=win)
    bar=ttk.Frame(frame);bar.pack(fill='x',pady=8)
    ttk.Button(bar,text='Xóa cấu hình đã lưu',command=forget).pack(side='left')
    ttk.Button(bar,text='Tạm thời bỏ qua' if allow_skip else 'Hủy',command=win.destroy).pack(side='right')
    ttk.Button(bar,text='Lưu cấu hình',command=save).pack(side='right',padx=8)
    parent.wait_window(win)
    if previous:
        try:previous.grab_set()
        except tk.TclError:pass
    return result[0] if result else None


def credentials(parent,provider):
    try:
        model,key=Settings().load(provider)
        if model and key:return model,key
    except Exception:
        pass
    return configure(parent,provider)
