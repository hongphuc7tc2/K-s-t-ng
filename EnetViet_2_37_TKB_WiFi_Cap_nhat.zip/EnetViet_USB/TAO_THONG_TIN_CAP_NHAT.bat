@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" release_manifest.py
