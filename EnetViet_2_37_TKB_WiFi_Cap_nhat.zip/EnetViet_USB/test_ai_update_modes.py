import copy
import unittest
from types import SimpleNamespace as NS
from profiles import default_profile
from profile_ui import ProfileEditor

class UpdateModes(unittest.TestCase):
    def parent(self,mode):
        p=default_profile()
        return NS(metadata=lambda:copy.deepcopy(p),files=[('TKB','new.xlsx'),('PPCT khối','ppct.pdf')],has_note=NS(get=lambda:False),note=None,ai_mode=NS(get=lambda:mode),ai_course=NS(get=lambda:'Toán 6'),ai_course_codes={'Toán 6':'6'},ai_week=NS(get=lambda:8))
    def test_ppct_selects_only_ppct_files_and_target(self):
        p,n,files=ProfileEditor.request_data(self.parent('Cập nhật PPCT hiện có'))
        self.assertEqual(files,['ppct.pdf']);self.assertIn('course 6',n);self.assertIn('Giữ mã course, TKB',n)
    def test_tkb_has_week_and_only_tkb_files(self):
        p,n,files=ProfileEditor.request_data(self.parent('Cập nhật TKB mới nhất'))
        self.assertEqual(files,['new.xlsx']);self.assertIn('từ tuần 8',n)
    def test_update_requires_new_file(self):
        obj=self.parent('Cập nhật PPCT hiện có');obj.files=[]
        with self.assertRaisesRegex(ValueError,'tệp PPCT mới'):ProfileEditor.request_data(obj)
