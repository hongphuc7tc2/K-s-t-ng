import colorsys

def group_colors(rows,mode):
    def group(row):
        if mode=='classroom':return row['classroom']
        if mode=='subject':return row.get('subject',row.get('kind',''))
        return row['session']
    if mode=='day':palette={'Sáng':'#fff9e9','Chiều':'#edf6fd'}
    else:
        groups=sorted({group(row) for row in rows.values()});palette={}
        for i,name in enumerate(groups):
            rgb=colorsys.hls_to_rgb((.12+i*.61803398875)%1,.95,.55)
            palette[name]='#'+''.join(f'{round(v*255):02x}' for v in rgb)
    return {iid:palette[group(row)] for iid,row in rows.items()}

def paint_rows(tree,rows,mode):
    if not hasattr(tree,'tag_configure'):return
    for iid,color in group_colors(rows,mode).items():
        if not tree.exists(iid):continue
        tag='shade_'+color[1:];tree.tag_configure(tag,background=color,foreground='#172b3a')
        tags=[t for t in tree.item(iid,'tags') if not t.startswith('shade_')]
        tree.item(iid,tags=tuple(tags+[tag]))
