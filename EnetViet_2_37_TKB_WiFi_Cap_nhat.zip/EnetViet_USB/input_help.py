"""Contextual help shared by profile and HĐTN forms."""
from tkinter import ttk
from widgets import Tooltip

HINTS={
'name':'Tên giáo viên để nhận biết profile. Chọn hồ sơ không tự đổi tài khoản eNetViet.',
'subject':'Môn mặc định của hồ sơ. Mỗi danh mục PPCT có thể đặt môn riêng, ví dụ Toán và HĐTN.',
'school_year':'Năm học của lịch và tiến độ, ví dụ 2026-2027.',
'integrated':'Nhập tên các lớp tích hợp, cách nhau bằng dấu phẩy, ví dụ 6A11, 7A1. Mỗi lớp cần PPCT riêng và PPCT tăng tiết.',
'has_integrated':'Bật khi có lớp học chương trình tích hợp, dùng PPCT khác với lớp thường.',
'provider':'Chọn dịch vụ AI. Model và API được nhớ riêng cho Gemini/OpenAI trong Cài đặt AI.',
'from_week':'Tuần bắt đầu áp dụng phiên bản thời khóa biểu này. Khác với tuần mốc dùng để tính PPCT.',
'anchor_week':'Tuần dùng làm mốc tính PPCT của lớp và danh mục. Ví dụ tuần mốc 6, PPCT đầu 21: tuần 6 bắt đầu từ PPCT 21.',
'start_period':'Số PPCT đầu tiên giáo viên thực sự dạy trong tuần mốc, không phải số tiết trong buổi. Toán 4 tiết/tuần: mốc 6, đầu 21 → tuần 6: 21–24; tuần 7: 25–28. HĐTN: mốc 1, đầu 2 → 2–3 rồi 5–6.',
'day':'Thứ trong tuần: từ Thứ Hai đến Chủ Nhật.',
'session':'Buổi dạy trên thời khóa biểu: Sáng hoặc Chiều.',
'slot':'Số tiết trong buổi trên TKB, ví dụ tiết 2 buổi sáng. Không phải số tiết PPCT.',
'classroom':'Tên lớp đúng như trên eNetViet. Có thể chọn lớp có sẵn hoặc nhập lớp mới.',
'course':'Danh mục PPCT dùng cho lớp và môn này. Chọn riêng PPCT thường, tích hợp, TT hoặc HĐTN.',
'course_name':'Tên dễ nhận biết của danh mục, ví dụ Toán 6 thường hoặc HĐTN 6A1.',
'kind':'Thường: PPCT thông thường; Tích hợp: PPCT riêng của lớp tích hợp; TT: PPCT tăng tiết.',
'course_subject':'Tên môn cần chọn trên eNetViet cho danh mục này, ví dụ Toán hoặc HĐTN.',
'teaching':'Tên Kiểu giảng dạy đúng trên eNetViet nếu cần chọn. Để trống khi không cần thay đổi.',
'hdtn':'PPCT HĐTN có 3 tiết/tuần nhưng giáo viên chỉ dạy 2 tiết sau. Mốc 1, đầu 2 → tuần 1: 2–3, tuần 2: 5–6.',
'exact':'Bật để kiểm tra số PPCT và tên bài. Chỉ bỏ chọn nếu tên trong file bị gộp nhiều tiết và không trùng tên trên app.',
'reviewed':'Chỉ đánh dấu sau khi đối chiếu lịch, số PPCT và tên bài. Đây là điều kiện để lưu profile.',
}

def hint(widget,text):
    if text and not hasattr(widget,'_tooltip'):widget._tooltip=Tooltip(widget,text)

def attach(parent,mapping):
    """Map Tk variables to help, including fields and checkboxes."""
    lookup={str(var):HINTS.get(key,key) for var,key in mapping}
    def walk(w):
        for child in w.winfo_children():
            for option in ('textvariable','variable'):
                if option in child.keys():hint(child,lookup.get(str(child.cget(option))))
            walk(child)
    walk(parent)
