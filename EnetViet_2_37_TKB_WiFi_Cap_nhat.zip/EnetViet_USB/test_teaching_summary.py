import unittest
from unittest.mock import patch
from types import SimpleNamespace
from teacher_setup import teaching_overview
from profiles import default_profile
from onboarding import ProfileWizard

class SummaryTests(unittest.TestCase):
    def test_declared_hdtn_is_visible_before_analysis(self):
        p={'teaching_options':dict(hdtn=['6A3'],integrated=['6A3'],extra=[]),'courses':{},'schedules':[]}
        values=teaching_overview(p)
        self.assertEqual(values['hdtn'],['6A3']);self.assertEqual(values['extra'],[])
        values['hdtn'].append('6A2');self.assertEqual(p['teaching_options']['hdtn'],['6A3'])
    def test_legacy_teacher_is_inferred(self):
        values=teaching_overview(default_profile())
        self.assertEqual(values['hdtn'],[]);self.assertEqual(values['integrated'],['6A11']);self.assertEqual(values['extra'],['6A11'])
    def test_skip_api_continues_new_profile(self):
        events=[]
        wizard=SimpleNamespace(step=2,is_new=True,build=lambda:{'name':'Cô A'},cancel=lambda:events.append('close'),on_ready=lambda p:events.append(p['name']))
        with patch('ai_settings.configure',return_value=None) as configure:
            ProfileWizard.next(wizard)
            configure.assert_called_once_with(wizard,'Gemini',allow_skip=True)
        self.assertEqual(events,['close','Cô A'])
    def test_edit_does_not_prompt_for_api(self):
        wizard=SimpleNamespace(step=2,is_new=False,build=lambda:{},cancel=lambda:None,on_ready=lambda p:None)
        with patch('ai_settings.configure') as configure:
            ProfileWizard.next(wizard);configure.assert_not_called()

if __name__=='__main__':unittest.main()
