import copy
import unittest
from table_sort import TimetableSort

class Tree:
    def __init__(self,ids):self.ids=list(ids);self.headings={}
    def heading(self,key,**kw):self.headings.setdefault(key,{}).update(kw)
    def get_children(self):return tuple(self.ids)
    def move(self,iid,parent,index):self.ids.remove(iid);self.ids.insert(index,iid)

class SortTests(unittest.TestCase):
    def test_time_class_and_stable_ids(self):
        rows={
            '0':dict(day=4,session='Sáng',slot=1,classroom='6A2'),
            '1':dict(day=2,session='Chiều',slot=2,classroom='6A11'),
            '2':dict(day=2,session='Sáng',slot=4,classroom='6A2'),
            '3':dict(day=2,session='Sáng',slot=1,classroom='7A2'),
        }
        original=copy.deepcopy(rows);tree=Tree(rows);sorter=TimetableSort(tree,lambda:rows)
        sorter.apply();self.assertEqual(tree.ids,['3','2','1','0'])
        sorter.select('classroom');self.assertEqual(tree.ids,['2','0','1','3'])
        self.assertEqual(tree.headings['classroom']['text'],'Lớp ▲')
        self.assertEqual(tree.headings['day']['text'],'Thứ ⇅')
        self.assertEqual(rows,original)
        rows['0']['slot']=3;sorter.apply()
        self.assertEqual(rows['0']['classroom'],'6A2')
        sorter.select('day');self.assertEqual(tree.ids,['3','2','1','0'])
    def test_heading_calls_and_empty_list(self):
        tree=Tree([]);closed=[];sorter=TimetableSort(tree,lambda:{},before_sort=lambda:closed.append(True))
        tree.headings['classroom']['command']()
        self.assertEqual(closed,[True]);self.assertEqual(sorter.mode,'classroom')
        sorter.apply();self.assertEqual(tree.ids,[])

if __name__=='__main__':unittest.main()
