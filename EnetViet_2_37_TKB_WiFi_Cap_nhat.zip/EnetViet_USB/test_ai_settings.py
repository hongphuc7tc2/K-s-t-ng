import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from ai_settings import Settings, credentials

class AiSettingsTests(unittest.TestCase):
    def test_restart_and_provider_isolation(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'settings.json'
            cipher=lambda b,decrypt=False:bytes(x^123 for x in b)
            store=Settings(path,cipher)
            store.save('Gemini','custom-gemini','dummy-secret-only-for-test')
            store.save('OpenAI','custom-openai','dummy-other')
            self.assertNotIn('dummy-secret-only-for-test',path.read_text())
            restarted=Settings(path,cipher)
            self.assertEqual(restarted.load('Gemini'),('custom-gemini','dummy-secret-only-for-test'))
            restarted.forget('Gemini')
            self.assertEqual(restarted.load('Gemini')[1],'')
            self.assertEqual(restarted.load('OpenAI'),('custom-openai','dummy-other'))
    def test_encryption_failure_writes_nothing(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'settings.json'
            def failing(*a):raise RuntimeError('DPAPI failure')
            with self.assertRaises(RuntimeError):Settings(path,failing).save('Gemini','model','test-key')
            self.assertFalse(path.exists())
    def test_saved_key_skips_dialog(self):
        with patch('ai_settings.Settings') as store,patch('ai_settings.configure') as dialog:
            store.return_value.load.return_value=('saved-model','test-key')
            self.assertEqual(credentials(None,'Gemini'),('saved-model','test-key'))
            dialog.assert_not_called()
    def test_unreadable_key_allows_reentry(self):
        with patch('ai_settings.Settings') as store,patch('ai_settings.configure',return_value=('new','key')) as dialog:
            store.return_value.load.side_effect=RuntimeError('different Windows user')
            self.assertEqual(credentials(None,'Gemini'),('new','key'))
            dialog.assert_called_once_with(None,'Gemini')

if __name__=='__main__':unittest.main()
