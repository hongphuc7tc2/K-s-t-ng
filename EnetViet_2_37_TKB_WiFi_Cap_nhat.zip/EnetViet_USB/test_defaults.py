import tempfile
import threading
import unittest
from pathlib import Path
from defaults import resolve_defaults, preserve_defaults
from engine import FormAssistant
from profiles import Store, default_profile

class DefaultsTests(unittest.TestCase):
    def test_old_profiles_and_isolation(self):
        a=resolve_defaults(); a['remark']='Khá'
        self.assertEqual(resolve_defaults()['remark'],'Tốt')
        self.assertEqual(resolve_defaults({'remark':''})['remark'],'')
    def test_portable(self):
        with tempfile.TemporaryDirectory() as d:
            store=Store(Path(d)/'profiles'); p=default_profile()
            p['write_defaults']={'attendance':'2','remark':'Cần cố gắng','learning':'18','discipline':'9','hygiene':'8'}
            store.save(p);store.export(p,Path(d)/'p.zip')
            restored,_=store.read_package(Path(d)/'p.zip')
            self.assertEqual(restored['write_defaults'],p['write_defaults'])
            self.assertEqual(store.list()[0]['write_defaults'],p['write_defaults'])
    def test_ai_keeps_teacher_choices(self):
        p={'write_defaults':{'remark':'Khá'}}
        q=preserve_defaults(p,{'write_defaults':{'remark':'AI đổi'}})
        self.assertEqual(q['write_defaults']['remark'],'Khá')
        q['write_defaults']['remark']='Khác'
        self.assertEqual(p['write_defaults']['remark'],'Khá')
    def test_custom_scores_sent_to_fields(self):
        values={'attendance':'3','remark':'Cần cố gắng','learning':'17','discipline':'8','hygiene':'7'}
        runner=FormAssistant(None,threading.Event(),lambda s:None,write_defaults=values)
        calls=[];runner.field=lambda *args:calls.append(args);runner.save_current=lambda:calls.append('save')
        values['learning']='20'
        runner.score_and_save()
        self.assertEqual([c[2] for c in calls[:-1]],['17','8','7'])
        self.assertEqual(calls[-1],'save')
        self.assertEqual(runner.default('attendance'),'3');self.assertEqual(runner.default('remark'),'Cần cố gắng')
    def test_invalid_defaults_rejected(self):
        for bad in ([],{'remark':None},{'unknown':'1'}):
            with self.assertRaises(ValueError):resolve_defaults(bad)

if __name__=='__main__': unittest.main()
