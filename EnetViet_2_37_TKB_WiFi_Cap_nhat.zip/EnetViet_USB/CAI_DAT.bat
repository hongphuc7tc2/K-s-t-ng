@echo off
chcp 65001 >nul
cd /d "%~dp0"
py -3 --version >nul 2>&1
if errorlevel 1 (
  echo Can cai Python 3.11 tro len tu https://www.python.org/downloads/windows/
  echo Khi cai, giu tuy chon pip, Tcl/Tk va Python Launcher.
  pause
  exit /b 1
)
py -3 -m venv .venv
if errorlevel 1 goto fail
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto fail
echo Cai xong. Chay MO_PHAN_MEM.bat
pause
exit /b 0
:fail
echo Cai dat chua thanh cong. Chup lai thong bao loi de kiem tra.
pause
exit /b 1
