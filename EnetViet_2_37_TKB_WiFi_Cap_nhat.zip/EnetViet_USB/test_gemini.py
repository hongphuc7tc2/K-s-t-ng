import copy
import json
import unittest
from unittest.mock import patch
from analyzer import analyze,check_analysis
from profiles import default_profile,plan,validate

class GeminiTests(unittest.TestCase):
    def response(self,data):
        class R:
            def __enter__(self):return self
            def __exit__(self,*a):pass
            def read(self):return json.dumps(data).encode()
        return R()
    def test_request_header_and_sorted_response(self):
        p=default_profile();out=copy.deepcopy(p);out['schedules'][0]['rows'].reverse();out['reviewed']=True
        data={'candidates':[{'finishReason':'STOP','content':{'parts':[{'text':json.dumps(out)}]}}]}
        with patch('urllib.request.urlopen',return_value=self.response(data)) as call:
            result=analyze(p,'giữ nguyên PPCT',[],'TEST-SECRET','gemini-test','Gemini')
        request=call.call_args.args[0];body=json.loads(request.data)
        self.assertIn('generativelanguage.googleapis.com',request.full_url)
        self.assertNotIn('TEST-SECRET',request.full_url);self.assertNotIn('TEST-SECRET',json.dumps(body));self.assertNotIn('TEST-SECRET',json.dumps(result))
        self.assertEqual(request.get_header('X-goog-api-key'),'TEST-SECRET')
        self.assertEqual(body['generationConfig']['responseMimeType'],'application/json')
        self.assertFalse(result['reviewed'])
        rows=result['schedules'][0]['rows'];self.assertEqual([(r['day'],r['session'],r['slot']) for r in rows[:3]],[(2,'Sáng',4),(2,'Chiều',1),(2,'Chiều',2)])
    def test_truncated_result_rejected(self):
        with patch('urllib.request.urlopen',return_value=self.response({'candidates':[{'finishReason':'MAX_TOKENS','content':{'parts':[]}}]})):
            with self.assertRaises(RuntimeError):analyze(default_profile(),'',[],'TEST','gemini-test','Gemini')
    def test_unresolved_questions_rejected(self):
        p=default_profile();p['unresolved_questions']=['Tuần nào bắt đầu PPCT 1?']
        with self.assertRaisesRegex(ValueError,'Tuần nào'):check_analysis(p)
    def test_explicit_week_overrides_formula(self):
        p=default_profile();p['week_assignments']=[{'classroom':'6A8','course':'6','week':7,'periods':[21,22,27,28]}]
        tasks=plan(p,7)
        self.assertEqual([t['period'] for t in tasks if t['classroom']=='6A8'],[21,22,27,28])
        self.assertEqual([t['period'] for t in tasks if t['classroom']=='6A1'],[25,26,27,28])
        self.assertFalse(any(t['valid'] for t in plan(p,8) if t['classroom']=='6A8'))
    def test_week_count_mismatch_rejected(self):
        p=default_profile();p['week_assignments']=[{'classroom':'6A8','course':'6','week':7,'periods':[25,26]}]
        with self.assertRaises(ValueError):validate(p)
    def test_invalid_model_cannot_change_host(self):
        with patch('urllib.request.urlopen') as call:
            with self.assertRaises(ValueError):analyze(default_profile(),'',[],'TEST','bad/host','Gemini')
            call.assert_not_called()

if __name__=='__main__':unittest.main()
