import tkinter as tk
from row_colors import group_colors
from profiles import key

TEXT={'saved':'Đã xong','skipped':'Đã làm thủ công','pending':'Chưa xong','working':'Đang làm','saving':'Cần kiểm tra'}
COLORS={'saved':'#08702c','skipped':'#08702c','pending':'#b42318','working':'#905400','saving':'#a64b00'}
class StatusCells:
    """Render status text independently for the two status columns."""
    def __init__(self,app):
        self.app=app;self.labels={};self.styles={};self.pending=None
        tree=app.table
        def moved(bar,*values):
            bar.set(*values)
            self.invalidate()
        tree.configure(xscrollcommand=lambda *v:moved(app.hscroll,*v),
                       yscrollcommand=lambda *v:moved(app.vscroll,*v))
        tree.bind('<Configure>',lambda e:self.invalidate(),add='+')
        self.poll()
    def invalidate(self):
        # Hide old overlays synchronously, before the scrolled table is painted.
        for widget in self.labels.values():widget.place_forget()
        if self.pending is None:self.pending=self.app.table.after_idle(self.refresh)
    def poll(self):
        if self.pending is None:self.refresh()
        self.app.table.after(250,self.poll)
    def refresh(self):
        self.pending=None
        app=self.app;tree=app.table
        try:
            if not tree.winfo_exists():return
            rows={key(t):t for t in app.tasks};shades=group_colors(rows,app.sorter.mode);selected=set(tree.selection());visible=set()
            for iid,t in rows.items():
                for col in ('write','complete'):
                    rect=tree.bbox(iid,col)
                    if not rect:continue
                    x,y,w,h=rect
                    if x<0 or x+w>tree.winfo_width():continue
                    ident=(iid,col);visible.add(ident)
                    if ident not in self.labels:
                        widget=tk.Label(tree,anchor='center',bd=0,padx=0,pady=0)
                        widget.bind('<Button-1>',lambda e,tr=tree:tr.event_generate('<Button-1>',x=e.x_root-tr.winfo_rootx(),y=e.y_root-tr.winfo_rooty(),state=e.state))
                        widget.bind('<MouseWheel>',lambda e,tr=tree:tr.event_generate('<MouseWheel>',delta=e.delta,state=e.state))
                        for button in (4,5):
                            widget.bind(f'<Button-{button}>',lambda e,tr=tree:tr.event_generate(f'<Button-{e.num}>',state=e.state))
                        self.labels[ident]=widget
                    state=app.ledger.state(t,col);widget=self.labels[ident]
                    style=(TEXT.get(state,'Chưa xong'),COLORS.get(state,'#b42318'),'#b6d6fa' if iid in selected else shades[iid],('Segoe UI',11,'bold' if iid in selected else 'normal'))
                    if self.styles.get(ident)!=style:
                        widget.configure(text=style[0],foreground=style[1],background=style[2],font=style[3])
                        self.styles[ident]=style
                    widget.place(x=x+1,y=y+1,width=w-2,height=h-2)
            for ident in list(self.labels):
                if ident not in visible:
                    self.labels.pop(ident).destroy();self.styles.pop(ident,None)
        except tk.TclError:return
