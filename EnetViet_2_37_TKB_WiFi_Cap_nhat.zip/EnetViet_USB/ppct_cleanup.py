"""Repair the explicit two-period/two-lesson merged-cell case before review."""
import copy
import re

def repair_merged_lessons(profile):
    result=copy.deepcopy(profile);notes=[]
    for code,course in result.get('courses',{}).items():
        periods=course.get('periods',{})
        numbers=sorted(int(n) for n in periods)
        index=0
        while index<len(numbers):
            group=[numbers[index]];text=str(periods[str(group[0])]);index+=1
            while index<len(numbers) and numbers[index]==group[-1]+1 and str(periods[str(numbers[index])])==text:
                group.append(numbers[index]);index+=1
            if len(group)<2:continue
            lines=text.splitlines()
            starts=[i for i,line in enumerate(lines) if re.match(r'^\s*Bài\s+\d+\s*[.:]',line,re.I)]
            if len(group)==2 and len(starts)==2:
                cut=starts[-1]
                periods[str(group[0])]='\n'.join(lines[:cut]).strip()
                periods[str(group[1])]='\n'.join(lines[cut:]).strip()
                notes.append(f"{course.get('name',code)}: đã tách ô gộp trùng ở tiết {group[0]}–{group[1]}; bài cuối vào tiết sau, phần trên vào tiết đầu. GV đối chiếu lại nguồn trước khi áp dụng.")
            elif len(starts)>1:
                raise ValueError(f"{course.get('name',code)}: các tiết {group} bị lặp ô chứa nhiều bài, chưa đủ căn cứ tách. Gửi riêng ảnh/đoạn PPCT này và ghi rõ bài của từng tiết để phân tích lại.")
    if notes:
        result['analysis_notes']='\n'.join(filter(None,[result.get('analysis_notes',''),*notes]))
        result['reviewed']=False
    return result
