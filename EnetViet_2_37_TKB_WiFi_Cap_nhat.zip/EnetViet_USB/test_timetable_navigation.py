import unittest
from unittest.mock import patch
from types import SimpleNamespace
from xml.etree.ElementTree import Element,SubElement
from navigator import Navigator

class Harness(Navigator):
    def __init__(self,slot=4):
        self.page=0;self.open=False;self.actions=[];self.slot=slot
        self.stop=SimpleNamespace(wait=lambda t:False)
        self.d=SimpleNamespace(window_size=lambda:(500,900),swipe=self.swipe)
        self.log=lambda s:None
    def check(self):pass
    def nodes(self):
        root=Element('node')
        SubElement(root,'node',text='Ghi sổ đầu bài' if self.open else 'Sổ đầu bài giáo viên')
        for title,value in [('Chọn tuần','Tuần 6'),('Chọn buổi','Buổi sáng')]:
            group=SubElement(root,'node')
            SubElement(group,'node',text=title,attrib={'resource-id':'app:id/textViewLabel'})
            SubElement(group,'node',text=value,attrib={'resource-id':'app:id/textViewValue'})
        SubElement(root,'node',text='T2',selected='true')
        ls=SubElement(root,'node',attrib={'resource-id':'app:id/rvNotebook','bounds':'[0,200][500,850]'})
        card=SubElement(ls,'node',bounds='[0,780][500,900]' if self.page==0 else '[0,300][500,480]')
        SubElement(card,'node',text=f'Tiết {self.slot}')
        if self.page:
            SubElement(card,'node',attrib={'resource-id':'app:id/imageViewAdd','bounds':'[200,350][260,410]'})
        return list(root.iter('node'))
    def click(self,n):
        self.actions.append(n.get('resource-id',n.get('text')))
        self.open=True
    def swipe(self,x,a,x2,b,duration):
        self.actions.append('down' if a>b else 'up');self.page=1
    def wait_nodes(self,predicate,message,timeout=20):
        ns=self.nodes()
        if not predicate(ns):raise RuntimeError(message)
        return ns

class NavigationTests(unittest.TestCase):
    @patch('navigator.time.sleep')
    def test_clipped_card_scrolls_down_without_reselecting_day_session(self,_):
        nav=Harness()
        nav.open_task(dict(week=6,day=2,session='Sáng',slot=4,classroom='6A1',subject='Toán'))
        self.assertEqual(nav.actions,['down','app:id/imageViewAdd'])
        self.assertTrue(nav.open)
    @patch('navigator.time.sleep')
    def test_completion_never_creates_empty_record(self,_):
        nav=Harness()
        with self.assertRaisesRegex(RuntimeError,'chưa có sổ'):
            nav.open_task(dict(week=6,day=2,session='Sáng',slot=4,classroom='6A1'),existing_only=True)
        self.assertEqual(nav.actions,['down'])
